#!/bin/bash
echo  --------------------------------------------------------------
echo                    Assets Install
echo  --------------------------------------------------------------

echo Installing assets
# Execute
php bin/console assets:install --no-debug >null
echo Assets installation complete
echo

echo Resetting directory permissions
chown -R www-data:www-data web
echo -------------------------------------------------------------
echo
