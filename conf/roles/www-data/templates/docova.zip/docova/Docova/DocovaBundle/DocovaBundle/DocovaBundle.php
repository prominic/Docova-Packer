<?php

namespace DocovaBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class DocovaBundle extends Bundle
{
}
