#!/bin/bash
echo  --------------------------------------------------------------
echo                    Setup DOCOVA SE
echo  --------------------------------------------------------------


while true; do
    echo WARNING: This process will recreate your DOCOVA SE database
    echo          if it already exists. Only use this option for
    echo          brand new installations.

    read -p "Are you sure you wish to continue?" yn
    case $yn in
        [Yy]* ) break;;
        [Nn]* ) exit;;
        * ) echo "Please answer yes or no.";;
    esac
done


echo Temporarily override entity data types for table creation.
# Execute
php  switchormdatatype.php "$PWD/src/Docova/DocovaBundle/Entity/*.php" string text >null
echo entity data type conversion complete
echo

echo Creating docova_db ...
# Execute
php bin/console doctrine:database:create >null
echo docova_db created
echo

echo Creating schema ...
# Execute
php bin/console doctrine:schema:create >null
echo Schema creation complete
echo

echo Removing override on entity data types.
# Execute
php  switchormdatatype.php "$PWD/src/Docova/DocovaBundle/Entity/*.php" text string >null
echo entity data type conversion complete
echo

echo Loading datafixtures ...
# Execute
php bin/console doctrine:fixtures:load --no-interaction >null
echo Completed loading datafixture
echo

echo Installing assets
# Execute
/bin/bash InstallAssets.sh > null
echo Assets installation complete
echo

echo Clearing prod cache
# Execute
php bin/console cache:clear --env=prod --no-debug --no-warmup >null
echo clear cache completed
echo

echo Clearing dev cache
# Execute
php bin/console cache:clear --env=dev --no-debug --no-warmup >null
echo clear cache completed
echo

echo -------------------------------------------------------------
echo
