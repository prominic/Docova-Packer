<?php 
namespace Docova\DocovaBundle\Extensions;

//use Docova\DocovaBundle\Extensions\ExternalDataSource;
use Symfony\Component\HttpFoundation\Response;

/*
 * Read data from SQL data source
 */
class SQLDataSource extends ExternalDataSource {
	private $pdo=null;	
	private $csvFilePath = null;
	private $em=null;
	private $controller=null;
	private $driverName="unknown";
    private $noResults = false;
    private $displayColumns = null; 
	
	public function __construct($controller,$name,$pdo,$query,$orderBy,$keyName=null,$key=null,$offset=0,$limit=10000,$search=null,$docovaDocumentsOnly=false){	
		
		if (! $pdo instanceof \PDO  && !$pdo instanceof \Doctrine\DBAL\Connection)
			throw new \Exception("Invalid PDO Provided. Received: ".\gettype($pdo));		
		$this->pdo = $pdo;
		$this->controller=$controller;
		$this->em=$this->getEntityManager($controller);
		if ($this->pdo instanceof \PDO){
			$this->driverName = $this->pdo->getAttribute(\PDO::ATTR_DRIVER_NAME); 
			//$this->driverName = $this->pdo->getDriver()->getName();
		}
		else{
			$this->driverName = $this->getDoctrine($controller)->getDriver()->getName();
			//$this->driverName = $this->pdo->getAttribute(\PDO::ATTR_DRIVER_NAME);
		}
		
		$noOffsetAndNoKey = false;
		//echo "<br/>Offset: ".json_encode($offset);
		//echo "<br/>Key: ".json_encode($key);
		if (is_null($offset)){
		    $offset = 0;
		    if (empty($key)){
		        $noOffsetAndNoKey = true;
		    }
		}
		//echo "<br/>Key Name: ".json_encode($keyName);
		//echo "<br/>Key: ".json_encode($key);
		if (empty($keyName) || empty($key) ){		    
		    if ($noOffsetAndNoKey){		        
		        //generate empty results		        
		        $this->readQueryData($query." WHERE 1=0",$orderBy,$offset,1,$search,$keyName);
		    }
		    else{
		        $this->readQueryData($query,$orderBy,$offset,($limit==0 ? 1000000 : $limit),$search);		        
		    }
		}
		else{
		    $this->readQueryData($query,$orderBy,$offset,($limit==0 ? 1000000 : $limit),$search,$keyName,$key);
		}
		
		parent::__construct($name,$this->fields, $this->data, new \DateTime(), false, $docovaDocumentsOnly);
		//echo "Data: ".json_encode($this->data);
		
		
	}
	public function setDisplayColumns(array $columns){
	   $this->displayColumns = $columns;
	}
	public function getDisplayColumns(){
	    return $this->displayColumns;
	}
	public static function getEntityManager($controller){
		return  $controller->getEntityManager();
	}
	public static function getDoctrine($controller){
		return  $controller->getDoctrineConnection();
	}
	
	public function getRowCountResponse($table,$query=null){
		$count = $this->getRowCount($table,$query);
		$result = '<?xml version="1.0" encoding="UTF-8"?>
			<Results><Result ID="Status">OK</Result><Result ID="Ret1">'.$count.'</Result></Results>';
		$response = new Response();
		$response->headers->set('Content-Type', 'text/xml');
		$response->setContent($result);
		return $response;
	}
	public function getRowCount($table,$query=null){
		if ($query==null)
			$query = "SELECT Count(*) FROM ".$table;		
		$statement = $this->pdo->query($query);
		$results = array_values($statement->fetchAll());
		return $results[0][0];
	}	
	private function readQueryData($query,$orderBy,$offset=0,$limit=10000,$search=null,$keyName=null,$key=null){		
		$hasOrderBy = !(\strpos(\strtoupper($query),"ORDER BY")===false);
		if ($hasOrderBy){
			//$query = \substr($query,0,\strpos(\strtoupper($query),"ORDER BY"));
		}		
		//echo "<br/>Read query: ".$query;
		$statement=null;
		$SQL = "";
		try {		    
			$hasCount = !(\strpos(\strtoupper($query),"COUNT(")===false);
			if (!$hasCount){
				$queryOptions="";				
				//query by key
				if (!empty($keyName) && !empty($key)){
				    if (is_numeric($key)){
				        //no quotes
				        $queryOptions.= PHP_EOL." WHERE ".$keyName."=".$key;
				    }
				    else{
				        //quoted, single quotes get doubled up
				        $queryOptions.= PHP_EOL." WHERE ".$keyName."='".str_replace("'","''", $key)."'";
				    }
				    if (!empty($orderBy) && $orderBy!="")
				        $queryOptions.= " ORDER BY ".$orderBy;
				}				
				else if (!empty($keyName) && empty($key)){	
				    $hasWhere = !(\strpos(\strtoupper($query)," WHERE ")===false);
				    if (!$hasWhere){
				        $queryOptions.= PHP_EOL." WHERE 1=0 ";
				    }
                    if ($hasOrderBy==false && !empty($orderBy) && $orderBy!="")
					      $queryOptions.= " ORDER BY ".$orderBy;
				}				
				else{
				//default is to query by row position
    				if ($hasOrderBy==false && !empty($orderBy) && $orderBy!="")
    					$queryOptions.= " ORDER BY ".$orderBy;
    				//echo "Driver: ".$this->getDriverName();
    				
    				if ($this->getDriverName()=="sqlsrv" || $this->getDriverName()=="pdo_sqlsrv")				
    					$queryOptions.=" OFFSET ".$offset." ROWS FETCH NEXT ".$limit." ROWS ONLY";
    				else
    					$queryOptions.=" LIMIT ".$limit." OFFSET ".$offset." ";
				}
				
				$SQL = $query.$queryOptions;	
			//	echo "<br/>Running query: ".$SQL.PHP_EOL;
				$statement = $this->pdo->query($SQL);
				
			}
			else{ 

			   
			    if ($hasOrderBy==false){
			         $SQL = $query." ORDER BY ".$orderBy;
			    }
			    else{
			        $SQL = $query;
			    }
			  //  echo "<br/>Running query: ".$SQL.PHP_EOL;
				$statement = $this->pdo->query($SQL);
			}
		} 
		catch (\PDOException $pe) {
			echo "SQL:".$SQL.PHP_EOL."SQLDataSource() - ERROR: ".$pe->getMessage();
		}		
		
		if ($statement==false){
		    echo "SQL:".$SQL.PHP_EOL."SQLDataSource() - ERROR: ".json_encode($this->pdo->errorInfo());
		}
		$this->data = array();
		//Use the statement to compute the field names
		$columnCount = $statement->columnCount();
		$this->fields = array();
		for($iColumn=0;$iColumn<$columnCount;$iColumn++){
			$columnMeta = $statement->getColumnMeta($iColumn);
			$this->fields[] = $columnMeta["name"];			
		}
		
		$rowPosition=0;
		$rowsMatched=0;
		
		while ( $dataRow=$statement->fetch() ){		
			if ($this->pdo instanceof \Doctrine\DBAL\Connection)	
				$dataRow = array_values($dataRow);
			$rowPosition++;
			$processRow=true;
		//	echo "Row: ".$rowPosition.PHP_EOL;
		 //   echo \json_encode($dataRow).PHP_EOL;
		 
			$ddOnly = $this->getDocovaDocumentsOnly();
			if ($ddOnly){
				//1.) Read the DOCOVA id
				//2). Confirm access to the document
				$idFieldIndex = $this->getFieldIndex('id');
				$docIdFieldIndex = $this->getFieldIndex('doc_id');
				$documentId = !empty($dataRow[$idFieldIndex]) ? $dataRow[$idFieldIndex] : null;
				$documentId = empty($documentId) && !empty($dataRow[$docIdFieldIndex]) ? $dataRow[$docIdFieldIndex] : $documentId;
				$accessCheck = ExternalDataSource::verifySourceAccess($this->controller, $documentId, "Document");
				if ($accessCheck==false)
					$processRow=false;
			}
			
			if ($search!=null){
			    //if this string is quoted
			    $searchLen = strlen($search);
			    if ($searchLen>2){
    			    $firstChar = substr($search, 0, 1);
    			    $lastChar = substr($search,$searchLen-1,1);
    			    if ($firstChar=='"' && $lastChar=='"'){
    			        $search = substr($search,1,$searchLen-2);
    			    }
			    }
				//Search Limit of 500 results
				if ($rowsMatched>=500)
					break;
				$processRow=false;
				foreach($dataRow as $dataField){
					$matches=!(\strpos(\strtolower($dataField),\strtolower($search))===false);	
					//$pos = \strpos(\strtolower($dataField),\strtolower($search));
					//echo "<br/>Data Field :".$dataField.", Search: ".$search.", Matches: ".$matches.", Pos: ".json_encode($pos);
					if ($matches==1){						
						$processRow=true;	
						$rowsMatched++;				
						break;
					}					
				}				
			}			
			
			if ($processRow){
			    //echo PHP_EOL."Data Row:".json_encode($dataRow);
			    //echo PHP_EOL."Row: ".(($rowPosition+$offset)-1);
				$this->data[($rowPosition+$offset)-1]=$dataRow;	
			}
		}
		
		if (count($this->data)==0){		    
		    foreach($this->fields as $index ){
		        $this->data["0"][$index] = ""; 
		    }
		    $this->noResults=true;
		}
		
		parent::setData($this->data);
	}
	
	public function hasResults(){
	    return $this->noResults==false;
	}
	private function computeInsert($tableName,$data,$keyName,$insertKey){
	    $fieldNames = "";
	    $names = array_keys($data);
	    foreach($names as $name){
	        if ($insertKey==false){
	            //do not list the key field name
	            if ($name==$keyName){
	                continue;
	            }
	        }
	        if ($fieldNames!="") $fieldNames.=",";
	        $fieldNames.=$name;
	    }
	    
	    $sql = "INSERT INTO ".$tableName.PHP_EOL." (".$fieldNames.") VALUES (";
	    $columnCount =0;
	    foreach($data as $name => $value){
	        if ($insertKey==false){
	            //do not list the key field value
	            if ($name==$keyName){
	                continue;
	            }
	        }
	        
	        $columnCount++;
	        if ($columnCount>1){
	            $sql.= ','.PHP_EOL;
	        }
	        if ($value===""){
	            $sql.="null";
	        }
	        else if (is_numeric($value)){
	            //no quotes
	            $sql.=$value;
	        }
	        else{
	            //quoted, single quotes get doubled up
	            $sql.="'".str_replace("'","''", $value)."'";
	        }
	    }
	   
	    $sql.=")";
	    
	    return $sql;
	}
	private function computeRead($tableName,$keyName,$key,$data){
	    $fieldNames = "";
	    $names = array_keys($data);
	    foreach($names as $name){
	        if ($fieldNames!="") $fieldNames.=",";
	        $fieldNames.=$name;
	    }
	    $sql = "SELECT ".$fieldNames." FROM ".$tableName;
	    
	    if (is_numeric($key)){
	        //no quotes
	        $sql.= PHP_EOL."WHERE ".$keyName."=".$key;
	    }
	    else{
	        //quoted, single quotes get doubled up
	        $sql.= PHP_EOL."WHERE ".$keyName."='".str_replace("'","''", $key)."'";
	    }
	       
	    return $sql;
	}
	private function computeUpdate($tableName,$keyName,$key,$data){
	    $sql = "UPDATE ".$tableName.PHP_EOL." SET ";
        $columnCount =0;
        foreach($data as $name => $value){
            if ($keyName==$name){
                //do not update the key
                continue;
            }
            $columnCount++;
            if ($columnCount>1){
                $sql.= ','.PHP_EOL;
            }
            if ($value===""){
                $sql.=$name."=null";
            }
            else if (is_numeric($value)){
                //no quotes
                $sql.=$name."=".$value."";
            }
            else{
                //quoted, single quotes get doubled up
                $sql.=$name."='".str_replace("'","''", $value)."'";                
            }
        }
        if (is_numeric($key)){
            //no quotes
            $sql.= PHP_EOL."WHERE ".$keyName."=".$key;
        }
        else{
            //quoted, single quotes get doubled up
            $sql.= PHP_EOL."WHERE ".$keyName."='".str_replace("'","''", $key)."'";
        }
	    
	     return $sql;   
	}
	
	private function computeDelete($tableName,$keyName,$key){
	    $sql = "DELETE FROM ".$tableName.PHP_EOL." ";
	    if (is_numeric($key)){
	        //no quotes
	        $sql.= PHP_EOL."WHERE ".$keyName."=".$key;
	    }
	    else{
	        //quoted, single quotes get doubled up
	        $sql.= PHP_EOL."WHERE ".$keyName."='".str_replace("'","''", $key)."'";
	    }
	    
	    return $sql;
	}
	
	public function deleteRow($tableName,$keyName,$key){
	    $sql= $this->computeDelete($tableName,$keyName,$key);	   
	    $result = $this->pdo->exec($sql);
	    if ($result===false){
	        throw new \Exception($sql."<br/>deleteRow() - ERROR: <br/>".json_encode($this->pdo->errorInfo(),JSON_PRETTY_PRINT));
	    }
	    return $result;
	}
	
	public function readRow($tableName,$keyName,$key,$data){
	    $sql= $this->computeRead($tableName,$keyName,$key,$data);
	    if ($this->pdo->exec($sql)===false){
	        echo "<br/>".$sql."<br/>";
	        echo "<br/>readRow() - ERROR: <br/>".json_encode($this->pdo->errorInfo(),JSON_PRETTY_PRINT);
	    }
	}
	
	public function updateRow($tableName,$keyName,$key,$data){
	    $sql= $this->computeUpdate($tableName,$keyName,$key,$data);
	   // echo "<br/>".$sql;
	    if ($this->pdo->exec($sql)===false){
	        echo "<br/>".$sql."<br/>";
	        echo "<br/>updateRow() - ERROR: <br/>".json_encode($this->pdo->errorInfo(),JSON_PRETTY_PRINT);
	    }
	}
	public function insertRow($tableName,$keyName,$key,$data,$insertKey=false){
	    $sql= $this->computeInsert($tableName,$data,$keyName,$insertKey);
	    if ($this->pdo->exec($sql)===false){
	        echo "<br/>".$sql."<br/>";
	        echo "<br/>insertRow() - ERROR: <br/>".json_encode($this->pdo->errorInfo(),JSON_PRETTY_PRINT);
	        return false;
	    }
	    else if ($insertKey==false) {
	        return $this->pdo->lastInsertId($tableName);
	    }
	    else{
	        return true;
	    }
	}
	public function getDriverName() {
		return $this->driverName;
	}
	
	
}
?>