<?php
namespace Docova\DocovaBundle\Extensions;

use Docova\DocovaBundle\Entity\DataViews;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Docova\DocovaBundle\Entity\AppForms;

class ExternalView
{
    
    private $controller;
    private $rootPath;
    private $dataView;
    private $dataViewId;
    private $dataSource;
    private $em;
    
    function __construct($controller,$rootPath,$dataViewOrId){
        //Check to see if there this folder is supplied by an external view
        $this->controller = $controller;
        $this->rootPath = $rootPath;
        $this->em = $controller->getEntityManager();
        
        
        
        if ($dataViewOrId instanceof DataViews){
            $this->dataView = $dataViewOrId;
            $this->dataViewId = $this->dataView->getId();
        }
        else{
            $this->dataViewId = $dataViewOrId;
            $this->dataView = $this->em->getRepository("DocovaBundle:DataViews")->getDataView( $dataViewOrId);
        }
        
        if (empty($this->dataView)){
            throw new \Exception("Data View: ".$dataViewOrId." can not be located!");
        }
            
        $this->dataSource = !empty($this->dataView) ? $this->dataView->getDataSource($this->em) : null;
    }
    
    public function dbColumn($column,$categoryField=null,$categoryKey=null) {
        $sqlSource = $this->getSQLSource(1,0,false);
        
        return $sqlSource->dbColumn($column);
    }
    private function getSQLSource($start,$count,$searchQuery) {
        //Adjust the offsets and limits
        $start = ($searchQuery!=null ? 1 : $start);
        $start = ($start==0 ? 1 : $start);
        $count = ($count==10000 ? 1000000 : $count);
        $count = ($searchQuery!=null ? 1000000 : $count);
        
        
        //Data View Hooks
        if (!empty($this->dataView) && !empty($this->dataSource)){
            $connectionName = $this->dataSource->getConnectionName();
            
            $connection = $connectionName=="DOCOVA SE" ? $this->controller->getDoctrine()->getConnection() : ExternalConnections::getConnection($connectionName);
            $dataType = $this->dataSource->getType();
            
            if ($dataType=="SQL"){
                $sqlType = $this->dataSource->getSQLType();
                if ($sqlType=="Text")
                    $query = $this->dataSource->getSQL();
                    else if ($sqlType=="File Resource" &&
                        (empty($query) || $query=="" ))
                        $query = $this->dataSource->getFileResourceContent($this->em,$this->rootPath);
                        
                        if (empty($query) || $query=="" ){
                            throw new NotFoundHttpException("A query must be provided");
                        }
                        $docovaDocumentsOnly = $this->dataSource->getDocovaDocumentsOnly();
                        if (empty($docovaDocumentsOnly) || $docovaDocumentsOnly==false){
                            $docovaDocumentsOnly=false;
                        }
                        
                        //If the data view has a filter then append it as an additonal condition
                        $whereFilter=$this->dataView->getSQLFilter();
                        if (!empty($whereFilter) && $whereFilter!=""){
                            //if a where statement does not exist in the query then add one
                            if (\strpos(\strtolower($query),"where")===false)
                                $query.=" WHERE ".$whereFilter;
                                else
                                    //add an additional AND WHERE condition
                                    $query.=" AND ".$whereFilter;
                        }
                                              
                        $sqlSource = new SQLDataSource(
                            $this->controller,
                            $this->dataView->getName(),
                            $connection,
                            $query,
                            $this->dataSource->getSQLOrderBy(),
                            null,
                            null,
                            ($start-1),
                            $count,$searchQuery,$docovaDocumentsOnly);
                        
                        return $sqlSource;
            }
        }
       
    }
    
    private function getSQLData($start,$count,$searchQuery,$returnJSON=false) {
        $isSearch = ($searchQuery==null ? false : true);
        $sqlSource = self::getSQLSource($start, $count, $searchQuery);
        
        if (!empty($sqlSource)){
            $docovaDocs = null;
            $keyFieldName = $this->dataSource->getSQLKeyName();
            $formName = $this->dataView->getFormName();
            if (!empty($keyFieldName) && !empty($formName) ){                
                $docovaDocs = $this->getAssociatedDOCOVADocuments($this->em, $this->dataView->getAppId(), $formName, $keyFieldName);                
            }
            if ($returnJSON){
                return $sqlSource->getJsonResponse($this->dataView->getId(),$isSearch,$this->dataSource->getSQLKeyName(),
                    null /*key value*/,
                    null /*column*/,
                    null /*perspective columns*/,
                    $docovaDocs
                    );
            }
            else{
                //NO LONGER USED
                return $sqlSource->getXmlResponse($this->dataView->getId(),$isSearch,$this->dataSource->getSQLKeyName());
            }
        }
    }
    
    /*
     * Return DOCOVA document references keyed by key field values
     * 1.  Locate the form field (design element)
     * 2.  Locate the key field values associated with with this form
     * 3.  Index the associated document objects by key field value
     */
    protected function getAssociatedDOCOVADocuments($em,$application,$formName,$keyFieldName,$keyFieldValue=null){
        $form = $this->getApplicationForm($application, $formName);
        if (empty($form)){
            return array();
        }
        $keyField = $this->getFormElement($form,$keyFieldName);
        
        if (empty($keyField)){
            return array();
        }
               
        //for now lets assume all key fields are text
        $ftv = $em->getRepository("DocovaBundle:FormTextValues");
        
        $query = $ftv->createQueryBuilder('EV')
        ->select('EV')
        ->where('EV.Field = :field');
        
        if ($keyFieldValue==null){
            $parameters = array('field' => $keyField);
            $query->setParameters($parameters);
        }
        else{
            $parameters = array('field' => $keyField,'summaryValue'=> $keyFieldValue);
            $query->andWhere('EV.summaryValue = :summaryValue');
            $query->setParameters($parameters);
        }
        
        $query = $query->getQuery();
        
        $fieldValues = $query->getResult();
        
        $results = array();
        
        if (!empty($fieldValues)){
            foreach($fieldValues as $fieldValue){
                $results[$fieldValue->getFieldValue()]=$fieldValue->getDocument();
            }
        }
        
        return $results;
    }
    
   protected function getApplicationForm($application,$formName){
        $forms = $this->em->getRepository("DocovaBundle:AppForms");
        $query = $forms->createQueryBuilder('F')->select("F")->where('F.application = :application')
        ->andWhere('F.formName = :formName');
        $query->setParameters(array('application'=>$application,'formName'=>$formName));
        $appForms = $query->getQuery()->getResult();
        if (!empty($appForms)){
            return $appForms[0];
        }
        else{
            return null;
        }
    }
    protected function getFormElement(AppForms $form,$fieldName){
        $elements = $form->getElements();
        if (!empty($elements)){
            foreach($elements as $element){
                if (strtolower($element->getFieldName())==strtolower($fieldName)) {
                    return $element;
                }
            }
        }
    }
    public function getCount(){
        //Data View Mappings
        if (!empty($this->dataView) && !empty($this->dataSource)){
            $dataType = $this->dataSource->getType();
            if ($dataType=="SQL"){
                $connectionName = $this->dataSource->getConnectionName();
                $connection = $connectionName=="DOCOVA SE" ? $this->controller->getDoctrine()->getConnection() : ExternalConnections::getConnection($connectionName);
                $sqlType = $this->dataSource->getSQLType();
                if ($sqlType=="Text")
                    $query = $this->dataSource->getSQL();
                    else if ($sqlType=="File Resource" &&
                        (empty($query) || $query=="" ))
                        $query = $this->dataSource->getFileResourceContent($this->em,$this->rootPath);
                        
                        if (empty($query) || $query=="" )
                            throw new NotFoundHttpException("A query must be provided");
                            
                            //check to see if this is a DOCOVA documents source
                            $docovaDocumentsOnly = $this->dataSource->getDocovaDocumentsOnly();
                            if (empty($docovaDocumentsOnly) || $docovaDocumentsOnly==false){
                                $docovaDocumentsOnly=false;
                            }
                            
                            $sqlSource = new SQLDataSource(
                                $this->controller,
                                $this->dataView->getName(),
                                $connection,
                                $query,
                                $this->dataSource->getSQLOrderBy(),
                                null,//key name
                                null,//key value
                                0,
                                0,
                                $docovaDocumentsOnly);
                            
                            return $sqlSource->getRowCountResponse($this->dataSource->getSQLTableName());
            }
            else if ($dataType=="CSV"){
                $csvPath = $this->dataSource->getFileResourcePath($this->em,$this->rootPath);
                if (empty($csvPath))
                    throw new NotFoundHttpException("File resouce ".$this->dataSource->getFileResourceName()." was not found!");
                    return CSVDataSource::getRowCountResponse($csvPath);
            }
        }

    }
    public function getDocumentByKey($key){
       
        if (empty($this->dataView) && empty($this->dataSource)){
            throw new NotFoundHttpException("Data View or Data Source could not be located!");
        }
        
        switch ($this->dataSource->getType()){
            case "CSV":
                if ($this->dataSource->getName()=="IIS Logs" || $this->dataSource->getName()=="IIS Log"){
                    $iisPath="C:/inetpub/logs/LogFiles/W3SVC1/";
                    $files = scandir($iisPath, SCANDIR_SORT_DESCENDING);
                    $csvFilePath = $iisPath.$files[0];
                    if (empty($csvFilePath))
                        throw new NotFoundHttpException("No log files found to process in path");
                }
                else
                    $csvFilePath = $this->dataSource->getFileResourcePath($this->em,$this->rootPath);
                    
                    //CSV Options
                    $csvDelimiter = $this->dataSource->getCSVDelimiter();
                    $csvOffsetLines = $this->dataSource->getCSVOffsetLines();
                    $csvOffsetChars = $this->dataSource->getCSVOffsetChars();
                    
                    $csvSource = new CSVDataSource($this->controller,$csvFilePath,intval($key)-1,1,null,
                        $csvDelimiter,$csvOffsetLines,$csvOffsetChars);
                    return $csvSource->getDataNameValues();
                    break;
            case "SQL":
                $connectionName = $this->dataSource->getConnectionName();
                $connection = $connectionName=="DOCOVA SE" ? $this->controller->getDoctrine()->getConnection() : ExternalConnections::getConnection($connectionName);
                $sqlType = $this->dataSource->getSQLType();
                if ($sqlType=="Text")
                    $query = $this->dataSource->getSQL();
                    if (empty($query) || $query=="")
                        $query = $this->dataSource->getFileResourceContent($this->em,$this->rootPath);
                        
                        
                        //check to see if this is a DOCOVA documents source
                        $docovaDocumentsOnly = $this->dataSource->getDocovaDocumentsOnly();
                        if (empty($docovaDocumentsOnly) || $docovaDocumentsOnly==false){
                            $docovaDocumentsOnly=false;
                        }
                        
                        
                        $sqlSource = new SQLDataSource(
                            $this->controller,
                            $this->dataView->getName(),
                            $connection,
                            $query,
                            $this->dataSource->getSQLOrderBy(),
                            $this->dataSource->getSQLKeyName(),//key name
                            $key,//key value
                            $key==null ? null : 0,
                            1,
                            $docovaDocumentsOnly);
                        
                        return $sqlSource->getDataNameValues();
                        break;
        }
    }
    public function getData($start,$count,$searchQuery,$returnJSON=false) {
        //Check to see if there this folder is supplied by an external view
        if (empty($this->dataView))
            return null;
            
            //Proces SQL data extensions
            $data = $this->getSQLData($start, $count, $searchQuery,$returnJSON);
            
            if ($data!=null) return $data;
            
            //Proces CSV data extensions
            $data = $this->getCSVData($start, $count, $searchQuery);
            if ($data!=null) return $data;
            
            return null;
    }
    private function getCSVSource($start,$count,$searchQuery){
        
        //Adjust the offsets and limits
        $start = $searchQuery!=null ? 1 : $start;
        $count = $count==10000 ? 0 : $count;
        
        //Data view hooks
        if (!empty($this->dataView) && !empty($this->dataSource)){
            
            $dataType = $this->dataSource->getType();
            if ($dataType=="CSV"){
                
                if ($this->dataSource->getName()=="IIS Logs" || $this->dataSource->getName()=="IIS Log"){
                    $iisPath="C:/inetpub/logs/LogFiles/W3SVC1/";
                    $files = scandir($iisPath, SCANDIR_SORT_DESCENDING);
                    $csvFilePath = $iisPath.$files[0];
                    if (empty($csvFilePath))
                        throw new NotFoundHttpException("No log files found to process in path");
                }
                else
                    $csvFilePath = $this->dataSource->getFileResourcePath($this->em,$this->rootPath);
                    
                    if (empty($csvFilePath)){
                        throw new \Exception("Unable to determine CSV data file location in "+$this->rootPath);
                    }
                    
                    //CSV Options
                    $csvDelimiter = $this->dataSource->getCSVDelimiter();
                    $csvOffsetLines = $this->dataSource->getCSVOffsetLines();
                    $csvOffsetChars = $this->dataSource->getCSVOffsetChars();
                    
                    $docovaDocumentsOnly = $this->dataSource->getDocovaDocumentsOnly();
                    if (empty($docovaDocumentsOnly) || $docovaDocumentsOnly==false){
                        $docovaDocumentsOnly=false;
                    }
                    
                    $csvSource = new CSVDataSource($this->controller,$csvFilePath,$start,$count,$searchQuery,
                        $csvDelimiter,$csvOffsetLines,$csvOffsetChars,$docovaDocumentsOnly);
                    
                    return $csvSource;
            }
        }

    }
    private function getCSVData($start,$count,$searchQuery){
        $csvSource = $this->getCSVSource($start, $count, $searchQuery);
        $isSearch = $searchQuery==null ? false : true;
        if ($csvSource==null)
            return null;
            else
                return $csvSource->getXmlResponse($this->dataView->getId(),$isSearch);
    }
    private function getFirstDocument($documentData){
        
        foreach($documentData as $data){
            if (!empty($data)){
                return $data;
            }
        }
    }
    public function getRowData($fields,$request){
        $row=array();
        foreach($fields as $field){
            $field_value = $request->get($field);
            if (empty($field_value) && $field_value!="0")
                $field_value="";
                $row[$field]=$field_value;
        }
        return $row;
    }
   
    public function readDocument($doc_id, $folder_id){
        //Do not process DOCOVA documents
        if (!empty($this->dataSource)){
            $docovaDocumentsOnly = $this->dataSource->getDocovaDocumentsOnly();
            if (!empty($docovaDocumentsOnly) && $docovaDocumentsOnly){
                return null;
            }
        }
        
        $documentData = $this->getFirstDocument($this->getDocumentByKey($doc_id));
        $securityContext = $this->controller->getSecurityContext();
        /*
         //Log for a custom form
         if (\file_exists(\realpath(__DIR__.'/../Resources/views/DesignElements/A094EE8F-F4AB-41F0-BCC2-5BC004EEBF42')."/".$dataView->getName().'_read.html.twig')){
         
         return $controller->renderForm('DocovaBundle:DesignElements:A094EE8F-F4AB-41F0-BCC2-5BC004EEBF42/'.$dataView->getName().'_read.html.twig', array(
         'viewTitle' => $dataView->getName(),
         'dataViewId' => $dataView->getId(),
         'data' => $documentData,
         'doc_id' => $doc_id,
         'user' => $securityContext->getToken()->getUser(),
         'form' => $dataView->getName()
         ));
         }
         //Look for a custom twig
         else
         */
         
         $customFormPath = \realpath(__DIR__.'/../Resources/views/Form').DIRECTORY_SEPARATOR.$this->dataView->getName().'_read.html.twig';
         if (\file_exists($customFormPath)){
             //render using custom form
             return $this->controller->renderForm('DocovaBundle:Form:'.$this->dataView->getName().'_read.html.twig', array(
                 'dataSource' => $this->dataView->getDataSource($this->em),
                 'dataView' => $this->dataView,
                 'viewName' => $this->dataView->getName(),
                 'viewTitle' => (empty($this->dataView->getFormLabel()) ? $this->dataView->getName(): $this->dataView->getFormLabel()),
                 'dataViewId' => $this->dataView->getId(),
                 'data' => $documentData,
                 'doc_id' => $doc_id,
                 'user' => $securityContext->getToken()->getUser(),
                 'canEdit' => $this->dataView->canUpdate()
             ));
         }
         else {
             //no custom twig found, render using the default twig
             return $this->controller->renderForm('DocovaBundle:Form:Default-External_read.html.twig', array(
                 'dataSource' => $this->dataView->getDataSource($this->em),
                 'dataView' => $this->dataView,
                 'viewName' => $this->dataView->getName(),
                 'viewTitle' => (empty($this->dataView->getFormLabel()) ? $this->dataView->getName(): $this->dataView->getFormLabel()),
                 'dataViewId' => $this->dataView->getId(),
                 'data' => $documentData,
                 'doc_id' => $doc_id,
                 'user' => $securityContext->getToken()->getUser(),
                 'canEdit' => $this->dataView->canUpdate()
             ));
         }
         
    }
    
    public function saveDocument($request, $doc_id, $folder_id){
        //Do not process DOCOVA documents
        if (!empty($this->dataSource)){
            $docovaDocumentsOnly = $this->dataSource->getDocovaDocumentsOnly();
            if (!empty($docovaDocumentsOnly) && $docovaDocumentsOnly){
                return null;
            }
        }
                
        if ($this->dataSource->getType()=="CSV"){
            $source = $this->getCSVSource(0, 1000000, null);
            $source->updateCSVLine($doc_id, $this->getRowData($source->fields,$request));            
            $source->saveCSVFile();
        }
        else if ($this->dataSource->getType()=="SQL"){
            if (is_numeric($doc_id)){
                $source = $this->getSQLSource($doc_id, 1, null);
            }
            else{
                $source = $this->getSQLSource(0, 1, null);
            }
            
            $rowData = self::getRowData($source->fields,$request);
            $keyColumn = $this->dataSource->getSQLKeyName();
            //echo "<br/>Source Fields: ".json_encode($source->fields);
            //echo "<br/>Row Data: ".json_encode($rowData);
            //echo "<br/>Key Column: ".json_encode($keyColumn);
            if (empty($doc_id) || $doc_id=="null" ){
                //echo "<br/>New Document: true";
                //new document
                if ($this->dataSource->getSQLKeyGenType()=="DOCOVA Generated GUID"){                    
                    $generatedKey = $rowData[$keyColumn]=$this->getGUID();
                    $source->insertRow($this->dataSource->getSQLTableName(), $this->dataSource->getSQLKeyName(),null,$rowData,true);
                }
                else{
                    $generatedKey = $source->insertRow($this->dataSource->getSQLTableName(), $this->dataSource->getSQLKeyName(),null,$rowData);
                }
                return $generatedKey;
            }
            else{
                //existing document
                //echo "<br/>New Document: false";
                $source->updateRow($this->dataSource->getSQLTableName(),$keyColumn,$doc_id, $rowData);
            }

        }
        $source=null;
    }
    function getGUID(){
        if (function_exists('com_create_guid')){
            return com_create_guid();
        }else{
            mt_srand((double)microtime()*10000);//optional for php 4.2.0 and up.
            $charid = strtoupper(md5(uniqid(rand(), true)));
            $hyphen = chr(45);// "-"
            $uuid = chr(123)// "{"
            .substr($charid, 0, 8).$hyphen
            .substr($charid, 8, 4).$hyphen
            .substr($charid,12, 4).$hyphen
            .substr($charid,16, 4).$hyphen
            .substr($charid,20,12)
            .chr(125);// "}"
            return $uuid;
        }
    }
    public function editDocument($doc_id,$folder_id){
        //Do not process DOCOVA documents
        if (!empty($this->dataSource)){
            $docovaDocumentsOnly = $this->dataSource->getDocovaDocumentsOnly();
            if (!empty($docovaDocumentsOnly) && $docovaDocumentsOnly){
                return null;
            }
        }
        if (empty($doc_id) || $doc_id=="undefined" || $doc_id=="null"){
            //new document
            $documentData = $this->getFirstDocument($this->getDocumentByKey(null));
        }
        else {
            $documentData = $this->getFirstDocument($this->getDocumentByKey($doc_id));
        }
        $securityContext = $this->controller->getSecurityContext();
        
        $customFormPath = \realpath(__DIR__.'/../Resources/views/Form').DIRECTORY_SEPARATOR.$this->dataView->getName().'_edit.html.twig';
        if (\file_exists($customFormPath)){
            //render using custom form
            return $this->controller->renderForm('DocovaBundle:Form:'.$this->dataView->getName().'_edit.html.twig', array(
                'dataSource' => $this->dataView->getDataSource($this->em),
                'dataView' => $this->dataView,
                'viewName' => $this->dataView->getName(),
                'viewTitle' => (empty($this->dataView->getFormLabel()) ? $this->dataView->getName(): $this->dataView->getFormLabel()),
                'doc_id' => $doc_id,
                'folderId' => $folder_id,
                'dataViewId' => $this->dataView->getId(),
                'document' => $documentData,
                'user' => $securityContext->getToken()->getUser(),
                'keyName' => $this->dataSource->getSQLKeyName(),                
            ));
        }
        else {
            //no custom twig found, render using the default twig
            return $this->controller->renderForm('DocovaBundle:Form:Default-External_edit.html.twig', array(
                'dataSource' => $this->dataView->getDataSource($this->em),
                'dataView' => $this->dataView,
                'viewName' => $this->dataView->getName(),
                'viewTitle' => (empty($this->dataView->getFormLabel()) ? $this->dataView->getName(): $this->dataView->getFormLabel()),
                'doc_id' => $doc_id,
                'folderId' => $folder_id,
                'dataViewId' => $this->dataView->getId(),
                'document' => $documentData,
                'user' => $securityContext->getToken()->getUser(),
                'keyName' => $this->dataSource->getSQLKeyName()
            ));
        }
    }
    
    public function deleteDocument($doc_id, $folder_id){
        
        //Do not process DOCOVA documents
        if (!empty($this->dataSource)){
            $docovaDocumentsOnly = $this->dataSource->getDocovaDocumentsOnly();
            if (!empty($docovaDocumentsOnly) && $docovaDocumentsOnly){
                return null;
            }
        }
                
        if ($this->dataSource->getType()=="CSV"){
            //TBD
            /*
             $source = self::getCSVSource($controller, $rootPath, $folder_id, 0, 1000000, null, $dataSource, $dataView);
             
             */
        }
        else if ($this->dataSource->getType()=="SQL"){
            $source = $this->getSQLSource(0, 1, null);
            return $source->deleteRow($this->dataSource->getSQLTableName(), $this->dataSource->getSQLKeyName(), $doc_id);
        }
    }
}

