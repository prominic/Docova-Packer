<?php
namespace Docova\DocovaBundle\Extensions;


use Symfony\Component\HttpFoundation\Request;

class ExternalDataView
{
    private $em = null;
    private $doctrine = null;
    
    public function __construct($em,$doctrine){
        $this->em = $em;
        $this->doctrine = $doctrine;
    }
    public function dbSelect($appNameOrId,$viewName,$where,$columns,$orderBy=null){
        $app_id=null;
        if ($this->isGUID($appNameOrId)){
            $app_id=$appNameOrId;
        }
        else{
            $app_id=$this->getApplicationId($this->em, $appNameOrId);
        }
        $dataView = $this->em->getRepository("DocovaBundle:DataViews")->getDataViewByName($viewName,$app_id);
        $dataSource = $dataView->getDataSource($this->em);
        
        $connectionName = $dataSource->getConnectionName();
        $connection = $connectionName=="DOCOVA SE" ? $this->doctrine->getConnection() : ExternalConnections::getConnection($connectionName);
        
        
        if (empty($columns)){
            $query = "SELECT * FROM ".$dataSource->getSQLTableName();
            $wherePos = \strpos(\strtolower($query),"where");
            if (!empty($where)){
                if ($wherePos===false){
                    $query .= " WHERE ".$where;
                }
                else{
                    $query = substr($query,0,$wherePos)." WHERE ".$where;
                }
            }
        }
        else{
            $query = "SELECT ".$columns." FROM ".$dataSource->getSQLTableName();
            if (!empty($where)){
                $query .= " WHERE ".$where;
            }
        }
        
        if (!empty($orderBy)){
            $orderByPos = \strpos(\strtolower($query),"order by");
            if ($orderByPos===false){
                $query .= " ORDER BY ".$orderBy;
            }
            else{
                $query = substr($query,0,$orderByPos)." ORDER BY ".$orderBy;
            }
        }
        
        $sqlSource = ExternalViews::getSQLSourceExt($this,$dataView,$dataSource,$connection,$query);       
        $data = $sqlSource->getData();
        //reduce the results to the request column values only
        //by default results are key by both name and index
        $result = array();
        if (!empty($columns)){
            $dataColumns = explode(',',$columns);            
            foreach($data as $row){
                $dataRow = array();
                foreach($dataColumns as $column){                
                    if (array_key_exists(strtolower($column), $row)){
                        $dataRow[strtolower($column)]=$row[strtolower($column)];                    
                    }
                }
                //add the processed data row to the results
                $result[]=$dataRow;
            }        
        }
        else{
            foreach($data as $row){
                $dataRow = array();
                foreach($row as $name => $value){
                    //skip any numeric keys
                    if (is_numeric($name)){
                        continue;
                    }                  
                    //process the field name references
                    $dataRow[strtolower($name)]=$value;
                    
                }
                //add the processed data row to the results
                $result[]=$dataRow;
            }
        }
        return json_encode($result,JSON_PRETTY_PRINT);
        
    }
    public function dbColumn($appNameOrId,$viewName,$column,$orderBy=null,$delimiter=";"){
        if (empty($column)){
            throw new \Exception("A column name or index must be provided!");
        }
        return $this->dbLookup($appNameOrId, $viewName, null, $column,$orderBy,$delimiter);
    }
    
    public function dbLookup($appNameOrId,$viewName,$where,$column,$orderBy=null,$delimiter=";"){
        $app_id=null;
        if ($this->isGUID($appNameOrId)){
            $app_id=$appNameOrId;
        }
        else{
            $app_id=$this->getApplicationId($this->em, $appNameOrId);
        }
        $dataView = $this->em->getRepository("DocovaBundle:DataViews")->getDataViewByName($viewName,$app_id);
        $dataSource = $dataView->getDataSource($this->em);
        
        $connectionName = $dataSource->getConnectionName();
        $connection = $connectionName=="DOCOVA SE" ? $this->doctrine->getConnection() : ExternalConnections::getConnection($connectionName);
        
        
        if (empty($column)){
            $query = $dataSource->getSQLQuery();
            $wherePos = \strpos(\strtolower($query),"where");
            if (!empty($where)){
                if ($wherePos===false){
                    $query .= " WHERE ".$where;
                }
                else{
                    $query = substr($query,0,$wherePos)." WHERE ".$where;
                }
            }            
        }
        else{
            $query = "SELECT ".$column." FROM ".$dataSource->getSQLTableName();
            if (!empty($where)){
                $query .= " WHERE ".$where;
            }
        }
        
        if (!empty($orderBy)){
            $orderByPos = \strpos(\strtolower($query),"order by");
            if ($orderByPos===false){
                $query .= " ORDER BY ".$orderBy;
            }
            else{
                $query = substr($query,0,$orderByPos)." ORDER BY ".$orderBy;
            }
        }
        
        $sqlSource = ExternalViews::getSQLSourceExt($this,$dataView,$dataSource,$connection,$query);
        $data = $sqlSource->getData();
        $result = array();
        foreach($data as $row){
            $result[] = $row[strtolower($column)];
        }
        return implode($result,$delimiter);
        
    }
    public function select($appNameOrId,$viewName,$where,$columns,$orderBy=null,$docovaFields=null){
        $app_id=null;
        if ($this->isGUID($appNameOrId)){
            $app_id=$appNameOrId;
        }
        else{
            $app_id=$this->getApplicationId($this->em, $appNameOrId);
        }
       
        $dataView = $this->em->getRepository("DocovaBundle:DataViews")->getDataViewByName($viewName,$app_id);
        $dataSource = $dataView->getDataSource($this->em);
        
        $connectionName = $dataSource->getConnectionName();
        $connection = $connectionName=="DOCOVA SE" ? $this->doctrine->getConnection() : ExternalConnections::getConnection($connectionName);
        
        
        if (empty($columns)){
            $query = $dataSource->getSQL();
            $wherePos = \strpos(\strtolower($query),"where");
            if (!empty($where)){
                if ($wherePos===false){
                    $query .= " WHERE ".$where;
                }
                else{
                    $query = substr($query,0,$wherePos)." WHERE ".$where;
                }
            }
            
        }
        else{
            $query = "SELECT ".$columns." FROM ".$dataSource->getSQLTableName();
            if (!empty($where)){
                $query .= " WHERE ".$where;
            }
        }
     
        if (!empty($orderBy)){
            $orderByPos = \strpos(\strtolower($query),"order by");
            if ($orderByPos===false){
                $query .= " ORDER BY ".$orderBy;
            }
            else{
                $query = substr($query,0,$orderByPos)." ORDER BY ".$orderBy;
            }
        }
        
        $sqlSource = ExternalViews::getSQLSourceExt($this,$dataView,$dataSource,$connection,$query);
        if (empty($dataSource->getSQLKeyName())){
            $extKeys = array();
        }
        else{
            //read the key values and use them to locate the associated DOCOVA documents
            $extKeys = $sqlSource->dbColumn($dataSource->getSQLKeyName());
        }
    
        $docovaDocs = null;
        $docovaDocFieldValues=array();
        if (!empty($docovaFields)) {           
          $docovaDocs =  ExternalViews::getAssociatedDOCOVADocuments($this->em,$app_id,$dataView->getFormName(),$dataSource->getSQLKeyName(),$extKeys);
          $applicationForm = ExternalViews::getApplicationForm($this->em, $app_id, $dataView->getFormName());
          if (!empty($applicationForm)){            
              
              $docovaDocFieldValues = ExternalViews::getSpecifiedDocumentFieldValues($this->em, $app_id, $applicationForm, $docovaDocs, $docovaFields);
              
          }
      
          if (empty($columns)){
                $columns = implode(',',$sqlSource->getFields());                
          }
            
          $columns = array_merge(explode(",",$docovaFields),explode(",",$columns));
            
        }
        else if (!empty($columns)){
            $columns = explode(",",$columns);
        }
        else{
            $columns = implode(',',$sqlSource->getDisplayColumns());
        }        
        return $sqlSource->getJson(null,false,$dataSource->getSQLKeyName(),null,null,$columns,$docovaDocs,$docovaDocFieldValues);
    }
    function insert($appNameOrId,$viewName,$dataOrRequest){
        $app_id=null;
        if ($this->isGUID($appNameOrId)){
            $app_id=$appNameOrId;
        }
        else{
            $app_id=$this->getApplicationId($this->em, $appNameOrId);
        }
        if (empty($dataOrRequest)){
            $responseData = array('Status' => 'Error - ExternalDataView->insert() - No data provided');
        }
        else if (!is_array($dataOrRequest) && !($dataOrRequest instanceof Request)){
            $responseData = array('Status' => 'Error - ExternalDataView->insert() - Data must be provided as a name value array or a Request');
        }
        else if (empty($app_id)){
            $responseData = array('Status' => 'Error - ExternalDataView->insert() - No application id provided');
        }
        else if (empty($app_id)){
            $responseData = array('Status' => 'Error - ExternalDataView->insert() - No application id provided');
        }
        else{
            $dataView = $this->em->getRepository("DocovaBundle:DataViews")->getDataViewByName($viewName,$app_id);
            $dataSource = $dataView->getDataSource($this->em);
            $keyName = $dataSource->getSQLKeyName();
            
            try{                
                //create an http request from the data provided
                $request = $this->createRequestFromData($dataOrRequest);
                
                //now post the request
                $saveDocument=true;
                $extId = ExternalViews::saveDocument($this, null, $request, null, null, $dataView->getId(),$saveDocument);
                if (!empty($keyName) && !empty($extId)){
                    $responseData = array($keyName=>$extId);
                }
                else{
                    $responseData = array('Status' => 'Insert complete');
                }
            }
            catch (\Exception $e){
                $responseData = array('Status' => 'Error - ExternalDataView->insert() '.$e->getMessage());
            }
        }
        
        return json_encode($responseData,JSON_PRETTY_PRINT);
        
    }
    
    function update($appNameOrId,$viewName,$dataOrRequest){
        $app_id=null;
        if ($this->isGUID($appNameOrId)){
            $app_id=$appNameOrId;
        }
        else{
            $app_id=$this->getApplicationId($this->em, $appNameOrId);
        }
        
        if (empty($dataOrRequest)){
            $responseData = array('Error' => 'Error - ExternalDataView->update() - No data provided');
        }
        else if (!is_array($dataOrRequest) && !($dataOrRequest instanceof Request)){
            $responseData = array('Error' => 'Error - ExternalDataView->update() - Data must be provided as a name value array or a Request');
        }
        else if (empty($app_id)){
            $responseData = array('Error' => 'Error - ExternalDataView->update() - No application id provided');
        }
        else if (empty($app_id)){
            $responseData = array('Error' => 'Error - ExternalDataView->update() - No application id provided');
        }
        else{
            if (is_array($dataOrRequest)){
                //make the keys lower case when we received a name value array
                $dataOrRequest = array_change_key_case($dataOrRequest);
            }
            $dataView = $this->em->getRepository("DocovaBundle:DataViews")->getDataViewByName($viewName,$app_id);
            $dataSource = $dataView->getDataSource($this->em);
            $keyName = $dataSource->getSQLKeyName();
            
            if (empty($keyName)){
                $responseData = array('Error' => 'Error - ExternalDataView->update() - A key field must be specified in the data source in order to identify the record to update');
            }
            else if (!empty($keyName) && is_array($dataOrRequest) && !array_key_exists($keyName, $dataOrRequest)){
                $responseData = array('Error' => 'Error - ExternalDataView->update() - The key field '.$keyName." must be provided in the data");
            }
            else if (!empty($keyName) && ($dataOrRequest instanceof Request) && !$dataOrRequest->request->has($keyName)){
                $responseData = array('Error' => 'Error - ExternalDataView->update() - The key field '.$keyName." must be provided in the request");
            }
            else{
                try{
                    //create an http request from the data provided                   
                    $request = $this->createRequestFromData($dataOrRequest);                    
                    $keyValue = $request->request->get($keyName);
                                      
                    //now post the update request
                    $saveDocument=true;
                    ExternalViews::saveDocument($this, null, $request, $keyValue, null, $dataView->getId(),$saveDocument);
                    $responseData = array('Status' => 'Update complete');
                }
                catch (\Exception $e){
                    $responseData = array('Error' => 'Error - ExternalDataView->update() '.$e->getMessage());
                }
            }
        }
        
        return json_encode($responseData,JSON_PRETTY_PRINT);        
    }
    function delete($appNameOrId,$viewName,$keys){
        $app_id=null;
        if ($this->isGUID($appNameOrId)){
            $app_id=$appNameOrId;
        }
        else{
            $app_id=$this->getApplicationId($this->em, $appNameOrId);
        }
        $dataView = $this->em->getRepository("DocovaBundle:DataViews")->getDataViewByName($viewName,$app_id);
        $dataSource = $dataView->getDataSource($this->em);
        
        $deletedDocuments = 0;
        
        if (!is_array($keys)){
            //single key provided
            try{
                ExternalViews::deleteDocument($this, null, $keys, null, $dataView, $dataSource);
                $deletedDocuments++;
            }
            catch (\Exception $e){                
            }
        }
        else{
            //multiple keys provided
            foreach($keys as $key){
                try{
                    ExternalViews::deleteDocument($this, null, $key, null, $dataView, $dataSource);
                    $deletedDocuments++;
                }            
                catch (\Exception $e){
                }
            }
        }
        $responseData=array('DeletedDocuments'=>$deletedDocuments);
        return json_encode($responseData,JSON_PRETTY_PRINT);        
    }
    function read($appNameOrId,$viewName,$key,$columns=null,$docovaFields=null){
        $app_id=null;
        if ($this->isGUID($appNameOrId)){
            $app_id=$appNameOrId;
        }
        else{
            $app_id=$this->getApplicationId($this->em, $appNameOrId);
        }
        $dataView = $this->em->getRepository("DocovaBundle:DataViews")->getDataViewByName($viewName,$app_id);
        $dataSource = $dataView->getDataSource($this->em);
        $docovaDocs = null;
        $docovaDoc=null;
        if (!empty($docovaFields)) {
            $docovaDocs =  ExternalViews::getAssociatedDOCOVADocuments($this->em,$app_id,$dataView->getFormName(),$dataSource->getSQLKeyName(),array($key));
            if (!empty($docovaDocs[$key])){
                $docovaDoc = $docovaDocs[$key];
            }
        }
        
        $extDocument = ExternalViews::readDocument($this, null, $key, null, $dataView, $dataSource, $columns, $docovaDoc, $docovaFields );
        return json_encode($extDocument,JSON_PRETTY_PRINT);
        
    }
    function getEntityManager(){
        return $this->em;
    }
    function getDoctrineConnection(){
        return $this->doctrine->getConnection();
    }
    private function createRequestFromData($data){
        //if we have received a request, then return it as-is        
        if ($data instanceof Request){            
            //data already received as a request
            return $data;
        }
        
        //only data was received
        //create an http request from the data provided
        $request = new Request();
        if (!empty($data)){
            foreach($data as $name => $value){
                $request->request->set(strtolower($name),$value);
            }
        }
        
        return $request;
    }
    
    private static function isGUID($guid){
        if (preg_match("/^(\{)?[a-f\d]{8}(-[a-f\d]{4}){4}[a-f\d]{8}(?(1)\})$/i", $guid)){
            return true;
        }
        else{
            return false;
        }
    }
    
    private function getApplicationId($em,$app){
        $app = $em->getRepository('DocovaBundle:Libraries')->getByName($app);
        if ($app){
            return $app->getId();
        }
    }
}

