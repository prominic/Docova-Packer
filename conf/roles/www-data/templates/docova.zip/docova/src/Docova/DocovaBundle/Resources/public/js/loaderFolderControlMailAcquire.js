var tempcontainer='<div id="divFolderControl"> \
<div id="divFolderControlTabContainer" style="display:none;"> \
  <div> \
      <div style="padding: 2px 4px 2px 4px; width: 100%; height: 100%; position: relative; top: 0px; left: 0px; overflow: auto;" > \
         <div id="divTreeView"></div> \
      </div> \
    </div> \
    </div> \
    </div>';
document.write(tempcontainer);
tempcontainer="";