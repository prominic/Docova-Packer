<?php
/*
Author:  Jeff Primeau
Purpose:  Provides helper method for loading external data into existing DOCOVA Libraries/Folders

IGNORE COMPILATION ERRORS, this is a part of the ScannerBundle and will be incomplete without it
However, portions can still be leverages for script based data imports into DOCOVA libraries
*/
namespace Docova\DocovaBundle\Extensions;
use Docova\DocovaBundle\Entity\Folders;
use Docova\DocovaBundle\Entity\UserAccounts;
use Doctrine\ORM\EntityManager;
use Docova\DocovaBundle\Logging\FileLogger;
use Docova\DocovaBundle\Entity\Documents;
use Docova\DocovaBundle\Controller\Miscellaneous;
use Docova\DocovaBundle\Security\User\CustomACL;
use Docova\DocovaBundle\Entity\DesignElements;
use Docova\DocovaBundle\Entity\AttachmentsDetails;
use Docova\DocovaBundle\FTP\FTPClient;
use Docova\DocovaBundle\Extensions\CSVDataSource;
use Docova\DocovaBundle\Extensions\ExternalConnections;
use Docova\DocovaBundle\Extensions\SQLDataSource;

use Docova\Bundle\DocumentScannerBundle\FileSystem\ZipReader;
use Docova\Bundle\DocumentScannerBundle\FileSystem\FileInfo;
use Docova\DocovaBundle\Extensions\MiscFunctions;
use Docova\DocovaBundle\Entity\FormDateTimeValues;
use Docova\DocovaBundle\Entity\FormNumericValues;
use Docova\DocovaBundle\Entity\FormTextValues;

/*
 * Simple class to generate DOCOVA documents from an external source
*/
class DocumentImporter {
	private $DATE_FORMAT='d/m/Y H:i:s';
	private $DATE_FORMAT_SHORT='Y-m-d';
	private $DATE_FORMAT_FULL='Y-m-d H:i:s';
	private $em=null;
	private $folder=null;
	private $doc_type=null;
	private $logger=null;
	private $container=null;
	private $customAcl=null;
	//SE File Storage Path
	private $file_path=null;
	private $web_path=null;
	private $handler=null;
	private $cache=null;
	
	public function __construct($container,EntityManager $em,$doc_type=null,FileLogger $logger=null){
		$this->container=$container;
		
		if ($logger==null){
			$this->logger = new FileLogger ( $this->getLogFileName () );
			$this->logger->enableEcho();
		}
		else{
			$this->logger=$logger;
		}
		
		if (empty($em)){
			throw new \Exception("A valid EntityManager must be provided!");
		}
				
		$this->em = $em;
		
		if (! $em instanceof EntityManager){
			throw new \Exception("A valid EntityManager must be provided!");
		}
				
		$instance = $this->container->getParameter('docova_instance') ? $this->container->getParameter('docova_instance') : 'Docova';
		$this->file_path = $this->container->getParameter('document_root') ? $this->container->getParameter('document_root').DIRECTORY_SEPARATOR.$instance.DIRECTORY_SEPARATOR.'_storage' :  $_SERVER['DOCUMENT_ROOT'].DIRECTORY_SEPARATOR.$instance.DIRECTORY_SEPARATOR.'_storage';
		$this->web_path = '/'.$instance."/_storage";
		if (!\file_exists($this->file_path.DIRECTORY_SEPARATOR."Embedded"))
			\mkdir($this->file_path.DIRECTORY_SEPARATOR."Embedded");		
		
	//	$this->log("DocumentImporter.__construct() - ".json_encode($doc_type));
			
		if (!empty($doc_type) && is_string($doc_type)){
			$this->log("Loading document type from string - ".$doc_type);
			$this->doc_type=$this->getDocType($doc_type);
		}
		else if (!empty($doc_type)) {
			$this->doc_type = $doc_type;
		}
	//	$this->log("DocumentImporter.__construct() - Final - ".json_encode($doc_type));
	}
	public function setCache($cache){
		$this->cache = $cache;
	}
	public function getCache(){
		return $this->cache;
	}
	public function setImportHandler(DocumentImportHandler $handler){
		$this->handler=$handler;
	}
	public function getImportHandler(){
		return $this->handler;
	}
	public function createFolderPath(Folders $rootFolder,$folderPath,$skip_folders=1){
		$folders = explode(DIRECTORY_SEPARATOR,$folderPath);
		$parent_folder = $rootFolder;
		$folder_count=0;
		foreach ($folders as $folder){
			$folder_count++;
			if (!empty($folder) && $folder!="." && $folder!="\\\\" && $folder_count>$skip_folders) {
				if ($this->isUTF8($folder) || $this->isValid($folder)){
					//all set
				}
				else{
					$folder = utf8_encode(utf8_decode($folder));
				}
				
				//check to see if this subfolder exists
				$subfolder = $this->getSubFolder($parent_folder, $folder);
				
				if (empty($subfolder)){
					//create the subfolder
					$this->log("Creating folder: ".$folder." in parent ".$parent_folder->getFolderName());
					$subfolder = $this->createFolder($parent_folder, $folder);
				}
				
				if (empty($subfolder)){
					throw new \Exception("Unable to create folder: ".$folder." in path ".$folderPath);
				}
				
				$parent_folder = $subfolder;
			}
		}
		return $parent_folder;
	}
	
	public function createFolder(Folders $rootFolder,$folder_name,Folders $parent_folder=null,UserAccounts $owner=null,$created=null,$modified=null){
		if (empty($rootFolder)){
			throw new \Exception("A valid root folder name must be provided!");
		}
		if (empty($folder_name)){
			throw new \Exception("A valid folder name must be provided!");
		}
		
		if (empty($owner)){
			//use the built-in account by default
			$owner = $this->getSEUser("DOCOVA SE");
		}
		
		//if the created date is provided use is, otherwise use the current date/time
		$date_created = $created;
		if (empty($date_created)){
			$date_created = new \DateTime();
		}
		
		//the modified date is optional, if not provided leave as null
		$date_modified = $modified;
		if (empty($modified)){
			$date_modified = null;
		}
		
		$folder = new Folders();
		if (!empty($parent_folder)){
			$folder->setParentfolder($parent_folder);
		}
		else{
			$folder->setParentfolder($rootFolder);
		}
		
		
		$folder->setCreator($owner);
		$folder->setDateCreated($date_created);
		if (!empty($date_modified)){
			$folder->setDateModified($date_modified);
		}
		
		$folder->setLibrary($rootFolder->getLibrary());
		$folder->setFolderName($folder_name);
		$folder->setPosition($this->em);
		$folder->setDefaultDocType('-1');
		$perspective = $this->em->getRepository('DocovaBundle:SystemPerspectives')->findOneBy(array('Perspective_Name' => 'System Default', 'Is_System' => true));
		$folder->setDefaultPerspective($perspective);
		
		if ($folder->getParentfolder())
		{
			$parent_folder = $folder->getParentfolder();
			$folder->setDefaultDocType($parent_folder->getDefaultDocType());
			if ($parent_folder->getApplicableDocType()->count() > 0)
			{
				foreach ($parent_folder->getApplicableDocType() as $dt) {
					$folder->addApplicableDocType($dt);
				}
			}
			unset($dt);
		}
		
		if (!empty($this->handler)){
			$continue = $this->handler->onFolderSave($this->em,$folder);	
			if (!$continue){
				return;
			}
		}
		
		$this->em->persist($folder);
		$this->em->flush();
		
		
		$customeACL_obj = new CustomACL($this->container);
		$res = $customeACL_obj->insertObjectAce($folder, 'ROLE_USER', array('view', 'delete'));
		
		if (!empty($folder))
		{
			$parent_authors = $customeACL_obj->getObjectACEUsers($folder, 'create');
			$parent_gauthors = $customeACL_obj->getObjectACEGroups($folder, 'create');
		}
		if ((empty($parent_authors) || $parent_authors->count() == 0) && (empty($parent_gauthors) || $parent_gauthors->count() == 0))
		{
			$res = $customeACL_obj->insertObjectAce($folder, 'ROLE_USER', 'create');
		}
		else {
			if (!empty($parent_authors) && $parent_authors->count() > 0)
			{
				foreach ($parent_authors as $pauthor) {
					if (false !== $user_obj = $this->findUserAndCreate($pauthor->getUsername(), false, true))
					{
						$res = $customeACL_obj->insertObjectAce($folder, $owner, 'create', false);
					}
				}
			}
			if (!empty($parent_gauthors) && $parent_gauthors->count() > 0)
			{
				foreach ($parent_gauthors as $group) {
					$res = $customeACL_obj->insertObjectAce($folder, $group->getRole(), 'create');
				}
			}
		}
		//@TODO: Create a log for new inserted ACL for the object
		
		$res = $customeACL_obj->insertObjectAce($folder, $owner, 'owner', false);
		
		if (!empty($this->handler)){
			$continue = $this->handler->postFolderSave($this->em,$folder);
			if (!$continue){
				return;
			}
		}
		
		return $folder;
	}
	public function importCSVFile(Folders $rootFolder,$csvFilePath,$searchQuery=null,$start=0,$count=0,$csvDelimiter=",",$csvOffsetLines=0,$csvOffsetChars=0){
	    $attachments=null;
		if (!file_exists($csvFilePath)){
			throw new \Exception("CSV Source File ".$csvFilePath. " could not be located!");
		}
		
		$csvSource = new CSVDataSource($this->container,$csvFilePath,$start,$count,$searchQuery,
				$csvDelimiter,$csvOffsetLines,$csvOffsetChars);
		
		$data = $csvSource->getData();
		$rowIndex=0;
		$docType = "Mail Document";
		
		foreach($data as $row){
			$rowIndex++;
			
			$rowValues =  $csvSource->getRowNameValues($rowIndex,$row);			
			$rowValues['Subject']=basename($csvFilePath)." - Row ".$rowIndex;
			//read and strip off any special fields
			//*******************************************
			if (!empty($rowValues["File_Attachments"])){
				$attachments = explode(";",$rowValues["File_Attachments"]);
				unset($rowValues["File_Attachments"]);
			}
			if (!empty($rowValues["Doc_Type"])){
				$docType = $rowValues["Doc_Type"];
				unset($rowValues["Doc_Type"]);
			}
			if (!empty($rowValues["Subject"])){
				$subject = $rowValues["Subject"];
				unset($rowValues["Subject"]);
			}
			if (empty($subject)){
				$subject = basename($csvFilePath)." - Row ".$rowIndex;
			}
			//*******************************************
			
			//the remaining fields are processed as meta-data
			$this->log("Creating document from CSV Row: ".$rowIndex. " of ".$csvFilePath);
			$document = $this->createDocument($rootFolder, $subject, $rowValues, $attachments);
		}
		
		
	}
	public function importDominoData(Folders $rootFolder,$nsfTitle,$nsfPath){
	//	$conn = new DominoConnection(array());
		$conn->setConnectionName($nsfTitle);
		$conn->setDatabaseName($nsfPath);
		$conn->setDatabaseUser("Jeff Primeau");
		$conn->setDatabasePassword("SyncMa5t3r");
		
		//$user = $this->getSEUser("BSimpson");
		$user = $this->getSEUser("DOCOVA SE");		
		$conn->setUserCredentials($this->getContainer(), $this->em, $user);
		
		$documents = $conn->documentLookup("States", null, null,null,0,1000,true,true);
		echo PHP_EOL."Domino Data: ".PHP_EOL.json_encode($documents,JSON_PRETTY_PRINT);
	}
	public function importSQLData(Folders $rootFolder,$sourceName,$connectionName,$query=null,$orderBy=null,$start=1,$count=0,$searchQuery=null){
		$connection = $connectionName=="DOCOVA SE" ? $this->container->get('doctrine')->getConnection() : ExternalConnections::getConnection($connectionName);
		if (empty($sourceName)){
			$sourceName = $connectionName;
		}
		if (empty($query) || $query=="" ){
			throw new \Exception("A query must be provided");
		}
		
		$sqlSource = new SQLDataSource(
					$sourceName,
					$connection,
					$query,
					$orderBy,
		            null,
		            null,
					($start-1),
					$count,$searchQuery);
						
		$data = $sqlSource->getData();
		
		echo PHP_EOL."SQL Data: ".PHP_EOL.json_encode($data,JSON_PRETTY_PRINT);
		
		$rowIndex=0;
		$docType = "Mail Document";
		
		foreach($data as $row){
			$rowIndex++;
			
			$rowValues =  $sqlSource->getRowNameValues($rowIndex,$row);
			
			//read and strip off any special fields
			//*******************************************
			if (!empty($rowValues["File_Attachments"])){
				$attachments = explode(";",$rowValues["File_Attachments"]);
				unset($rowValues["File_Attachments"]);
			}
			else{
				$attachments = null;
			}
			
			if (!empty($rowValues["Doc_Type"])){
				$docType = $rowValues["Doc_Type"];
				unset($rowValues["Doc_Type"]);
			}
			if (!empty($rowValues["Subject"])){
				$subject = $rowValues["Subject"];
				unset($rowValues["Subject"]);
			}
			if (empty($subject)){
				$subject = $sourceName." - Row ".$rowIndex;
			}
			//*******************************************
			
			//the remaining fields are processed as meta-data
			$this->log("Creating document from SQL Row: ".$rowIndex. " of ".$sourceName);
			$document = $this->createDocument($rootFolder, $subject, $rowValues, $attachments);
		}
		
		
	}
	public function importFTPFiles($host,$port,$login,$password,$secure=false,$directory,Folders $rootFolder,$recursive=false){
		$ftpClient = new FTPClient($host, $port, $login, $password, $secure, $directory);
		$ftpHandle = $ftpClient->getStream();
		
		//read all of the files in the specified directory and subdirectories as required 		
		$ftp_info = $ftpClient->listFiles($directory,$recursive);
		
		echo PHP_EOL."Details: ".PHP_EOL.json_encode($ftp_info,JSON_PRETTY_PRINT);
		
		if (!empty($ftp_info)){
			foreach ($ftp_info as $ftp_file_info){
				$file_path = $ftp_file_info["Path"];
				$file_directory = str_replace("/", DIRECTORY_SEPARATOR, $ftp_file_info["Directory"]);
				$file_name = $ftp_file_info["Name"];
				$file_size = $ftp_file_info["Size"];
				$file_modified = $ftp_file_info["Modified"];
				
				//download the file content
				$file_path_local = $ftpClient->getFile($file_path,$file_modified);
				
				if (!file_exists($file_path_local)){
					throw new \Exception("Unable to access local file: ".$file_path_local);
				}
				
				//create the folder path and document
				$parent_folder = $this->createFolderPath($rootFolder, $file_directory, 0);
				$file_document = $this->createDocument($parent_folder, $file_name,array("Description"=>$file_path),array($file_path_local));
			}
		}
		else{
			echo PHP_EOL."No FTP files found in ".$directory."!";
		}
	}
	public function importCachedFiles(Folders $rootFolder,$rootPath,$doc_type=null,$released=false,$archived=false){
		
		
		if (!file_exists($rootPath)){
			throw new \Exception("Root path ".$rootPath." does not exist!");
		}
	
		if ($this->right($rootPath,1)!=DIRECTORY_SEPARATOR){
			$rootPath.=DIRECTORY_SEPARATOR;
		}
	
		if (empty($doc_type)){
			$doc_type = $this->doc_type;
		}
	
		if (!empty($doc_type) && is_string($doc_type)){
			$this->log("Getting document type for name: ".json_encode($doc_type));
				
			$doc_type=$this->getDocType($doc_type);
		}
		else{
			//$this->log("Document Type: ".$doc_type->getDocName()." ID: ".$doc_type->getId());
		}
	
		//$this->log("Importing Type: ".$doc_type->getDocName(). " ID: ".$doc_type->getId());
	
		try{			
			//$this->log("Creating folder from Path as/if required: ".$rootPath);
			$parent_folder = $this->createFolderPath($rootFolder, $rootPath, 100);
			$count = count($this->cache);			
			//$this->log("Processing ".$count." files from Root Path: ".$rootPath." via file cache");
				
			if (empty($this->cache)){
				throw new \Exception("No cache available!");
			}
			//process files
			foreach($this->cache as $filePath){
					if (!empty($filePath)) {						
						$fileName = (new FileInfo($filePath))->getFilename();
	
						if (\file_exists($filePath)){
							//$this->log("Processing cache file: ".$filePath);
							//create the file document
							$document = $this->createDocument($parent_folder, $fileName, array("Description" => $filePath), array($filePath),null,null,null,$released,$archived);
							
							if ($document===-5){
								//already processed
								//remove the file from the cache
								$this->log("Removing processed file: ".$filePath." from file cache");
								unset($this->cache[$filePath]);
							}
							else if (!empty($document)){
								$this->log("Document created for: ".$filePath);
								
								//remove the file from the cache
								unset($this->cache[$filePath]);
							}
							else{
				//				$this->log("Document NOT created for: ".$filePath);
							}
							//for each file processed, run the handler
							if (!empty($this->handler)){
								$this->handler->postFileProcessed($this->em, $document,$filePath,!empty($document));
							}
							if ($document!==null){
							//	$this->em->detach($document);
								unset( $document );
								$document = null;
							}
							
							if (empty($document) || $document===-5){
							    //break out as soon as we do not have a match
							    break;
							}
						}
						unset($fileName);		
						
						$this->em->clear("DocovaBundle:Documents");
						$this->em->clear("DocovaBundle:DocumentsLog");
						$this->em->clear("DocovaBundle:Attachments");
						$this->em->clear("DocovaBundle:DesignElements");
						$this->em->clear("DOCOVAScannerBundle:ScannerImportedFile");
						
						gc_collect_cycles(); // PHP garbage collect
					}
					else{
						$this->log("Cache File is null");
					}
			}	
			
		}
		catch (\Exception $e){
			$this->log(PHP_EOL."ERROR: ".$e->getMessage());
		    $this->log(PHP_EOL."TRACE: ".PHP_EOL.$e->getTraceAsString());
		}
	
	}
	public function importFiles(Folders $rootFolder,$rootPath,$doc_type=null,$skip_folders=1,$process_subfolders=false){
		if (!file_exists($rootPath)){
			throw new \Exception("Root path ".$rootPath." does not exist!");
		}
		
		if ($this->right($rootPath,1)!=DIRECTORY_SEPARATOR){
			$rootPath.=DIRECTORY_SEPARATOR;
		}
		
		if (empty($doc_type)){
			$doc_type = $this->doc_type;
		}
		
		if (!empty($doc_type) && is_string($doc_type)){
			$this->log("Getting document type for name: ".json_encode($doc_type));
			
			$doc_type=$this->getDocType($doc_type);
		}
		else{
			$this->log("Document Type: ".$doc_type->getDocName()." ID: ".$doc_type->getId());
		}
		
		//$this->log("Importing Type: ".$doc_type->getDocName(). " ID: ".$doc_type->getId());
		
		try{
			$this->log("Creating folder from Path as/if required: ".$rootPath);
			$parent_folder = $this->createFolderPath($rootFolder, $rootPath, $skip_folders);
			
			$this->log("Processing files from Root Path: ".$rootPath);
			
			//process files
			foreach(new \DirectoryIterator($rootPath) as $targetFileOrFolder){
				if ($targetFileOrFolder){
					if ($targetFileOrFolder->isDot()==false && $targetFileOrFolder->isFile()) {
						$filePath = $targetFileOrFolder->getPathname();
						$fileName = $targetFileOrFolder->getFilename();
						
						if (\file_exists($filePath)){							
							//create the file document							
							$document = $this->createDocument($parent_folder, $fileName, array("Description" => $filePath), array($filePath));
							
							//for each file processed, run the handler
							if (!empty($this->handler)){
								$this->handler->postFileProcessed($this->em, $document,$filePath,!empty($document));
							}
							if ($document!==null){
							//	$this->em->detach($document);
								unset($document);
								$document = null;
							}
						}
						else{
							$this->log("File ".$filePath." does not exist");
						}
					}
				}
			}
			
			//process folders
			if ($process_subfolders){
				$this->log("Processing sub-folders in path: ".$rootPath);
				foreach(new \DirectoryIterator($rootPath) as $targetFileOrFolder){
					if ($targetFileOrFolder){
						if ($targetFileOrFolder->isDot()==false && $targetFileOrFolder->isDir()) {
							
							$folderPath = $targetFileOrFolder->getPathname().DIRECTORY_SEPARATOR;
							
							$this->log("Processing sub-folder: ".$folderPath);
							if (\file_exists($folderPath)){		
								//import the folder's files
								$this->importFiles($rootFolder, $folderPath, $this->doc_type, $skip_folders,$process_subfolders);
							}
						}
					}
					else{
						$this->log("No target file of folder!");
					}
				}
			}
			else{
				$this->log("Subfolder processing is disabled!");
			}
		}
		catch (\Exception $e){
			$this->log(PHP_EOL."importFiles() - ERROR: ".$e->getMessage());
			$this->log(PHP_EOL."importFiles() - TRACE: ".$e->getTraceAsString());			
		}
		
	}
	
	public function importZipFiles(ZipReader $zipReader,Folders $rootFolder,$doc_type=null,$skip_folders=1,$process_subfolders=false){
		$rootPath="";
		
		if ($this->right($rootPath,1)!=DIRECTORY_SEPARATOR){
			$rootPath.=DIRECTORY_SEPARATOR;
		}
	
		if (empty($doc_type)){
			$doc_type = $this->doc_type;
		}
	
		if (!empty($doc_type) && is_string($doc_type)){
			$this->log("Getting document type for name: ".json_encode($doc_type));
				
			$doc_type=$this->getDocType($doc_type);
		}
	
		//$this->log("Importing Type: ".$doc_type->getDocName(). " ID: ".$doc_type->getId());
	
		try{
			if ($rootPath!=""){
				$this->log("Creating folder from Path as/if required: ".$rootPath);
				$parent_folder = $this->createFolderPath($rootFolder, $rootPath, $skip_folders);
			}
				
			//process zip files
			$zipFiles = $zipReader->getArchiveFiles();	
			
			$importedFiles = 0;
			foreach($zipFiles as $index => $targetFile){
				//do not permit the same file to be processed twice
				if ($zipReader->isFileProcessed($targetFile)){
					continue;
				}
								
				$zipFilePath = $this->extractZipFile($zipReader, $targetFile, $index);
				$this->importFile ( $parent_folder, $doc_type, $zipFilePath );
				
				//purge the temporary file created immediately
				if (\file_exists($zipFilePath)){
					unlink($zipFilePath);
				}
				$this->em->clear("DocovaBundle:Documents");
				$this->em->clear("DocovaBundle:DocumentsLog");
				$this->em->clear("DocovaBundle:Attachments");
				$this->em->clear("DocovaBundle:DesignElements");
				$this->em->clear("DOCOVAScannerBundle:ScannerImportedFile");
				gc_collect_cycles(); // PHP garbage collect
			}
			
		}
		catch (\Exception $e){			
			$this->log(PHP_EOL."importZipFiles() - ERROR: ".$e->getMessage());
			$this->log(PHP_EOL."importZipFiles() - TRACE: ".$e->getTraceAsString());
			return false;
		}
	  return true;
	}
	
	private function extractZipFile(ZipReader $zipReader, $targetFile, $index){
		if (!empty($targetFile)){
			//extract the specified file to the file system (tempdir)
			$tempDir = sys_get_temp_dir();
			$fileInfo = new FileInfo($targetFile);
			$zipFileName=$tempDir.DIRECTORY_SEPARATOR.$fileInfo->getFileName();
			$zipReader->extractFile($targetFile,$index, $zipFileName);
			return $zipFileName;
		}
	}
	
	 private function importFile(Folders $rootFolder,$doc_type=null,$targetFile) {
		if (!empty($targetFile) && file_exists($targetFile) ){
					//remember the original document type in case its changing
					
					//$this->log("importFile() - Orig Type: ".json_encode($this->doc_type));
					$origDocType = $this->doc_type;
					if (!empty($doc_type)){
						$this->doc_type = $doc_type;
						//$this->log("importFile() - New Type: ".json_encode($this->doc_type));
					}
					else{
					//	$this->log("importFile() -Type is empty");
					}
					
					try{
					//create the file document
					$this->log("Procesing single file: ".$targetFile);
					$fileInfo = new FileInfo($targetFile);
					$this->createDocument($rootFolder, $fileInfo->getFileName(), array(), array($targetFile));
									
					}
					catch (\Exception $e){
						$this->logger->log("importFile() - ".$e->getMessage(),FileLogger::ERROR);
					}
					
					//reset the document type back to the original value
					$this->doc_type = $origDocType;
					$this->log("Type reset");

		}
	 
	}
	public function createDocument(Folders $folder,$subject,$meta_data=null,array $attachments=null,UserAccounts $owner=null,$created=null,$modified=null,$released=false,$archived=false){
	try{
		//Initialize the document object
		$document = new Documents();
		$miscfunctions = new MiscFunctions();
		$document->setId($miscfunctions->generateGuid());
		
		if (!empty($this->handler)){
			$continue = $this->handler->onDocumentCreate($this->em,$document,$meta_data,$attachments);
			if ($continue===-5){
				return -5;
			}
			if (!$continue){
				return;
			}
		}
		
		if (! $folder instanceof Folders){
			$folder = $this->getFolderById($folder);
		}
		
		if (! $folder instanceof Folders){
			throw new \Exception("A valid folder of type Folders must be provided!");
		}
		
		$this->folder = $folder;
		
		if (empty($subject)){
			throw new \Exception("A valid subject must be provided!");
		}
		
		if (empty($owner)){
			//use the built-in account by default
			$owner = $this->getSEUser("DOCOVA SE");
		}
		
		//if the created date is provided use is, otherwise use the current date/time
		$date_created = $created;
		if (empty($date_created)){
			$date_created = new \DateTime();
		}
		
		//the modified date is optional, if not provided leave as null
		$date_modified = $modified;
		if (empty($modified)){
			$date_modified = null;
		}
		
		//now populate the document		
		$document->setAuthor($owner);
		$document->setCreator($owner);
		$document->setModifier($owner);
		$document->setDateCreated($date_created);
		if (!empty($date_modified)){
			$document->setDateModified($date_modified);
		}
			
		$document->setDocTitle($subject);
		
		if (!empty($this->doc_type) && is_string($this->doc_type)){
			$this->log("Getting doc type for name: ".$this->doc_name);
			$this->doc_type = $this->getDocType($this->doc_type);
		}
		$document->setDocType($this->doc_type);
		if ($released==false){
			$document->setDocStatus('Draft');
			$document->setStatusNo(0);
		}
		else{
			$document->setDocStatus('Released');
			$document->setStatusNo(1);
		}
		
		if ($archived){
		    $document->setArchived(1);
		    $document->setDateArchived(new \DateTime());
		}
		
		$document->setFolder($this->folder);
		$document->setOwner($owner);
		
		$document->setDocVersion('0.0');
		$document->setRevision(0);
		
		if (!empty($this->handler)){
			$continue = $this->handler->onDocumentSave($this->em,$document,$meta_data,$attachments);
			if (!$continue){
				return;
			}
		}
		
		$this->em->persist($document);
		$this->em->flush();
		
		//secure the document and create its log
		$security_check = $this->getMiscellaneous();
		$security_check->createDocumentLog($this->em, 'CREATE', $document);
		$customAcl = $this->getCustomACL();
		$customAcl->insertObjectAce($document, $owner, 'owner', false);
		$customAcl->insertObjectAce($document, 'ROLE_USER', 'view');
				
		//return the id to the caller
		$this->log("Created document ID: ".$document->getId()." Subject: ".$subject." Folder ".$this->folder->getFolderName());
		
		$attachmentField=null;
		if (!empty($meta_data)){
			$this->log("Importing fields for document ID: ".$document->getId());
                        $attachmentField = $this->importFields($document, $meta_data);
		}
		
			//$this->log("Attachments: ".json_encode($attachments,JSON_PRETTY_PRINT));
			//$this->log("Attachments Field: ".json_encode($attachmentField,JSON_PRETTY_PRINT));
			
			if (!empty($attachments) && !empty($attachmentField)){
				//$this->log("Importing attachments for document ID: ".$document->getId());
				$this->importAttachments($document, $attachments, $attachmentField);
			}
		
		if (!empty($this->handler)){
			$continue = $this->handler->postDocumentSave($this->em,$document);
			if (!$continue){
				return;
			}
		}
		
			unset($meta_data);
			$meta_data = null;			
			unset($attachments);
			$attachments = null;
		}
		catch (\Exception $e){
			$this->log(PHP_EOL."createDocument() - ERROR: ".$e->getMessage());
			$this->log(PHP_EOL."createDocument() - TRACE: ".$e->getTraceAsString());
			throw $e;
		}
		return $document;
	}
	public function getFolderById($rootFolder){
		$folderRep = $this->em->getRepository('DocovaBundle:Folders');
		$qb = $folderRep->createQueryBuilder("f");
		$qb->select("f")
		->join('f.Library', 'l')
		//	->where("l.Library_Title=?1")
		//	->setParameter(1, $this->library)
		->where("l.Status=?2")
		->setParameter(2, true)
		->andWhere("l.Trash=?3")
		->setParameter(3, false)
		->andWhere("f.id=?4")
		->setParameter(4, $rootFolder)
		->andWhere("f.Del=?5")
		->setParameter(5, false);
		
		$results = $qb->getQuery()->getResult();
		
		if (!empty($results[0]))
			return $results[0];
			else
				throw new \Exception("The folder ".$rootFolder." can not be located in the library ".$this->library."!");
	}
	public function getSubfolder(Folders $parentFolder,$folder){
		$folderRep = $this->em->getRepository('DocovaBundle:Folders');
		$qb = $folderRep->createQueryBuilder("f");
		$qb->select("f")
		->join('f.Library', 'l')
		//	->where("l.Library_Title=?1")
		//	->setParameter(1, $this->library)
		->where("l.Status=?2")
		->setParameter(2, true)
		->andWhere("l.Trash=?3")
		->setParameter(3, false)
		->andWhere("f.parentfolder=?4")
		->setParameter(4, $parentFolder)
		->andWhere("f.Del=?5")
		->setParameter(5, false)
		->andWhere("f.Folder_Name=?6")
		->setParameter(6, $folder);
		
		$results = $qb->getQuery()->getResult();
		
		if (!empty($results[0])){
			return $results[0];
		}
		else{
			return null;
		}
	}
	private function ftp_is_dir( $ftpHandle,  $root, $dir )
	{
		$size = ftp_size($ftpHandle, $root."/".$dir);
		
		if ($size===-1) {
			return true;
		}
		else{
			return false;
		}
	}
	/**
	 * Returns the text to the left of the search text
	 *
	 * @return String
	 */
	private function left($val,$search){
		if (\is_int($search)){
			if (strlen($val)<$search){
				return '';
			}
			else{
				return substr($val,0,$search);
			}
		}
		
		
		$pos = strpos($val,$search);
		if ($pos===false)
			return $val;
			else
				return substr($val, 0, $pos);
	}
	private function right($source,$target)
	{
		if (empty($source) || empty($target))
			return '';
			else{
				
				if (\is_int($target)){
					if (strlen($source)<$target)
						return '';
						else
							return \substr($source,strlen($source)-$target);
				}
				else if (strpos($source,$target)===false)
					return '';
					else
						return \substr($source, strpos($source,$target)+strlen($target));
			}
	}
	private function isValid($string)
	{
		return preg_match('//u', $string) === 1;
	}
	private function isUTF8($string) {
		return (utf8_encode(utf8_decode($string)) == $string);
	}
	private function importAttachments($document,$attachments,$field){		
		foreach($attachments as $attachment){
			if (empty($attachment) || !file_exists($attachment) ){
				continue;
			}			
			
			//determine the file modification time
			$dtFileModified = new \DateTime();
			$file_modified = filemtime($attachment);
			if (!empty($file_modified)){
				$dtFileModified->setTimestamp($file_modified);
			}
			
			//upload the file
			$this->uploadAttachedFile(basename($attachment), file_get_contents($attachment), $document,$dtFileModified,$field);
			
		}
	}
	private function uploadAttachedFile($file_name, $content, $document,\DateTime $dtModified=null, $field="default")	
	{	
				
		if (empty($file_name)){
			$this->log("uploadedAttachedFile() - No attachment name provided.  Orig: ".\json_encode($file_name));
			return;
		}

		if ($field === false) {
			if (!@is_dir($this->file_path.DIRECTORY_SEPARATOR.'Embedded'.DIRECTORY_SEPARATOR.$document->getId()))
			{
				@mkdir($this->file_path.DIRECTORY_SEPARATOR.'Embedded'.DIRECTORY_SEPARATOR.$document->getId(), 0666);
			}
			
			@chmod($this->file_path.DIRECTORY_SEPARATOR.'Embedded'.DIRECTORY_SEPARATOR.$document->getId(), '0777');
			$this->log("File Path: ".$this->file_path.DIRECTORY_SEPARATOR.'Embedded'.DIRECTORY_SEPARATOR.$document->getId().DIRECTORY_SEPARATOR.$file_name);
			
			file_put_contents($this->file_path.DIRECTORY_SEPARATOR.'Embedded'.DIRECTORY_SEPARATOR.$document->getId().DIRECTORY_SEPARATOR.$file_name, $content);
			
			@chmod($this->file_path.DIRECTORY_SEPARATOR.'Embedded'.DIRECTORY_SEPARATOR.$document->getId(), '0666');
			
			$local_file = $this->file_path.DIRECTORY_SEPARATOR.'Embedded'.DIRECTORY_SEPARATOR.$document->getId().DIRECTORY_SEPARATOR.$file_name;
			if (!empty($dtModified)){
				touch($local_file,$dtModified->getTimestamp());
			}
			$this->log("uploadAttachedFile - ".$file_name." as embedded attachment.");
		}
		else
		{
			if (!@is_dir($this->file_path.DIRECTORY_SEPARATOR.$document->getId().DIRECTORY_SEPARATOR))
			{
				@mkdir($this->file_path.DIRECTORY_SEPARATOR.$document->getId().DIRECTORY_SEPARATOR, 0666);
			}
			
			@chmod($this->file_path.DIRECTORY_SEPARATOR.$document->getId().DIRECTORY_SEPARATOR, '0777');
			file_put_contents($this->file_path.DIRECTORY_SEPARATOR.$document->getId().DIRECTORY_SEPARATOR.md5($file_name), $content);
			@chmod($this->file_path.DIRECTORY_SEPARATOR.$document->getId().DIRECTORY_SEPARATOR, '0666');
			
			$local_file = $this->file_path.DIRECTORY_SEPARATOR.$document->getId().DIRECTORY_SEPARATOR.md5($file_name);
			if (!empty($dtModified)){
				touch($local_file,$dtModified->getTimestamp());
			}
			
			$finfo = new \finfo(FILEINFO_MIME_TYPE);
			$mime_type = $finfo->buffer($content);
			$mime_type = (empty($mime_type)) ? 'application/octet-stream' : $mime_type;
			
			$file_size = '';
			$matches=null;
			if (preg_match('/Content-Length: (\d+)/', $content, $matches)) {
				$file_size = (int)$matches[1];
			}
			
			if (empty($file_size)){
				$file_size = filesize($this->file_path.DIRECTORY_SEPARATOR.$document->getId().DIRECTORY_SEPARATOR.md5($file_name));
			}
			unset($finfo, $matches);
			
			
			$temp = new AttachmentsDetails();
			$temp->setDocument($document);
			$temp->setField($field);
			$temp->setFileName(basename($file_name));
			
			if (!empty($dtModified)){
				$temp->setFileDate($dtModified);
			}
			else{
				$temp->setFileDate(new \DateTime());
			}
						
			$temp->setFileMimeType($mime_type);
			if (!empty($file_size)) {
				$temp->setFileSize($file_size);
			}
			$temp->setAuthor($document->getOwner());
			
			$this->em->persist($temp);
			$this->em->flush();
			
			
			unset($temp);
			$temp=null;
			unset($content);
			$content=null;
			
			$this->log("uploadAttachedFile - ".$file_name." as standard attachment.");
		}
		
			
		
	}
	
	private function importFields($document,$meta_data){
	    $this->log("Importing meta data");
	   
		$attachmentField = null;
		if (empty($document) || empty($meta_data)){
		    $this->log("No meta data available!");
			return;
		}
		$this->log( json_encode($meta_data,JSON_PRETTY_PRINT) );
		
			$doc_type = $document->getDocType();
			$subforms = $doc_type->getDocTypeSubform();
			$subformFields = $this->getSubformFields($subforms);
			
			$hasDocumentFields = false;
			foreach ($meta_data as $metaDataFieldName=>$metaDataFieldValue){
			  //  $this->log(PHP_EOL."Processing field: ".json_encode($metaDataFieldName)." value: ".json_encode($metaDataFieldValue).PHP_EOL);
				if ($this->isDocumentField($document, $metaDataFieldName)){
					$this->log(PHP_EOL."Processing Document field: ".$metaDataFieldName);
					try {
						$this->setDocumentField($document, $metaDataFieldName, $metaDataFieldValue);
						$hasDocumentFields=true;
						$this->log(PHP_EOL."DONE Processing Document field: ".$metaDataFieldName);
						
					} catch (\Exception $e) {
						$this->log(PHP_EOL."ERROR: ".$e->getMessage());
						$this->log(PHP_EOL."TRACE: ".PHP_EOL.$e->getTraceAsString());
						throw $e;
					}
				}
				else if ($this->isSubformField($subformFields, $metaDataFieldName)){
					//$this->log("Processing Subform field: ".$metaDataFieldName);					
					$fieldInfo = $subformFields[$metaDataFieldName];
					//$this->log("Field info: ".json_encode($fieldInfo));
					//$this->log("Field value: ".json_encode($metaDataFieldValue));
					
					//CUSTOM HANDLING FOR BillDate, set creation date to match
					if ($metaDataFieldName=="BillDate"){
					   
					    $dtLength =strlen($metaDataFieldValue);
					    if ($dtLength==10){
					        $dtBillDate = \DateTime::createFromFormat($this->DATE_FORMAT_SHORT, $metaDataFieldValue);
					    }
					    else if ($dtLength==19){
					        $dtBillDate = \DateTime::createFromFormat($this->DATE_FORMAT_FULL, $metaDataFieldValue);
					    }
					    
					    if (!empty($dtBillDate) && $dtBillDate instanceof \DateTime){
					       		    $document->setDateCreated($dtBillDate);
					               $hasDocumentFields=true;
					    }
					}
					$this->importSubformField($document, $fieldInfo['subform'], $fieldInfo['field'], $metaDataFieldName,$metaDataFieldValue);
				}
				else{
					$this->log("Warning: No field named ".$metaDataFieldName." could be located!");
				}
			}
			
			if (array_key_exists('mcsf_dliuploader1', $subformFields)){
				$attachmentField = $subformFields['mcsf_dliuploader1']['field'];
			}
			
			if ($hasDocumentFields){
				try{
					$this->em->getConnection()->beginTransaction();
					$this->em->persist($document);
					$this->em->flush();
					$this->em->commit();
				}
				catch (\Exception $e){
					$this->log("ERROR: ".$e->getTraceAsString());
					
					$isOpen = $this->em->isOpen();
					if ($isOpen){
						$this->em->getConnection()->rollBack();
						throw $e;
					}
					else{
					//	$this->resetManager();
						$this->em->getConnection()->rollBack();
						throw $e;
					}
				}
			}
			
			unset($subforms);
			$subforms = null;
			
			unset($subformFields);
			$subformFields=null;	
			
			unset($doc_type);
			$doc_type = null;
			
			$this->log("Processed meta-data fields.");
			return $attachmentField;
	}
	
	private function isSubformField($fields,$field){
		if (empty($fields) || !is_array($fields)){
			return false;
		}
		
		if (array_key_exists($field, $fields)){
			return true;
		}
		else{
			return false;
		}	
	}
	private function getSubformFields($subforms){
		$subformFields=array();
		
		foreach ($subforms as $sub)
		{
			$fields = $sub->getSubform()->getSubformFields();
			foreach ($fields as $field)
			{
				$fieldMetaData=array();
				$fieldMetaData['subform']=$sub->getSubform()->getFormName();
				$fieldMetaData['field']=$field;
				//$this->log('Checking field: '.$field->getFieldName()." in Subform:  ".$sub->getSubform()->getFormName());
				
				if ( !array_key_exists($field->getFieldName(), $subformFields) ){
					$subformFields[$field->getFieldName()]=$fieldMetaData;
				}
			}
		}
		return $subformFields;
	}
	private function setDocumentField($document,$fieldName,$fieldValue){
		//call the specified method
	//	echo PHP_EOL."Setting field [".$fieldName."] on document ".$document->getId()." to ".$fieldValue;
		
		$methodName = "set".$fieldName;
		if(method_exists($document,$methodName )){
			//echo PHP_EOL."Calling Method ".$methodName;
			call_user_func(array($document,$methodName),$fieldValue);
		}
		else{
			//echo PHP_EOL."Method ".$methodName." does not exist!";
		}
	}
	
	private function isDocumentField($document,$fieldName){
		//first check to see if we have a matching property on the document itself
		if (method_exists($document,"set".$fieldName)){
			return true;
		}
		else{
			return false;
		}
	}
	
	private function importSubformField($document,$subform,$metaDataField,$metaDataFieldName,$metaDataFieldValue) {
			
		
		//check to see if we have a matching field in the provided meta-data		
		//$this->log("Checking for field ".$metaDataFieldName." of subform ".$subform);
				
		if (!empty($metaDataFieldValue)){
			if ($metaDataField->getFieldType()==1  ){
				//date fields values
				$dataField = new FormDateTimeValues();				
				$dataField->setField($metaDataField);
				$dataField->setDocument($document);
				$dtLength =strlen($metaDataFieldValue);
				if ($dtLength==10){
				    $dtField = \DateTime::createFromFormat($this->DATE_FORMAT_SHORT, $metaDataFieldValue);
				}
				else if ($dtLength==19){
				    $dtField = \DateTime::createFromFormat($this->DATE_FORMAT_FULL, $metaDataFieldValue);
				}
				
				if (!empty($dtField) && $dtField instanceof \DateTime){
					$dataField->setFieldValue($dtField);
				}
				else{
				    $dataField = null;
				}
			}
			else{
				if ($metaDataField->getFieldType()==4 && is_numeric($metaDataFieldValue)){
					//Numeric field values
					$dataField = new FormNumericValues();
					$dataField->setField($metaDataField);
					$dataField->setDocument($document);
					$dataField->setFieldValue(floatval($metaDataFieldValue));
				}
				else{
					//Text field values (default)
					$dataField = new FormTextValues();
					$dataField->setField($metaDataField);
					$dataField->setDocument($document);
					//check the value format
					if ($this->isUTF8($metaDataFieldValue) || $this->isValid($metaDataFieldValue) ) {
						//no action required
					}
					else{
						$metaDataFieldValue=utf8_encode($metaDataFieldValue);
					}
					$dataField->setFieldValue($metaDataFieldValue);
				}
			}
		}
		else{
			//$this->log("No field mapping found for source target field: ".$field_name);
			//$this->log("Field ".$field_name. "=".$value);
			unset($dataField);
			return;
		}
		
		
		
		try {
			$this->em->getConnection()->beginTransaction();
			if (!empty($dataField)) {
				
				if (!empty($this->handler)){
					$continue = $this->handler->onFieldSave($this->em,$dataField);
					if (!$continue){
						return;
					}
				}
				$this->em->persist($dataField);
				$this->em->flush();				
			}
			$this->em->getConnection()->commit();
			
		}
		catch (\Exception $e){
			$val = $dataField->getFieldValue();
			if (empty($val))
				$val="";
				$this->log("General Error posting field value for field ".$metaDataFieldName." Value: ".$val." Error: ".$e->getTraceAsString());
				
				$isOpen = $this->em->isOpen();
				if ($isOpen){
					$this->em->getConnection()->rollBack();
				}
				else{
					$this->resetManager();
					$this->em->getConnection()->rollBack();
				}
					
				throw new \Exception("General Error posting field value for field ".$metaDataFieldName." Error: ".$e->getTraceAsString());
		}
	}
	
	private function log($action){
		if (!empty($this->logger)){
			$this->logger->log($action);			
		}
	}
	private static function getLogFileName() {
		$dateTime = new \DateTime ();
		$dateTime = $dateTime->format ( "Y-m-d" );
		
		return \str_replace ( '\\', '/', realpath ( __DIR__ . '/../' ) ) . "/logs/import_" . $dateTime . ".log";
		
	}
	
	private function getDocType($name){
		$folderRep = $this->em->getRepository('DocovaBundle:DocumentTypes');
		$qb = $folderRep->createQueryBuilder("f");
		$qb->select("f")	
		->where("f.Doc_Name=?1")
		->setParameter(1, $name);
		
		$results = $qb->getQuery()->getResult();
		
		if (!empty($results[0]))
			return $results[0];
			else
				throw new \Exception("The type ".$name." can not be located!");
	}
	private function getSEUser($name){
		$qb=$this->em->getRepository("DocovaBundle:UserAccounts")->createQueryBuilder("u");
		$qb->select("u")
		->where("u.username=?1")
		->setParameter(1, $name);
		$results = $qb->getQuery()->getResult();
		
		if (!empty($results[0]))
			return $results[0];
			else
				throw new \Exception("User ".$name." not available!");
	}
	private function getEntityManager(){
		
		if ((empty($this->em)))
			return  $this->getContainer()->get('doctrine')->getManager();
			else
				return $this->em;
	}
	private function getMiscellaneous(){
		if (empty($this->miscellaneous)){
			$this->miscellaneous=new Miscellaneous($this->container);
		}
		return $this->miscellaneous;
	}
	private function getCustomACL(){
		if (empty($this->customAcl)){
			$this->customAcl=new CustomACL($this->container);
		}
		return $this->customAcl;
	}
}

