document.write('<object id="DLIUploader1" style="border: 1px inset;width: 530px; height: 160px;"  ');
document.write('CLASSID="CLSID:155E724D-D3EE-4078-B226-871EF322E512" >');
document.write('<param name="SettingsXML" value="UploaderSettings">');
document.write('<div style="font: 12px Arial; color: red; border: 2 solid red; padding: 5; width: 95%;"> ');
document.write('DLI.Uploader ActiveX control is not loaded. Application will not run.<br><br> ');
document.write('Please make sure that the DLI.Uploader cabinet file is accessible for download  ');
document.write('from the web server at <Computed Value> and that your browser security  ');
document.write('settings allow download and installation of ActiveX controls.</div><br><br> ');
document.write('</OBJECT>');