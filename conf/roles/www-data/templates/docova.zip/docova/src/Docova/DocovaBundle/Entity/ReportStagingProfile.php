<?php

namespace Docova\DocovaBundle\Entity;
use Doctrine\ORM\Mapping as ORM;
use Doctrine\ORM\EntityRepository;
/**
 * ReportStagingProfile
 *
 * @ORM\Table(name="tb_report_staging_profile")
 * @ORM\Entity(repositoryClass="ReportStagingProfileRepository")
 */
class ReportStagingProfile {
/**
 * @ORM\Column(name="id", type="guid")
 * @ORM\Id
 * @ORM\GeneratedValue(strategy="UUID")
 */
protected $id;


/**
 * @var string
 *
 * @ORM\Column(name="Name", type="string", length=512, nullable=true)
 */
protected $Name;

/**
 * @var string
 *
 * @ORM\Column(name="Type", type="string", length=100, nullable=true)
 */
protected $Type;


/**
 * @var string
 *
 * @ORM\Column(name="RepositoryType", type="string", length=100, nullable=true)
 */
protected $RepositoryType;

/**
 * @var string
 *
 * @ORM\Column(name="ConnectionName", type="string", length=100, nullable=true)
 */
protected $ConnectionName;

/**
 * @var string
 *
 * @ORM\Column(name="TableName", type="string", length=255, nullable=true)
 */
protected $TableName;

/**
 * @var string
 *
 * @ORM\Column(name="TranslationType", type="string", length=255, nullable=true)
 */
protected $TranslationType;

/**
 * @var string
 *
 * @ORM\Column(name="Libraries", type="text", nullable=true)
 */
protected $Libraries;


/**
 * @var string
 *
 * @ORM\Column(name="Applications", type="text", nullable=true)
 */
protected $Applications;

/**
 * @ORM\Column(name="doc_type_id", type="guid", nullable=true) 
 */
protected $doc_type_id;


/**
 * @ORM\Column(name="app_form_id", type="guid", nullable=true)
  */
protected $app_form_id;


/**
 * @var string
 *
 * @ORM\Column(name="CriteriaFieldNames", type="string", nullable=true)
 */
protected $CriteriaFieldNames;

/**
 * @var string
 *
 * @ORM\Column(name="CriteriaFieldTypes", type="string", nullable=true)
 */
protected $CriteriaFieldTypes;

/**
 * @var string
 *
 * @ORM\Column(name="CriteriaFieldOperators", type="string", nullable=true)
 */
protected $CriteriaFieldOperators;


/**
 * @var string
 *
 * @ORM\Column(name="CriteriaFieldValues", type="string", nullable=true)
 */
protected $CriteriaFieldValues;

/**
 * @var string
 *
 * @ORM\Column(name="CreateTable", type="text",  nullable=true)
 */
protected $CreateTable;


/**
 * @var string
 *
 * @ORM\Column(name="DropTable", type="text",  nullable=true)
 */
protected $DropTable;


/**
 * @ORM\ManyToOne(targetEntity="DocumentTypes")
 * @ORM\JoinColumn(name="DocType", referencedColumnName="id", nullable=true)
 */
protected $DocType;


/**
 * @var string
 *
 * @ORM\Column(name="SourceFields", type="text",  nullable=true)
 */
protected $SourceFields;

/**
 * @var string
 *
 * @ORM\Column(name="DestinationFields", type="text",  nullable=true)
 */
protected $DestinationFields;

/**
 * @var string
 *
 * @ORM\Column(name="ValueExpressions", type="text", nullable=true)
 */
protected $ValueExpressions;

/**
 * @var string
 *
 * @ORM\Column(name="SourceFieldsMultiValued", type="text",  nullable=true)
 */
protected $SourceFieldsMultiValued;

/**
 * @var string
 *
 * @ORM\Column(name="UpdateFrequency", type="string", length=255, nullable=true)
 */
protected $UpdateFrequency;

/**
 * @var \DateTime
 *
 * @ORM\Column(name="LastRunDate", type="datetime", nullable=true)
 */
protected $LastRunDate;

/**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

/**
     * @return string
     */
    public function getName()
    {
        return $this->Name;
    }

/**
     * @return string
     */
    public function getType()
    {
        return $this->Type;
    }

/**
     * @return string
     */
    public function getConnectionName()
    {
        return $this->ConnectionName;
    }

/**
     * @return string
     */
    public function getTableName()
    {
        return $this->TableName;
    }

/**
     * @return string
     */
    public function getTranslationType()
    {
        return $this->TranslationType;
    }

/**
     * @return string
     */
    public function getLibraries()
    {
        return explode(PHP_EOL,$this->Libraries);
    }

/**
     * @return string
     */
    public function getApplications()
    {
        return $this->Applications;
    }

/**
     * @return mixed
     */
    public function getDoc_type_id()
    {
        return $this->doc_type_id;
    }

/**
     * @return mixed
     */
    public function getApp_form_id()
    {
        return $this->app_form_id;
    }

/**
     * @return string
     */
    public function getCriteriaFieldNames()
    {
        if (empty($this->CriteriaFieldNames)){
            return $this->CriteriaFieldNames;
        }
        return explode(PHP_EOL,$this->CriteriaFieldNames);
    }

/**
     * @return string
     */
    public function getCriteriaFieldTypes()
    {
        if (empty($this->CriteriaFieldTypes)){
            return $this->CriteriaFieldTypes;
        }
        return explode(PHP_EOL,$this->CriteriaFieldTypes);
    }

/**
     * @return string
     */
    public function getCriteriaFieldOperators()
    {
        if (empty($this->CriteriaFieldOperators)){
            return $this->CriteriaFieldOperators;
        }
        return explode(PHP_EOL,$this->CriteriaFieldOperators);
    }

/**
     * @return string
     */
    public function getCriteriaFieldValues()
    {
        if (empty($this->CriteriaFieldValues)){
            return $this->CriteriaFieldValues;
        }
        return explode(PHP_EOL,$this->CriteriaFieldValues);
    }

/**
     * @return string
     */
    public function getCreateTable()
    {
        return $this->CreateTable;
    }

/**
     * @return string
     */
    public function getDropTable()
    {
        return $this->DropTable;
    }

/**
     * @return mixed
     */
    public function getDocType()
    {
        return $this->DocType;
    }

/**
     * @return string
     */
    public function getSourceFields()
    {
        if (empty($this->SourceFields)){
            return array();
        }
        else{
            return explode(PHP_EOL.PHP_EOL,$this->SourceFields);
        }
    }

/**
     * @return string
     */
    public function getDestinationFields()
    {
        if (empty($this->DestinationFields)){
            return array();
        }
        else{
            return explode(PHP_EOL,$this->DestinationFields);
        }
    }

/**
     * @return string
     */
    public function getValueExpressions()
    {
        if (empty($this->ValueExpressions)){
            return array();
        }
        else{
            return explode(PHP_EOL,$this->ValueExpressions);
        }
        
    }

/**
     * @return string
     */
    public function getSourceFieldsMultiValued()
    {
        if (empty($this->SourceFieldsMultiValued)){
            return array();
        }
        else{
            return explode(PHP_EOL,$this->SourceFieldsMultiValued);
        }
        
    }

/**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

/**
     * @param string $Name
     */
    public function setName($Name)
    {
        $this->Name = $Name;
    }

/**
     * @param string $Type
     */
    public function setType($Type)
    {
        $this->Type = $Type;
    }

/**
     * @param string $ConnectionName
     */
    public function setConnectionName($ConnectionName)
    {
        $this->ConnectionName = $ConnectionName;
    }

/**
     * @param string $TableName
     */
    public function setTableName($TableName)
    {
        $this->TableName = $TableName;
    }

/**
     * @param string $TranslationType
     */
    public function setTranslationType($TranslationType)
    {
        $this->TranslationType = $TranslationType;
    }

/**
     * @param string $Libraries
     */
    public function setLibraries($Libraries)
    {
        $this->Libraries = $Libraries;
    }

/**
     * @param string $Applications
     */
    public function setApplications($Applications)
    {
        $this->Applications = $Applications;
    }

/**
     * @param mixed $doc_type_id
     */
    public function setDoc_type_id($doc_type_id)
    {
        $this->doc_type_id = $doc_type_id;
    }

/**
     * @param mixed $app_form_id
     */
    public function setApp_form_id($app_form_id)
    {
        $this->app_form_id = $app_form_id;
    }

/**
     * @param string $CriteriaFieldNames
     */
    public function setCriteriaFieldNames($CriteriaFieldNames)
    {
        $this->CriteriaFieldNames = $CriteriaFieldNames;
    }

/**
     * @param string $CriteriaFieldTypes
     */
    public function setCriteriaFieldTypes($CriteriaFieldTypes)
    {
        $this->CriteriaFieldTypes = $CriteriaFieldTypes;
    }

/**
     * @param string $CriteriaFieldOperators
     */
    public function setCriteriaFieldOperators($CriteriaFieldOperators)
    {
        $this->CriteriaFieldOperators = $CriteriaFieldOperators;
    }

/**
     * @param string $CriteriaFieldValues
     */
    public function setCriteriaFieldValues($CriteriaFieldValues)
    {
        $this->CriteriaFieldValues = $CriteriaFieldValues;
    }

/**
     * @param string $CreateTable
     */
    public function setCreateTable($CreateTable)
    {
        $this->CreateTable = $CreateTable;
    }

/**
     * @param string $DropTable
     */
    public function setDropTable($DropTable)
    {
        $this->DropTable = $DropTable;
    }

/**
     * @param mixed $DocType
     */
    public function setDocType($DocType)
    {
        $this->DocType = $DocType;
    }

/**
     * @param string $SourceFields
     */
    public function setSourceFields($SourceFields)
    {
        $this->SourceFields = $SourceFields;
    }

/**
     * @param string $DestinationFields
     */
    public function setDestinationFields($DestinationFields)
    {
        $this->DestinationFields = $DestinationFields;
    }

/**
     * @param string $ValueExpressions
     */
    public function setValueExpressions($ValueExpressions)
    {
        $this->ValueExpressions = $ValueExpressions;
    }

/**
     * @param string $SourceFieldsMultiValued
     */
    public function setSourceFieldsMultiValued($SourceFieldsMultiValued)
    {
        $this->SourceFieldsMultiValued = $SourceFieldsMultiValued;
    }
    /**
     * @return string
     */
    public function getSyncFrequency()
    {
        return $this->SyncFrequency;
    }

    /**
     * @return string
     */
    public function getManualSync()
    {
        return $this->ManualSync;
    }

    /**
     * @param string $SyncFrequency
     */
    public function setSyncFrequency($SyncFrequency)
    {
        $this->SyncFrequency = $SyncFrequency;
    }

    /**
     * @param string $ManualSync
     */
    public function setManualSync($ManualSync)
    {
        $this->ManualSync = $ManualSync;
    }
    /**
     * @return string
     */
    public function getRepositoryType()
    {
        return $this->RepositoryType;
    }

    /**
     * @param string $RepositoryType
     */
    public function setRepositoryType($RepositoryType)
    {
        $this->RepositoryType = $RepositoryType;
    }
    /**
     * @return string
     */
    public function getUpdateFrequency()
    {
        return $this->UpdateFrequency;
    }

    /**
     * @return \DateTime
     */
    public function getLastRunDate()
    {
        return $this->LastRunDate;
    }

    /**
     * @param string $UpdateFrequency
     */
    public function setUpdateFrequency($UpdateFrequency)
    {
        $this->UpdateFrequency = $UpdateFrequency;
    }

    /**
     * @param \DateTime $LastRunDate
     */
    public function setLastRunDate($LastRunDate)
    {
        $this->LastRunDate = $LastRunDate;
    }

}