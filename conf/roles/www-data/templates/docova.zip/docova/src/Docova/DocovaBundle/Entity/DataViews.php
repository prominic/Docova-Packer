<?php

namespace Docova\DocovaBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * DataViews
 *
 * @ORM\Table(name="tb_data_views")
 * @ORM\Entity(repositoryClass="Docova\DocovaBundle\Entity\DataViewsRepository")
 */
class DataViews
{
    protected $perspectiveColumns=array();
    
    /**
     * @ORM\Column(name="id", type="guid")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     */
    protected $id;

    /**
     * @var string
     *
     * @ORM\Column(name="Name", type="string", length=100)
     */
    protected $Name;
    
    /**
     * @var string
     *
     * @ORM\Column(name="FormName", type="string", length=255,nullable=true)
     */
    protected $FormName;

    /**
     * @var string
     *
     * @ORM\Column(name="Folder_Id", type="string", length=36, nullable=true)
     */
    protected $Folder_Id;
    /**
     * @var string
     *
     * @ORM\Column(name="Folder_Link", type="string", length=255, nullable=false)
     */
    protected $Folder_Link;

    /**
     * @var string
     *
     * @ORM\Column(name="Data_Source_Name", type="string", length=100, nullable=false)
     */
    protected $Data_Source_Name;
    
    
    /**
     * @var \DateTime
     *
     * @ORM\Column(name="Date_Created", type="datetime")
     */
    protected $Date_Created;

    /**
     * @var string
     *
     * @ORM\Column(name="SQL_Filter", type="string", nullable=true)
     */
    protected $SQL_Filter;

    /**
     * @ORM\Column(name="app_id", type="guid",nullable=true)          
     */
    protected $app_id;
    
    /**
     * @var string
     *
     * @ORM\Column(name="Permissions", type="string", length=12,nullable=true)
     */
    protected $Permissions;

    /**
     * @var string
     *
     * @ORM\Column(name="Storage", type="string", length=12,nullable=true)
     */
    protected $Storage;
    
    
    /**
     * @var string
     *
     * @ORM\Column(name="StorageFields", type="string", length=2048,nullable=true)
     */
    protected $StorageFields;
    
    /**
     * @var string
     *
     * @ORM\Column(name="CreateLabel", type="string", length=50,nullable=true)
     */
    protected $CreateLabel;
    
    /**
     * @var string
     *
     * @ORM\Column(name="FormLabel", type="string", length=50,nullable=true)
     */
    protected $FormLabel;
    
    /**
     * @var string
     *
     * @ORM\Column(name="DOCOVAIntegrated", type="string", length=7,nullable=true)
     */
    protected $DOCOVAIntegrated;
    
    /**
     * Get id
     *
     * @return string 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set Name
     *
     * @param string $Name
     * @return DataViews
     */
    public function setName($Name)
    {
        $this->Name = $Name;
    
        return $this;
    }

    /**
     * Get File_Name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->Name;
    }

    /**
     * Set Folder_Link
     *
     * @param string $Name
     * @return DataViews
     */
    public function setFolderLink($link)
    {
    	$this->Folder_Link = $link;
    
    	return $this;
    }
    
    /**
     * Get Folder_Link
     *
     * @return string
     */
    public function getFolderLink()
    {
    	return $this->Folder_Link;
    }
    /**
     * Set Folder_Id
     *
     * @param string $id
     * @return DataViews
     */
    public function setFolderId($id)
    {
    	$this->Folder_Id = $id;
    
    	return $this;
    }
    
    /**
     * Get Folder_Id
     *
     * @return string
     */
    public function getFolderId()
    {
    	return $this->Folder_Id;
    }
    /**
     * Set Data Source Name
     *
     * @param string $DataSourceName
     * @return DataViews
     */
    public function setDataSourceName($Name)
    {
    	$this->Data_Source_Name = $Name;
    
    	return $this;
    }
    
    /**
     * Get File_Name
     *
     * @return string
     */
    public function getDataSourceName()
    {
    	return $this->Data_Source_Name;
    }
    

    /**
     * Set Date_Created
     *
     * @param \DateTime $dateCreated
     * @return FileResources
     */
    public function setDateCreated($dateCreated)
    {
        $this->Date_Created = $dateCreated;
    
        return $this;
    }

    /**
     * Get Date_Created
     *
     * @return \DateTime 
     */
    public function getDateCreated()
    {
        return $this->Date_Created;
    }
	
    public function getDataSource($em)
    {
    	return $em->getRepository("DocovaBundle:DataSources")->getDataSource($this->getDataSourceName());
    }
	public function getSQLFilter() {
		if (empty($this->SQL_Filter))
			return "";
		return $this->SQL_Filter;
	}
	public function setSQLFilter($SQL_Filter) {
		$this->SQL_Filter = $SQL_Filter;
		return $this;
	}
    /**
     * @return mixed
     */
    public function getAppId()
    {
        return $this->app_id;
    }

    /**
     * @param mixed $app_id
     */
    public function setAppId($app_id)
    {
        $this->app_id = $app_id;
    }
    
    /**
     * @return string
     */
    public function getPermissions()
    {
        return $this->Permissions;
    }
    
    /**
     * @return string
     */
    public function getCreateLabel()
    {
        return $this->CreateLabel;
    }

    /**
     * @param string $CreateLabel
     */
    public function setCreateLabel($CreateLabel)
    {
        $this->CreateLabel = $CreateLabel;
    }

    /**
     * @return string
     */
    public function getFormLabel()
    {
        return $this->FormLabel;
    }

    /**
     * @param string $FormLabel
     */
    public function setFormLabel($FormLabel)
    {
        $this->FormLabel = $FormLabel;
    }

    public function canCreate(){
        $permissions = $this->getPermissionsList();        
        if (array_key_exists('C', $permissions)){
            return true;
        }
        else{
            return false;
        }
    }
    public function canRead(){
        $permissions = $this->getPermissionsList();
        if (array_key_exists('R', $permissions)){
            return true;
        }
        else{
            return false;
        }
    }
    public function canUpdate(){
        $permissions = $this->getPermissionsList();
        if (array_key_exists('U', $permissions)){
            return true;
        }
        else{
            return false;
        }
    }
    public function canDelete(){
        $permissions = $this->getPermissionsList();
        
        if (array_key_exists('D', $permissions)){
            return true;
        }
        else{
            return false;
        }
    }
    public function getPermissionsList()
    {
        //split the permissions out into an array
        $p = $this->Permissions;
        $permissions=array();
        if (empty($p)){
            return $permissions;
        }
        else{
            $plen = strlen($p);
            for($i=0;$i<$plen;$i++){
                $permissions[$p[$i]]=$p[$i];
            }
            return $permissions;
        }
        
    }
    /**
     * @param string $Permissions
     */
    public function setPermissions($Permissions)
    {
        $this->Permissions = $Permissions;
    }

    /**
     * @return string
     */
    public function getDOCOVAIntegrated()
    {
        return $this->DOCOVAIntegrated;
    }

    /**
     * @param string $DOCOVAIntegrated
     */
    public function setDOCOVAIntegrated($DOCOVAIntegrated)
    {
        $this->DOCOVAIntegrated = $DOCOVAIntegrated;
    }

    //volatile
    public function getPerspectiveColumns(){
        return $this->perspectiveColumns;        
    }
    //volatile
    public function setPerspectiveColumns(\DOMDocument $perspective){
        if (empty($perspective)){
            return array();
        }
        else{
            //read the node names
            foreach ($perspective->getElementsByTagName('xmlNodeName') as $index => $node) {
                $this->perspectiveColumns[]=$node->nodeValue;
            }
            $fieldNames = array();
            foreach ($perspective->getElementsByTagName('translatedFormula') as $index => $node) {
                $matches=null;
                if (preg_match('/f_GetField\(\"([A-Za-z0-9\_\$]*)\"\)/', $node->nodeValue, $matches)) {
                    $fieldNames[]=strtolower($matches[1]);
                }
                else{
                    //echo "Index: ".$index. ", Column: ".$this->perspectiveColumns[$index];
                    $fieldNames[]=strtolower(str_replace('CF','',$this->perspectiveColumns[$index]));                
                }
            }
            $this->perspectiveColumns=$fieldNames;
        }
    }
 public function generatePerspectiveColumn($column_name,$column_node_name,$column_data_type){ 
      $column_name = str_replace(PHP_EOL,'',$column_name);
	  $column_name = str_replace('\n','',$column_name);
 
          $XML = <<< XML
<column>
<isCategorized/>
<hasCustomSort>0</hasCustomSort>
<totalType>0</totalType>
<isFrozen/>
<isFreezeControl/>
<title><![CDATA[$column_name]]></title>
<xmlNodeName>$column_node_name</xmlNodeName>
<dataType>$column_data_type</dataType>
<isMobileTitle/>
<isMobileDetail/>
<showResponses/>
<showMultiAsSeparate/>
<responseFormula><![CDATA[]]></responseFormula>
<isHidden/>
<entryType><![CDATA[S]]></entryType>
<formName><![CDATA[null]]></formName>
<formField><![CDATA[null]]></formField>
<columnFormula><![CDATA[$column_name]]></columnFormula>
<translatedFormula><![CDATA[{% docovascript "variable:array" %}{{ f_GetField("$column_name") }}{% enddocovascript %}]]></translatedFormula>
<sortOrder>none</sortOrder>
<customSortOrder>none</customSortOrder>
<numberFormat>###.##;-###.##</numberFormat>
<numberPrefix/>
<numberSuffix/>
<numberBlankFormat/>
<dateFormat/>
<width>125</width>
<align/>
<fontSize/>
<fontFamily/>
<color/>
<fontWeight/>
<fontStyle/>
<textDecoration/>
<backgroundColor/>
<alignT/>
<fontSizeT/>
<fontFamilyT/>
<colorT>#0000ff</colorT>
<fontWeightT>bold</fontWeightT>
<fontStyleT/>
<textDecorationT/>
<backgroundColorT/>
<alignH/>
<fontSizeH/>
<fontFamilyH/>
<colorH/>
<fontWeightH/>
<fontStyleH/>
<textDecorationH/>
<backgroundColorH/>
</column>
XML;
return $XML;
	}
	
	public function generateAppView($em,$application,$viewName,$fields,$owner){
	    
	    $appView = new \Docova\DocovaBundle\Entity\AppViews();
	    $appView->setApplication($application);
	    $appView->setAutoCollapse(false);
	    $appView->setConvertedQuery("");
	    $appView->setCreatedBy($owner);
	    $appView->setDataView($this->getName());
	    
	    $dt = new \DateTime();
	    $appView->setDateCreated($dt);
	    $appView->setDateModified($dt);    
	    $appView->setEmulateFolder(false);
	    $appView->setEnablePaging(true);
	    $appView->setFirstDay(true);	    
	    $appView->setModifiedBy($owner);
	    $appView->setOpenInEdit(false);
	    $appView->setRespHierarchy(false);
	    $appView->setPrivateOnFirstUse(false);
	    $appView->setPDU(false);
	    $appView->setStyle(false);
	    $appView->setShowSelection(true);
	    $appView->setViewAlias($viewName);
	    $appView->setViewFtSearch(true);
	    $appView->setViewName($viewName);
	    $appView->setWeekends(false);
	    $appView->setConvertedQuery('{{ f_GetField("Form")===\'Enter Form Name\' }}');
	    
	    $viewPerspective = $this->generatePerspective($fields);	    
	    $appView->setViewPerspective($viewPerspective);
	    
	    $appView->setViewQuery("SELECT Form='Enter Form Name'");
	    $appView->setViewType("Standard");
	 	    
	    if ($this->canCreate()){
	        $this->generateAppViewCreateAction($application->getId(), str_replace(' ','',$viewName), $this->getCreateLabel());
	    }
	    
	    $em->persist($appView);
	    
	   
	    
	    $em->flush();
	    
	    
	    
	}
    public function generatePerspective(array $fields){
	
	if (empty($fields)){
	   throw new \Exception("Column names must be provided!");   
	}
	
	//Compute the xml and script for the the columns
	$columns="";
	$columns_script="";
	$columnNumber=0;
	foreach($fields as $field){
	    $columnNumber++;
	    if ($columnNumber!=1){
	        $columns_script.=", ";
	        $columns.=", ";
	    }
	    $columns_script .= $this->getFieldFormula($field);
	    $col="CF".($columnNumber-1);	    
	    $columns .= $this->generatePerspectiveColumn($field, $col, "text");
	}
	$XML = <<< XML
<?xml version="1.0"?>
<viewperspective>
<viewsettings>
<viewproperties>
<showSelectionMargin>1</showSelectionMargin>
<allowCustomization>1</allowCustomization>
<extendLastColumn/>
<isSummary/>
<responseColspan>2</responseColspan>
<isThumbnails/>
<categoryBorderStyle>border-bottom : solid 2px #aaccff;</categoryBorderStyle>
<categoryExpandClass>fa-arrow-circle-down</categoryExpandClass>
<categoryCollapseClass>fa-arrow-circle-right</categoryCollapseClass>
<categoryIconSize>14px</categoryIconSize>
</viewproperties>
<columnsscript><![CDATA[{ $columns_script }] }]]></columnsscript>
<columns>
	$columns
</columns>
</viewsettings>
</viewperspective>
XML;
	return $XML;
  }
  private function getFieldFormula($field){
$XML = <<< XML
      {% docovascript "variable:array" %}{{ f_GetField("$field") }}{% enddocovascript %}
XML;
  return $XML;
  }
  private function getSourcePath(){
      //the bundle source directory is located 1 directories above the current script path
      return str_replace('\\', '/', realpath(__DIR__.'/../'));
  }
  private function generateAppViewCreateAction($applicationId,$appViewName){
      $appViewActionPath = $this->getSourcePath()."/Resources/views/DesignElements/".$applicationId."/templates/VIEW/";
      if (!file_exists($appViewActionPath)){
          mkdir($appViewActionPath);
      }
      $appViewActionPathTemplate = $appViewActionPath .$appViewName.".html.twig";
      $toolbarPath = $this->getSourcePath()."/Resources/views/DesignElements/".$applicationId."/toolbar/";
      if (!file_exists($toolbarPath)){
          mkdir($toolbarPath);
      }
      $appViewActionPath = $toolbarPath.$appViewName.".html.twig";
      $appViewCreateActionTemplate = $this->getAppViewCreateActionTemplate( (empty($this->getCreateLabel()) ? 'New Document': $this->getCreateLabel()) );
      file_put_contents($appViewActionPathTemplate,$appViewCreateActionTemplate);
      
      $appViewCreateAction = $this->getAppViewCreateAction( (empty($this->getCreateLabel()) ? 'New Document': $this->getCreateLabel()) );
      file_put_contents($appViewActionPath,$appViewCreateAction);
  }
  private function getAppViewCreateActionTemplate($createLabel){
     $createAction = <<< createAction
     <button title="$createLabel" class="ui-button ui-widget ui-state-default ui-corner-all ui-button-text-icon-primary" role="button" onclick="
var docUrl = docInfo.PortalWebPath+'/wViewForm/'+docInfo.externalViewForm+'?AppID='+docInfo.AppID+'&ExternalDataView='+docInfo.externalView+'&Seq=1&typekey=external';
window.parent.fraTabbedTable.objTabBar.CreateTab(&amp;quot;$createLabel&amp;quot;, &amp;quot;NewExternalDocument_&amp;quot;+docInfo.DocID, &amp;quot;D&amp;quot;, docUrl, docInfo.DocID, true);" type="button" iconright="" iconleft="ui-icon-refresh" hidewhen="" customhidewhen="" showlabel="1" actiontype="Custom" actiondoctype="-Select-"><span class="ui-button-icon-primary ui-icon ui-icon-document"></span><span class="ui-button-text">$createLabel</span></button>
createAction;
     return $createAction;
  }

private function getAppViewCreateAction($createLabel){
    $createAction = <<< createAction
    <button onclick="
var docUrl = docInfo.PortalWebPath+'/wViewForm/'+docInfo.externalViewForm+'?AppID='+docInfo.AppID+'&ExternalDataView='+docInfo.externalView+'&Seq=1&typekey=external';
window.parent.fraTabbedTable.objTabBar.CreateTab(&quot;$createLabel&quot;, &quot;NewExternalDocument_&quot;+docInfo.DocID, &quot;D&quot;, docUrl, docInfo.DocID, true);" iconleft="ui-icon-document" iconright="" title="$createLabel"></button>
createAction;
     return $createAction;
  }
  public function hasForm($formName){
      if (!file_exists($this->getSourcePath()."/Resources/views/Form/")){
          mkdir($this->getSourcePath()."/Resources/views/Form/");
      }
      $formPath = $this->getSourcePath()."/Resources/views/Form/".$formName."_read.html.twig";
      if (file_exists($formPath)){
          return true;
      }
      else{
          return false;
      }
  }
  public function generateForm($formName,array $fieldNames,$readMode){
      $formFieldRows = "";      
      foreach($fieldNames as $fieldName){
          if ($readMode){
                      
           $formRow = PHP_EOL.$this->getReadFormFieldRow($fieldName);           
            $formFieldRows.=$formRow;            
          }
          else{
            
            $formRow = PHP_EOL.$this->getEditFormFieldRow($fieldName);            
            $formFieldRows.=$formRow;
          }
      }
      
      if ($readMode===true){       
          $form = $this->getReadForm($formFieldRows);
          $formPath = $this->getSourcePath()."/Resources/views/Form/".$formName."_read.html.twig";
         
          file_put_contents($formPath,$form);
          
      }
      else{
          $form = $this->getEditForm($formFieldRows);
          $formPath = $this->getSourcePath()."/Resources/views/Form/".$formName."_edit.html.twig";
          
          file_put_contents($formPath,$form);          
      }
      
  }
  
  /**
     * @return string
     */
    public function getFormName()
    {
        return $this->FormName;
    }

/**
     * @param string $FormName
     */
    public function setFormName($FormName)
    {
        $this->FormName = $FormName;
    }

    
/**
     * @return string
     */
    public function getStorage()
    {
        return $this->Storage;
    }

    /**
     * @return string
     */
    public function getStorageFields()
    {
        return $this->StorageFields;
    }

    /**
     * @param string $Storage
     */
    public function setStorage($Storage)
    {
        $this->Storage = $Storage;
    }

    /**
     * @param string $StorageFields
     */
    public function setStorageFields($StorageFields)
    {
        $this->StorageFields = $StorageFields;
    }

private function getReadFormFieldRow($fieldName){
      $row = <<< ROW
        <tr>
			<td><b>$fieldName:&nbsp;&nbsp;&nbsp;</b></td>
			<td>{{ data['$fieldName'] is defined ? data['$fieldName']}}</td>
		</tr>
ROW;
      return $row;
  }
  private function getEditFormFieldRow($fieldName){
     $row = <<< ROW
        <tr>
			<td><b>$fieldName:&nbsp;&nbsp;&nbsp;</b></td>
			<td><input type="text" name="$fieldName" value="{{ document['$fieldName'] is defined ? document['$fieldName'] }}" {{ dataSource.getSQLKeyGenType()!='None' and '$fieldName'==keyName ? "disabled " }}class="FIELD MAIN_FONT" /></td>
		</tr>
ROW;
    return $row;     
  }
  private function getEditForm($fieldRows){
      $form = <<< FORM
{% include 'DocovaBundle:Form:Template-External_edit.html.twig' %}
<form method="post" action="{{ path('docova_editdocument', {'doc_id' : doc_id}) }}?editDocument{{ app.request.query.get("mode") ? '&mode=' ~ app.request.query.get("mode") : '' }}&D={{ folderId }}&DataView={{ dataViewId }}&amp;Seq=1&amp;typekey=external" enctype="multipart/form-data" name="_Document">
  <body scroll="No" style="align:top;background-color:white;">
	<ul class="ui-widget-header actionBar hidetoload" style="margin-left:0px;padding-left:0px;margin-top:2px;">
		<li id="saveBtn" href="javascript:{window.forms[0].submit()}" >{% trans %}Save{% endtrans %}</li>
		<li id="closeBtn">{% trans %}Close{% endtrans %}</li>
	</ul>
	<h3 class="TITLE">{{ viewTitle }}</h3>
<hr style="color:rgb(92,134,197);height:2px;"/>
	<table border=0 class="MAIN_FONT">
		$fieldRows
	</table>
	<input type="hidden" name="DataView" value="{{ dataViewId }}"/>	
	<input id="submit" type="submit" value="Save" style="display:none;"/>	
	<br/>
  </body>		
</form>
</html>
FORM;
      return $form;
  }
  private function getReadForm($fieldRows){
      $form = <<< FORM
{% include 'DocovaBundle:Form:Template-External_read.html.twig' %}
<body scroll="No" style="align:top;background-color:white;">
    <ul class="ui-widget-header actionBar" style="margin-left:0px;padding-left:0px;margin-top:2px;">
        {% if canEdit %}
    	    <a id="editBtn" href="{{ path('docova_editdocument', { 'view_name' : (viewName is defined ? viewName : viewTitle), 'doc_id' : doc_id }) }}?editDocument{{ app.request.query.get("mode") ? '&mode=' ~ app.request.query.get("mode") : '' }}&DataView={{ dataViewId }}&amp;Seq=1&amp;typekey=external" >{% trans %}Edit{% endtrans %}</a>
        {% endif %}
    	<li id="closeBtn">{% trans %}Close{% endtrans %}</li>
    </ul>
    <h3 class="TITLE">{{ viewTitle }}</h3>
    <hr style="color:rgb(92,134,197);height:2px;"/>	
    <table border=0 class="MAIN_FONT">
    	$fieldRows
    </table>
</body>
<br/>
</html>
FORM;
      return $form;
  }
  
}
