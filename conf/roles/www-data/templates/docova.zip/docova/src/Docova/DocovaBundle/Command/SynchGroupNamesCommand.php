<?php
namespace Docova\DocovaBundle\Command;

use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Docova\DocovaBundle\Security\User\adLDAP;
use Doctrine\ORM\Query;

/**
 * Command to synch group names base on groupObjectGUID key in AD
 * @author javad rahimi
 *        
 */
class SynchGroupNamesCommand extends ContainerAwareCommand 
{
	private $_em;
	private $_ldap;
	private $groupKey;
	private $oldGuid;
	
	protected function configure()
	{
		$this->setName('docova:synchgroupnames')
			->setDescription('Auto synch group names base on objectGUID key in AD.');
	}
	
	protected function execute(InputInterface $input, OutputInterface $output)
	{
		$this->groupKey = $this->getContainer()->hasParameter('ldap_groupkey') ? $this->getContainer()->getParameter('ldap_groupkey') : null;
		$this->oldGuid = $this->getContainer()->hasParameter('ldap_oldguidkey') ? $this->getContainer()->getParameter('ldap_oldguidkey') : null;
		if (empty($this->groupKey) || empty($this->oldGuid)) {
			$output->writeln('ldap_groupkey / ldap_oldguidkey is not set or defined in configuration; synch process is stopped.');
			return false;
		}
		
		$this->_em = $this->getContainer()->get('Doctrine')->getManager();
		$global_settings = $this->_em->getRepository('DocovaBundle:GlobalSettings')->createQueryBuilder('GS')
			->select(array('GS.LDAP_Directory', 'GS.LDAP_Port', 'GS.ldapBaseDn'))
			->setMaxResults(1)
			->getQuery()
			->getSingleResult(Query::HYDRATE_ARRAY);
			
		$this->_ldap = new adLDAP(array(
			'domain_controllers' => $global_settings['LDAP_Directory'],
			'domain_port' => $global_settings['LDAP_Port'],
			'base_dn' => $global_settings['ldapBaseDn'],
			'ad_username' => $this->getContainer()->getParameter('ldap_username'),
			'ad_password' => $this->getContainer()->getParameter('ldap_password')
		));
		
		$groups = $this->_em->getRepository('DocovaBundle:UserRoles')->findBy(array('Group_Type' => true));
		
		$not_synched_groups = array();
		if (!empty($groups))
		{
			foreach ($groups as $g)
			{
				if ($g->getAdKey())
				{
					if (false !== $groupInfo = $this->searchGroupByGuid($g->getAdKey())) {
						$groupname = key(array_keys($groupInfo));
						$changed = false;
						if ($groupInfo[$groupname][$this->oldGuid] == $g->getAdKey() && !empty($groupInfo[$groupname][$this->groupKey]) && $g->getAdKey() != $groupInfo[$groupname][$this->groupKey])
						{
							$g->setAdKey($groupInfo[$groupname][$this->groupKey]);
							$changed = true;
						}
						if (!empty($groupname) && $groupname != $g->getGroupName())
						{
							$g->setGroupName($groupname);
							$g->setDisplayName($groupname);
							$changed = true;
						}
						if ($changed === true)
						{
							$this->_em->flush();
						}
					}
				}
				elseif (false !== $adKey = $this->fetchGroupKey($g->getGroupName()))
				{
					$g->setAdKey(key($adKey));
					$g->setDisplayName(current($adKey));
					//$g->setGroupName(current($adKey));
					$this->_em->flush();
				}
				else {
					$not_synched_groups[$g->getId()] = $g->getGroupName();
				}
			}
			
			if (!empty($not_synched_groups) && count($not_synched_groups))
			{
				$x = 0;
				$output->writeln('Following groups were not synched because not match key/group name were found. May need a manual update.');
				foreach ($not_synched_groups as $id => $group)
				{
					$output->writeln(($x+1).". Group ID \"$id\", Group Name \"$group\"");
					$x++;
				}
			}
		}
		else {
			$output->writeln('No LDAP/AD group found in database!');
		}
	}
	
	/**
	 * Search for a group by GUID and return group info
	 * 
	 * @param string $groupkey
	 * @return array|boolean
	 */
	private function searchGroupByGuid($groupkey)
	{
		$info = array();
		$filter = '(&(|(objectcategory=group)(objectclass=dominoGroup))';
		$filter .= "({$this->groupKey}={$groupkey}))";
		$attributes = array($this->groupKey, $this->oldGuid, 'displayname', 'cn', 'samaccountname');
		$group = $this->_ldap->group_info(null, $attributes, $filter);
		//$group = $this->_ldap->search_groups(null, false, '', true, $filter, $attributes);
		if (!empty($group['count']) && strval($group['count']) === '1') {
			$gname = (!empty($group[0]['displayname']) ? $group[0]["displayname"][0] : (!empty($group[0]['cn']) ? $group[0]['cn'][0] : $group[0]['samaccountname'][0]));
			$info[$gname] = array(
				$this->oldGuid => !empty($group[0][$this->oldGuid]) ? (is_array($group[0][$this->oldGuid]) ? $group[0][$this->oldGuid][0] : $group[0][$this->oldGuid]) : null,
				$this->groupKey => !empty($group[0][$this->groupKey]) ? (is_array($group[0][$this->groupKey]) ? $group[0][$this->groupKey][0] : $group[0][$this->groupKey]) : null
			);
			return $info;
		}
		else {
			$filter = '(&(|(objectcategory=group)(objectclass=dominoGroup))';
			$filter .= "({$this->oldGuid}={$groupkey}))";
			$group = $this->_ldap->group_info(null, $attributes, $filter);
			//$group = $this->_ldap->search_groups(null, false, '', true, $filter, $attributes);
			if (!empty($group['count']) && strval($group['count']) === '1') {
				$gname = (!empty($group[0]['displayname']) ? $group[0]["displayname"][0] : (!empty($group[0]['cn']) ? $group[0]['cn'][0] : $group[0]['samaccountname'][0]));
				$info[$gname] = array(
						$this->oldGuid => !empty($group[0][$this->oldGuid]) ? (is_array($group[0][$this->oldGuid]) ? $group[0][$this->oldGuid][0] : $group[0][$this->oldGuid]) : null,
						$this->groupKey => !empty($group[0][$this->groupKey]) ? (is_array($group[0][$this->groupKey]) ? $group[0][$this->groupKey][0] : $group[0][$this->groupKey]) : null
				);
				return $info;
			}
		}
		return false;
	}
	
	/**
	 * Find group GUID value by group name
	 * 
	 * @param string $groupname
	 * @return array|boolean
	 */
	private function fetchGroupKey($groupname)
	{
		$adKey = $this->_ldap->group_info($groupname, array($this->groupKey, $this->oldGuid, 'displayname'));
		if (!empty($adKey[0][$this->groupKey]))
		{
			$key = $this->_ldap->decodeGuid(is_array($adKey[0][$this->groupKey]) ? $adKey[0][$this->groupKey][0] : $adKey[0][$this->groupKey]);
			return array($key => is_array($adKey[0]['displayname']) ? $adKey[0]['displayname'][0] : $adKey[0]['displayname']);
		}
		elseif (!empty($adKey[0][$this->oldGuid]))
		{
			$key = $this->_ldap->decodeGuid(is_array($adKey[0][$this->oldGuid]) ? $adKey[0][$this->oldGuid][0] : $adKey[0][$this->oldGuid]);
			return array($key => is_array($adKey[0]['displayname']) ? $adKey[0]['displayname'][0] : $adKey[0]['displayname']);
		}

		return false;
	}
}