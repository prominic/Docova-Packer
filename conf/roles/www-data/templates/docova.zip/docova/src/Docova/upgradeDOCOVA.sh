#!/bin/bash
#
curpath="$( cd "$(dirname "${BASH_SOURCE[0]}")" ; pwd -P )"
curpath="${curpath%/}/"
echo 
echo "--------------------------------------------------------------"
echo "                   DOCOVA SE Upgrade                          "
echo "--------------------------------------------------------------"
echo 

if [ ! -f "$curpath/DocovaBundle/DocovaBundle.php" ]
then
    echo "The source upgrade files could not be located."
    echo "Please ensure that this batch file is run from within the upgrade files directory."
    exit 1
fi

echo 
echo "1. Enter path to the existing docova installation."
echo "   example: /var/www/html/docova"
echo "   Enter [q to quit]"
read  targetfolder
if [ "${targetfolder}" == "q" ]; then
   exit 1
fi
if [ "${targetfolder}" == "Q" ]; then
   exit 1
fi
if [ ! -d "${targetfolder}" ]; then
    echo "The existing docova installation could not be located."
    exit 1
fi
targetfolder="${targetfolder%/}/"

echo 
echo  "==========================================================="
echo  "=              Confirm Copy                               ="
echo  "=   This process will overwrite your existing DOCOVA      ="
echo  "=   application files.  Please confirm that you wish      ="
echo  "=   to begin the upgrade process.                         ="
echo  "==========================================================="
echo  "Do you wish to continue (y/n)?" 
read  oktocontinue
if [ "${oktocontinue}" != "y" ] && [ "${oktocontinue}" != "Y" ]; then
  exit 1
fi

echo 
echo "Do you want to exclude custom code (y/n)?"
read  skipcustom
echo "${curpath}.excludefiles.tmp">${curpath}.excludefiles.tmp
if [ "${skipcustom}" == "y" ] || [ "${skipcustom}" == "Y" ]; then
  echo "${curpath}DocovaBundle/Agents/*">>${curpath}.excludefiles.tmp
  echo "${curpath}DocovaBundle/Resources/public/css/custom/*">>${curpath}.excludefiles.tmp
  shopt -s nullglob
  urlpattern="${curpath}DocovaBundle/Resources/public/js/custom/*-*-*-*"
  for tempdir in $urlpattern
  do
     temppath="${tempdir%/}"
     temppath="${temppath##*/}"
     if [[ ${temppath} != *"."* ]]; then
	echo "${curpath}DocovaBundle/Resources/public/js/custom/${temppath}">>${curpath}.excludefiles.tmp
     fi
  done
  echo "${curpath}DocovaBundle/Resources/views/DesignElements/*">>${curpath}.excludefiles.tmp  
  shopt -s nullglob
  urlpattern="${curpath}DocovaBundle/Resources/public/images/*-*-*-*"
  for tempdir in $urlpattern
  do
     temppath="${tempdir%/}"
     temppath="${temppath##*/}"
     if [[ ${temppath} != *"."* ]]; then
	echo "${curpath}DocovaBundle/Resources/public/images/${temppath}">>${curpath}.excludefiles.tmp
     fi
  done
fi

echo 
echo "========================================================="
echo "=             Copy Files Started                        ="
echo "========================================================="
rsync -a --exclude-from="${curpath}.excludefiles.tmp" "${curpath}DocovaBundle/" "${targetfolder}src/Docova/DocovaBundle/"
echo "========================================================="
echo "=             Copy Files Finished                       ="
echo "========================================================="
echo 


echo 
echo "========================================================="
echo "=             Updating Autoload Files                   ="
echo "========================================================="
cd "${targetfolder}"
composer dump-autoload --classmap-authoritative
echo "========================================================="
echo "=             Finished Updating Autoload Files          ="
echo "========================================================="
echo 


echo 
echo "Do you want to check the database schema (y/n)?"
read  checkschema
if [ "${checkschema}" == "y" ] || [ "${checkschema}" == "Y" ]; then
  echo 
  echo "========================================================="
  echo "=             Checking Database Schema                  ="
  echo "========================================================="
  cd "${targetfolder}"
  php bin/console cache:clear --env=prod --no-debug --no-warmup >null
  php bin/console cache:clear --env=dev --no-debug --no-warmup >null
  # Temporarily override entity data types for schema check.
  php  switchormdatatype.php "${targetfolder}src/Docova/DocovaBundle/Entity/*.php" string text >null
  # Alert user to schema updates
  php bin/console doctrine:schema:update
  echo 
  echo "===================== Important =========================="
  echo "If required changes were reported above it may be necessary"
  echo "to update the database table structure.  The following"
  echo "command will generate the required SQL to update the tables."
  echo 
  
  echo 
  echo "Do you want to generate the schema update script (y/n)?"
  read  updatechema
  if [ "${updatechema}"=="y" ] || [ "${updateschema}"=="Y" ]
  then  
    php bin/console doctrine:schema:update --dump-sql >"${curpath}schemaupdate.sql"
    echo "A schemaupdate.sql file was created with the necessary SQL update commands"
  fi  
  # Reset any overrides to entity data types for schema check.
  php  switchormdatatype.php "${targetfolder}src/Docova/DocovaBundle/Entity/*.php" text string >null
fi

echo "========================================================="
echo "=             Finished Checking Database Schema         ="
echo "========================================================="
echo 

echo 
echo "========================================================="
echo "=             Clearing Application Cache                ="
echo "========================================================="
cd "${targetfolder}"
php bin/console cache:clear --env=prod --no-debug --no-warmup >null
php bin/console cache:clear --env=dev --no-debug --no-warmup >null
echo "========================================================="
echo "=             Finished Clearing Application Cache       ="
echo "========================================================="
echo 


echo 
echo "========================================================="
echo "=             Installing Asset Files                    ="
echo "========================================================="
cd "${targetfolder}"
php bin/console assets:install --no-debug
echo "========================================================="
echo "=             Finished Installing Asset Files           ="
echo "========================================================="
echo 

echo 
echo "Do you want to upgrade the schema of all views (y/n)?"
read  viewschema
if [ "${viewchema}" == "y" ] || [ "${viewchema}" == "Y" ]; then
  echo 
  echo "========================================================="
  echo "=             Upgrading View Schemas                    ="
  echo "========================================================="
  cd "${targetfolder}"
  bin/console docova:apps:upgradeviewschema --no-debug
  echo "========================================================="
  echo "=             Finished Upgrading View Schemas           ="
  echo "========================================================="
  echo  
fi

cd "${curpath}"
echo "========================================================="
echo "=                 Upgrade Complete                      ="
echo "========================================================="
