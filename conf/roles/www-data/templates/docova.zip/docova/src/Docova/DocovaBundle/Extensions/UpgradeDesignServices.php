<?php

namespace Docova\DocovaBundle\Extensions;

use Docova\DocovaBundle\Extensions\CopyDesignServices;
use Doctrine\ORM\EntityManager;
use Docova\DocovaBundle\Entity\Libraries;
use Docova\DocovaBundle\Entity\UserAccounts;

/**
 * Class to maintain upgrade app design services
 * @author javad_rahimi
 */
class UpgradeDesignServices extends CopyDesignServices
{
	private $_em;
	private $_user;
	private $_source;
	private $_target;

	public function __construct(EntityManager $em, Libraries $source, Libraries $target, UserAccounts $user, $rootpath)
	{
		$this->_em = $em;
		$this->_source = $source;
		$this->_target = $target;
		$this->_user = $user;
		parent::__construct($rootpath, $source->getId());
		$this->setTargetPath($target->getId());
	}

	/**
	 * Upgrade target application forms
	 */
	public function upgradeForms()
	{
		try {
			$source_forms = $this->_em->getRepository('DocovaBundle:AppForms')->getFormNamesAlias($this->_source->getId());
			$this->_em->getRepository('DocovaBundle:AppForms')->trashNoneInheritedForms($this->_target->getId(), $source_forms);// << trash all target forms where not in source forms and pDU is false
			//@note: should I delete trashed forms' twig files? For now I don't.
			$target_forms = $this->_em->getRepository('DocovaBundle:AppForms')->getFormNamesAlias($this->_target->getId());
			$common_forms = ['names' => [], 'alias' => []];
			$slen = count($source_forms['names']);
			$tlen = count($source_forms['names']);
			// find common forms by name or alias and take them out of source forms list
			for ($x = 0; $x < $slen; $x++)
			{
				for ($i = 0; $i < $tlen; $i++) {
					if (!empty($source_forms['names'][$x]) && !empty($target_forms['names'][$i]))
					{
						if ($source_forms['names'][$x] == $target_forms['names'][$i]) {
							$common_forms['names'][] = $source_forms['names'][$x];
							$common_forms['alias'][] = $source_forms['alias'][$x];
							unset($source_forms['names'][$x]);
							unset($source_forms['alias'][$x]);
							break;
						}
					}
					if (!empty($source_forms['alias'][$x]) && !empty($target_forms['alias'][$i]))
					{
						if ($source_forms['alias'][$x] == $target_forms['alias'][$i]) {
							$common_forms['names'][] = $source_forms['names'][$x];
							$common_forms['alias'][] = $source_forms['alias'][$x];
							unset($source_forms['names'][$x]);
							unset($source_forms['alias'][$x]);
							break;
						}
					}
				}
			}
			$source_forms['names'] = array_values($source_forms['names']);
			$source_forms['alias'] = array_values($source_forms['alias']);
			
			$slen = count($source_forms['names']);
			// loop through the rest of source forms and create them in target app (new source forms will be created)
			for ($x = 0; $x < $slen; $x++) {
				if (!empty($source_forms['names'][$x]) && !empty($source_forms['alias'][$x])) {
					$src_form = $this->_em->getRepository('DocovaBundle:AppForms')->findOneBy(['application' => $this->_source->getId(), 'formName' => $source_forms['names'][$x], 'formAlias' => $source_forms['alias'][$x]]);
				}
				elseif (!empty($source_forms['names'][$x])) {
					$src_form = $this->_em->getRepository('DocovaBundle:AppForms')->findOneBy(['application' => $this->_source->getId(), 'formName' => $source_forms['names'][$x]]);
				}
				elseif (!empty($source_forms['alias'][$x])) {
					$src_form = $this->_em->getRepository('DocovaBundle:AppForms')->findOneBy(['application' => $this->_source->getId(), 'formAlias' => $source_forms['alias'][$x]]);
				}
				
				if (!empty($src_form)) {
					$this->cloneForm($src_form);
				}
			}
			
			$clen = count($common_forms['names']);
			// loop through common forms and update desing of each target form base on source form changes
			for ($x = 0; $x < $clen; $x++)
			{
				if (!empty($common_forms['names'][$x]) && !empty($common_forms['alias'][$x])) {
					$src_form = $this->_em->getRepository('DocovaBundle:AppForms')->findOneBy(['application' => $this->_source->getId(), 'formName' => $common_forms['names'][$x], 'formAlias' => $common_forms['alias'][$x]]);
					$target_form = $this->_em->getRepository('DocovaBundle:AppForms')->findOneBy(['application' => $this->_target->getId(), 'formName' => $common_forms['names'][$x], 'formAlias' => $common_forms['alias'][$x]]);
					if (empty($target_form)) {
						$target_form = $this->_em->getRepository('DocovaBundle:AppForms')->findOneBy(['application' => $this->_target->getId(), 'formName' => $common_forms['names'][$x]]);
						if (empty($target_form)) {
							$target_form = $this->_em->getRepository('DocovaBundle:AppForms')->findOneBy(['application' => $this->_target->getId(), 'formAlias' => $common_forms['alias'][$x]]);
						}
					}
				}
				elseif (!empty($common_forms['names'][$x])) {
					$src_form = $this->_em->getRepository('DocovaBundle:AppForms')->findOneBy(['application' => $this->_source->getId(), 'formName' => $common_forms['names'][$x]]);
					$target_form = $this->_em->getRepository('DocovaBundle:AppForms')->findOneBy(['application' => $this->_target->getId(), 'formName' => $common_forms['names'][$x]]);
				}
				elseif (!empty($common_forms['alias'][$x])) {
					$src_form = $this->_em->getRepository('DocovaBundle:AppForms')->findOneBy(['application' => $this->_source->getId(), 'formAlias' => $common_forms['alias'][$x]]);
					$target_form = $this->_em->getRepository('DocovaBundle:AppForms')->findOneBy(['application' => $this->_target->getId(), 'formAlias' => $common_forms['alias'][$x]]);
				}
				
				if (!empty($src_form) && !empty($target_form))
				{
					//update form meta data
					$target_form->setDateModified(new \DateTime());
					$target_form->setModifiedBy($this->_user);
					$target_form->setFormName($src_form->getFormName());
					$target_form->setFormAlias($src_form->getFormAlias());
					$target_form->setCSSFilename($src_form->getCSSFilename());
					$target_form->setJSFilename($src_form->getJSFilename());

					//update form properties
					$src_properties = $src_form->getFormProperties();
					if(!empty($src_properties)) {
						$properties = $target_form->getFormProperties();
						$properties->setModifiedBy($this->_user);
						$properties->setDateModified(new \DateTime());
						$properties->setAllowRetract($src_properties->getAllowRetract());
						$properties->setArchivedStatus($src_properties->getArchivedStatus());
						$properties->setAttachmentOptions($src_properties->getAttachmentOptions());
						$properties->setAttachmentSection($src_properties->getAttachmentSection());
						$properties->setCustomHideButtonsWhen($src_properties->getCustomHideButtonsWhen());
						$properties->setCustomJSWFApprove($src_properties->getCustomJSWFApprove());
						$properties->setCustomJSWFComplete($src_properties->getCustomJSWFComplete());
						$properties->setCustomJSWFDeny($src_properties->getCustomJSWFDeny());
						$properties->setCustomJSWFStart($src_properties->getCustomJSWFStart());
						$properties->setCustomReleaseButtonLabel($src_properties->getCustomReleaseButtonLabel());
						$properties->setCustomReviewButtonLabel($src_properties->getCustomReviewButtonLabel());
						$properties->setCustomStartButtonLabel($src_properties->getCustomStartButtonLabel());
						$properties->setDeletedStatus($src_properties->getDeletedStatus());
						$properties->setDisableDeleteWorkflow($src_properties->getDisableDeleteWorkflow());
						$properties->setDiscardedStatus($src_properties->getDiscardedStatus());
						$properties->setEmailSection($src_properties->getEmailSection());
						$properties->setEnableLifeCycle($src_properties->getEnableLifeCycle());
						$properties->setEnableVersions($src_properties->getEnableVersions());
						$properties->setEnableWorkflow($src_properties->getEnableWorkflow());
						$properties->setFinalStatus($src_properties->getFinalStatus());
						$properties->setHideButtons($src_properties->getHideButtons());
						$properties->setInitialStatus($src_properties->getInitialStatus());
						$properties->setRestrictDrafts($src_properties->getRestrictDrafts());
						$properties->setRestrictLiveDrafts($src_properties->getRestrictLiveDrafts());
						$properties->setSpecialEditorSectoin($src_properties->getSpecialEditorSectoin());
						$properties->setStrictVersioning($src_properties->getStrictVersioning());
						$properties->setSupersededStatus($src_properties->getSupersededStatus());
						$properties->setUpdateBookmarks($src_properties->getUpdateBookmarks());
					}
					
					//update attachments' properties
					$src_attprop = $src_form->getAttachmentProp();
					if(!empty($src_attprop)){
						$att_prop = $target_form->getAttachmentProp();
						$att_prop->setAllowedExtensions($src_attprop->getAllowedExtensions());
						$att_prop->setFileCiao($src_attprop->getFileCiao());
						$att_prop->setFileDownloadLogging($src_attprop->getFileDownloadLogging());
						$att_prop->setFileViewLogging($src_attprop->getFileViewLogging());
						$att_prop->setHideAttachment($src_attprop->getHideAttachment());
						$att_prop->setLocalScan($src_attprop->getLocalScan());
						$att_prop->setMaxFiles($src_attprop->getMaxFiles());
						$att_prop->setReadOnly($src_attprop->getReadOnly());
						$att_prop->setTemplateAutoAttach($src_attprop->getTemplateAutoAttach());
						$att_prop->setTemplateList($src_attprop->getTemplateList());
						$att_prop->setTemplateType($src_attprop->getTemplateType());
					}
					
					//remove workflows tied to target form 
					$target_worklows = $target_form->getFormWorkflows();
					if (!empty($target_worklows))
					{
						foreach ($target_worklows as $wf) {
							$target_form->removeFormWorkflow($wf);
						}
					}
					$this->_em->flush();
					$this->removeAppWorkflows($target_worklows);
					$this->copyFormWorkflows($src_form, $target_form);
					$this->updateDesignElements($src_form->getElements(), $target_form);
					//@note: should I delete target form's twig files first? For now, I don't.
					$this->copyFiles('FORMS', $src_form->getFormName());
				}
				elseif (!empty($src_form) && empty($target_form))
				{
					$this->cloneForm($src_form);
				}
			}
		}
		catch (\Exception $e) {
			//@todo: log the error and form name which is not upgraded
			echo "exception ".$e->getMessage();
		}
	}
	
	/**
	 * Upgrade target app views
	 */
	public function upgradeViews()
	{
		try {
			$trash_views = $this->_em->getRepository('DocovaBundle:AppViews')->getAllViewIds($this->_target->getId(), true);
			//@todo: delete all twigs for trashed views in back-end
			$conn = $this->_em->getConnection();
			foreach ($trash_views as $view_id) {
				$id = str_replace('-', '', $view_id);
				$query = "DROP TABLE view_$id";
				$stmt = $conn->prepare($query);
				$stmt->execute();
				$view = $this->_em->getReference('DocovaBundle:AppViews', $view_id);
				$this->_em->remove($view);
			}
			$this->_em->flush();
			$view = $view_id = null;
			
			$source_views = $this->_em->getRepository('DocovaBudle:AppViews')->findBy(['application' => $this->_source->getId()]);
			if (!empty($source_views[0]))
			{
				foreach ($source_views as $view)
				{
					$target_view = clone $view;
					$target_view->setDateModified(new \DateTime());
					$target_view->setModifiedBy($this->_user);
					$trash_views->setApplication($this->_target);
					$this->copyFiles('TOOLBAR', $view->getViewName());
					$this->_em->persist($target_view);
				}
				$this->_em->flush();
				//@todo: create a bat file and call it to index the view through command line to speed up upgrade process.
			}
		}
		catch (\Exception $e) {
			//@todo: log the error and view name which is not upgraded
			echo "exception ".$e->getMessage();
		}
	}
	
	/**
	 * Upgrade target app's layouts
	 */
	public function upgradeLayouts()
	{
		try {
			$trash_layouts = $this->_em->getRepository('DocovaBundle:AppLayout')->findBy(['application' => $this->_target->getId(), 'pDU' => false]);
			if (!empty($trash_layouts[0]))
			{
				foreach ($trash_layouts as $layout)
				{
					//@todo: delete each layout generated twig or other file
					$this->_em->remove($layout);
				}
				$this->_em->flush();
			}
			
			$source_layouts = $this->_em->getRepository('DocovaBundle:AppLayout')->findBy(['application' => $this->_source->getId()]);
			if (!empty($source_layouts[0]))
			{
				foreach ($source_layouts as $layout)
				{
					$target_layout = clone $layout;
					$target_layout->setApplication($this->_target->getId());
					$target_layout->setDateModified(new \DateTime());
					$target_layout->setModifiedBy($this->_user);
					$this->_em->flush();
					$this->copyFiles('LAYOUTS', $layout->getLayoutId());
				}
			}
		}
		catch (\Exception $e) {
			//@todo: log the error and view name which is not upgraded
			echo "exception ".$e->getMessage();
		}
	}
	
	/**
	 * Upgrade target app pages
	 */
	public function upgradePages()
	{
		try {
			$trash_pages = $this->_em->getRepository('DocovaBundle:AppPages')->findBy(['application' => $this->_target->getId(), 'pDU' => false]);
			if (!empty($trash_pages[0]))
			{
				foreach ($trash_pages as $page)
				{
					//@todo: delete each page generated twig or other file
					$this->_em->remove($page);
				}
				$this->_em->flush();
			}

			$source_pages = $this->_em->getRepository('DocovaBundle:AppPages')->findBy(['application' => $this->_source->getId()]);
			if (!empty($source_pages[0]))
			{
				foreach ($source_pages as $page)
				{
					$target_page = clone $page;
					$target_page->setDateModified(new \DateTime());
					$target_page->setModifiedBy($this->_user);
					$target_page->setApplication($this->_target);
					$this->_em->persist($target_page);
					$this->copyFiles('PAGES', $page->getPageName());
				}
			}
		}
		catch (\Exception $e) {
			//@todo: log the error and view name which is not upgraded
			echo "exception ".$e->getMessage();
		}
	}
	
	public function upgradeSubforms()
	{
		try {
			$source_forms = $this->_em->getRepository('DocovaBundle:Subforms')->getFormNamesAlias($this->_source->getId());
			$this->_em->getRepository('DocovaBundle:Subforms')->trashNoneInheritedForms($this->_target->getId(), $source_forms);// << trash all target forms where not in source forms and pDU is false
			//@note: should I delete trashed forms' twig files? For now I don't.
			$target_forms = $this->_em->getRepository('DocovaBundle:Subforms')->getFormNamesAlias($this->_target->getId());
			$common_forms = ['names' => [], 'alias' => []];
			$slen = count($source_forms['names']);
			$tlen = count($source_forms['names']);
			// find common forms by name or alias and take them out of source forms list
			for ($x = 0; $x < $slen; $x++)
			{
				for ($i = 0; $i < $tlen; $i++) {
					if (!empty($source_forms['names'][$x]) && !empty($target_forms['names'][$i]))
					{
						if ($source_forms['names'][$x] == $target_forms['names'][$i]) {
							$common_forms['names'][] = $source_forms['names'][$x];
							$common_forms['alias'][] = $source_forms['alias'][$x];
							unset($source_forms['names'][$x]);
							unset($source_forms['alias'][$x]);
							break;
						}
					}
					if (!empty($source_forms['alias'][$x]) && !empty($target_forms['alias'][$i]))
					{
						if ($source_forms['alias'][$x] == $target_forms['alias'][$i]) {
							$common_forms['names'][] = $source_forms['names'][$x];
							$common_forms['alias'][] = $source_forms['alias'][$x];
							unset($source_forms['names'][$x]);
							unset($source_forms['alias'][$x]);
							break;
						}
					}
				}
			}
			$source_forms['names'] = array_values($source_forms['names']);
			$source_forms['alias'] = array_values($source_forms['alias']);
				
			$slen = count($source_forms['names']);
			// loop through the rest of source forms and create them in target app (new source forms will be created)
			for ($x = 0; $x < $slen; $x++) {
				if (!empty($source_forms['names'][$x]) && !empty($source_forms['alias'][$x])) {
					$src_form = $this->_em->getRepository('DocovaBundle:Subforms')->findOneBy(['application' => $this->_source->getId(), 'Form_File_Name' => $source_forms['names'][$x], 'Form_Name' => $source_forms['alias'][$x]]);
				}
				elseif (!empty($source_forms['names'][$x])) {
					$src_form = $this->_em->getRepository('DocovaBundle:Subforms')->findOneBy(['application' => $this->_source->getId(), 'Form_File_Name' => $source_forms['names'][$x]]);
				}
				elseif (!empty($source_forms['alias'][$x])) {
					$src_form = $this->_em->getRepository('DocovaBundle:Subforms')->findOneBy(['application' => $this->_source->getId(), 'Form_Name' => $source_forms['alias'][$x]]);
				}
			
				if (!empty($src_form)) {
					$target_form = clone $src_form;
					$target_form->setApplication($this->_target);
					$target_form->setDateModified(new \DateTime());
					$target_form->setModifiedBy($this->_user);
					$this->_em->persist($target_form);
					
					$this->copyFormElements($src_form, $target_form, true);
					$this->copyFiles('SUBFORMS', $src_form->getFormName());
				}
			}
				
			$clen = count($common_forms['names']);
			// loop through common forms and update desing of each target form base on source form changes
			for ($x = 0; $x < $clen; $x++)
			{
				if (!empty($common_forms['names'][$x]) && !empty($common_forms['alias'][$x])) {
					$src_form = $this->_em->getRepository('DocovaBundle:Subforms')->findOneBy(['application' => $this->_source->getId(), 'Form_File_Name' => $common_forms['names'][$x], 'Form_Name' => $common_forms['alias'][$x]]);
					$target_form = $this->_em->getRepository('DocovaBundle:Subforms')->findOneBy(['application' => $this->_target->getId(), 'Form_File_Name' => $common_forms['names'][$x], 'Form_Name' => $common_forms['alias'][$x]]);
					if (empty($target_form)) {
						$target_form = $this->_em->getRepository('DocovaBundle:Subforms')->findOneBy(['application' => $this->_target->getId(), 'Form_File_Name' => $common_forms['names'][$x]]);
						if (empty($target_form)) {
							$target_form = $this->_em->getRepository('DocovaBundle:Subforms')->findOneBy(['application' => $this->_target->getId(), 'Form_Name' => $common_forms['alias'][$x]]);
						}
					}
				}
				elseif (!empty($common_forms['names'][$x])) {
					$src_form = $this->_em->getRepository('DocovaBundle:Subforms')->findOneBy(['application' => $this->_source->getId(), 'Form_File_Name' => $common_forms['names'][$x]]);
					$target_form = $this->_em->getRepository('DocovaBundle:Subforms')->findOneBy(['application' => $this->_target->getId(), 'Form_File_Name' => $common_forms['names'][$x]]);
				}
				elseif (!empty($common_forms['alias'][$x])) {
					$src_form = $this->_em->getRepository('DocovaBundle:Subforms')->findOneBy(['application' => $this->_source->getId(), 'Form_Name' => $common_forms['alias'][$x]]);
					$target_form = $this->_em->getRepository('DocovaBundle:Subforms')->findOneBy(['application' => $this->_target->getId(), 'Form_Name' => $common_forms['alias'][$x]]);
				}
			
				if (!empty($src_form) && !empty($target_form))
				{
					//update form meta data
					$target_form->setDateModified(new \DateTime());
					$target_form->setModifiedBy($this->_user);
					$target_form->setFormFileName($src_form->getFormFileName());
					$target_form->setFormName($src_form->getFormName());
					$this->_em->flush();
					$this->updateDesignElements($src_form->getSubformFields(), $target_form);
					//@note: should I delete target form's twig files first? For now, I don't.
					$this->copyFiles('SUBFORMS', $src_form->getFormFileName());
				}
			}
		}
		catch (\Exception $e) {
			//@todo: log the error and view name which is not upgraded
			echo "exception ".$e->getMessage();
		}
	}
	
	/**
	 * Remove all app workflows and depencies
	 * 
	 * @param \Docova\DocovaBundle\Entity\Workflow[] $workflows
	 */
	private function removeAppWorkflows($workflows)
	{
		if (!empty($workflows) && $workflows->count())
		{
			foreach ($workflows as $wf)
			{
				$steps = $wf->getSteps();
				foreach ($steps as $stp)
				{
					$actions = $stp->getActions();
					foreach ($actions as $act)
					{
						$sendTo = $act->getSendTo();
						foreach ($sendTo as $send) {
							$act->removeSendTo($send);
						}
						$act->setBackTrackStep(null);
						$stp->removeAction($act);
						$this->_em->remove($act);
					}
					
					$participants = $stp->getOtherParticipant();
					if (!empty($participants) && $participants->count())
					{
						foreach ($participants as $p) {
							$stp->removeOtherParticipant($p);
						}
					}
					$this->_em->remove($stp);
				}
				$this->_em->remove($wf);
			}
			$this->_em->flush();
		}
	}
	
	/**
	 * Clone the source form
	 * 
	 * @param \Docova\DocovaBundle\Entity\AppForms $source
	 */
	private function cloneForm($source)
	{
		$target_form = clone $source;
		$target_form->setApplication($this->_target);
		$target_form->setCreatedBy($this->_user);
		$target_form->setDateCreated(new \DateTime());
		$target_form->setDateModified(new \DateTime());
		$target_form->setModifiedBy($this->_user);
		$this->_em->persist($target_form);
			
		$src_properties = $source->getFormProperties();
		if(!empty($src_properties)){
			$properties = clone $src_properties;
			$properties->setAppForm($target_form);
			$properties->setModifiedBy($this->_user);
			$properties->setDateModified(new \DateTime());
			$this->_em->persist($properties);
		}
		
		$src_attprop = $source->getAttachmentProp();
		if(!empty($src_attprop)){
			$att_prop = clone $src_attprop;
			$att_prop->setAppForm($target_form);
			$this->_em->persist($att_prop);
		}
		
		$this->copyFormElements($source, $target_form);
		$this->copyFormWorkflows($source, $target_form);
		$this->copyFiles('FORMS', $source->getFormName());
	}
	
	/**
	 * Update target design elements base on source elements
	 * 
	 * @param \Docova\DocovaBundle\Entity\DesignElements[] $source
	 * @param \Docova\DocovaBundle\Entity\AppForms|\Docova\DocovaBundle\Entity\Subforms $trg_form
	 */
	private function updateDesignElements($source, $trg_form, $is_subform = false)
	{
		if ($is_subform === true) {
			$target = $trg_form->getSubformFields();
		}
		else {
			$target = $trg_form->getElements();
		}
		if (!empty($target[0]) && !empty($source[0]))
		{
			$tlen = count($target);
			for ($x = 0; $x < $tlen; $x++)
			{
				$found = false;
				foreach ($source as $i => $element) {
					if ($element->getFieldName() == $target[$x]->getFieldName()) {
						$target[$x]->setDateModified(new \DateTime());
						$target[$x]->setModifiedBy($this->_user);
						$target[$x]->setFieldType($element->getFieldType());
						$target[$x]->setMultiSeparator($element->getMultiSeparator());
						$target[$x]->setNameFieldType($element->getNameFieldType());
						$target[$x]->setSelectQuery($element->getSelectQuery());
						$source[$i] = null;
						$found = true;
						break;
					}
				}
				
				if ($found === false) {
					$target[$x]->setTrash(true);
					$target[$x]->setDateModified(new \DateTime());
					$target[$x]->setModifiedBy($this->_user);
					$found = true;
				}
				
				if ($found === true) {
					$this->_em->flush();
				}
			}
			
			$source = array_values(array_filter($source));
		}
		
		if (!empty($source[0]))
		{
			foreach ($source as $element) {
				$target_elem = clone $element;
				$target_elem->setDateModified(new \DateTime());
				$target_elem->setModifiedBy($this->_user);
				$target_elem->setForm($trg_form);
				$this->_em->persist($target_elem);
				$this->_em->flush();
			}
		}
	}
}