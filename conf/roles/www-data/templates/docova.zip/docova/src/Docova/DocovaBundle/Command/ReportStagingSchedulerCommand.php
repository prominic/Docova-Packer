<?php
namespace Docova\DocovaBundle\Command;

use Doctrine\DBAL\Connection;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Docova\DocovaBundle\Extensions\ExternalConnections;
use Docova\DocovaBundle\Entity\ReportStagingProfile;


/**
 * @author Jeff Primeau
 * Command to trigger data presentation jobs
 *        
 */
class ReportStagingSchedulerCommand extends ContainerAwareCommand 
{	
	protected function configure()
	{
		$this
			->setName('docova:reportstagingscheduler')
			->setDescription('Report Staging Scheduler Command');         	
	}
	
	protected function execute(InputInterface $input, OutputInterface $output)
	{
	    $this->output = $output;
		try {		     
		     $em = $this->getContainer()->get('doctrine')->getManager();
	
		     $dpp = $em->getRepository('DocovaBundle:ReportStagingProfile');
		     $hourlyProfilesProcessed = 0;
		     $dailyProfilesProcessed = 0;
		     
		     //1.  Process the hourly jobs where at least one hour has elapsed		     
		     $hourlyProfiles=$dpp->getPendingHourlyProfiles();		     
		     if (!empty($hourlyProfiles)){
		         echo PHP_EOL.count($hourlyProfiles)." pending hourly profile(s) found";
		         foreach($hourlyProfiles as $hourlyProfile){		             
		             $this->processProfile($hourlyProfile,"Hourly");
		             $hourlyProfilesProcessed++;
		         }
		     }
		     
		     //2.  Process the daily jobs where at least one hour has elapsed
		     $dailyProfiles=$dpp->getPendingDailyProfiles();
		     if (!empty($dailyProfiles)){
		         echo PHP_EOL.count($dailyProfiles)." pending daily profile(s) found";
		         foreach($dailyProfiles as $dailyProfile){
		             $this->processProfile($dailyProfile,"Daily");
		             $dailyProfilesProcessed++;
		         }
		     }
		     echo PHP_EOL."------------";
		     echo PHP_EOL."Processed ".(empty($hourlyProfiles) ? 0 : count($hourlyProfiles))." Report Staging Profiles scheduled hourly";
		     echo PHP_EOL."Processed ".(empty($dailyProfiles) ? 0 : count($dailyProfiles))." Report Staging Profiles scheduled daily";		     
		     echo PHP_EOL."Completed processing scheduled Report Staging Profiles";		     
		}
		catch(\Exception $e){
		    echo PHP_EOL."reportstagingscheduler ERROR:".$e->getMessage().PHP_EOL.$e->getTraceAsString();
		}
	}
	private function getRootPath(){
	    //the _root directory is located 4 directories above the current script path
	    return str_replace('\\', '/', realpath(__DIR__.'/../../../../'));
	}
	private function processProfile(ReportStagingProfile $profile,$updateFrequency){
	    try{
	        //process the profile
	        echo PHP_EOL."Processing ".$updateFrequency." profile ".$profile->getName(). " (".$profile->getId().")";
	        
	        $dtNow = new \DateTime();
	        //compute the log file name
	        $logFile = $profile->getName()."_".$dtNow->format("Y-m-d_H_i_s").".log";
	        //sanitize the log file name
	        $logFile = preg_replace( '/[^a-zA-Z0-9]+/', '_', $logFile );
	        
	        $logPath = $this->getRootPath()."/"."logs/ReportStaging/";
	        
	        if (!file_exists($logPath)){
	            mkdir($logPath);
	        }
	        $logFilePath =$logPath.$logFile;
	        $command = ''.$this->getRootPath()."/reportStaging.bat".' "'.$profile->getId().'" "'.$logFilePath.'"';
	       
	        echo PHP_EOL."Running Command: ".$command;
	        exec($command);
	    }
	    catch (\Exception $e){
	        echo PHP_EOL."reportstagingscheduler.processProfile() ERROR:".$e->getMessage().PHP_EOL.$e->getTraceAsString();
	        throw $e;
	    }
	}
}