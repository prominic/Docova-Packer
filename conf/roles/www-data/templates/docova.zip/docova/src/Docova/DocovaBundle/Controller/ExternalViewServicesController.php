<?php
namespace Docova\DocovaBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Docova\DocovaBundle\Extensions\ExternalDataView;

class ExternalViewServicesController extends Controller{   
    public function getEntityManager(){
        return $this->getDoctrine()->getManager();
    }
    public function getDoctrineConnection(){
        return $this->getDoctrine()->getConnection();
    }
          
   function viewServicesAction(Request $request){          
        $em = $this->getEntityManager();
        $app = $request->request->get('@app');       
        $view =  $request->request->get('@view');
        $where =  $request->request->get('@where');
        $columns = ( $request->request->has('@columns') ? $request->request->get('@columns') : $request->request->get('@column') );
        $docovaFields =  $request->request->get('@docovafields');
        $keys =  $request->request->get('@keys');
        if (!empty($keys)){
            $keys = explode(',',$keys);
        }
        $id =  $request->request->get('@id');
        $orderBy =  $request->request->get('@orderby');
        $delimiter =  $request->request->get('@delimiter');
        $action =  $request->request->get('@action');
        
        $edv = new ExternalDataView($em, $this->getDoctrine());
        
        switch ($action){
            case "dbLookup":
                if (empty($delimiter)){
                    $text =  $edv->dbLookup($app, $view, $where, $columns, $orderBy);
                }
                else{
                    $text =  $edv->dbLookup($app, $view, $where, $columns, $orderBy, $delimiter);
                }                            
                return new Response($text,200,array("Context-Type"=>"plain/text"));                
            case "dbColumn":                
                if (empty($delimiter)){
                    $text =  $edv->dbColumn($app, $view, $columns, $orderBy);
                }
                else{
                    $text =  $edv->dbColumn($app, $view, $columns, $orderBy, $delimiter);
                }
                return new Response($text,200,array("Context-Type"=>"plain/text"));
            case "dbSelect":
                $json =  $edv->dbSelect($app, $view, $where, $columns, $orderBy);
                return new Response($json,200,array("Context-Type"=>"application/json"));  
            case "select":
                $json =  $edv->select($app, $view, $where, $columns, $orderBy, $docovaFields);
                return new Response($json,200,array("Context-Type"=>"application/json")); 
            case "read":
                $json = $edv->read($app,$view,$id,$columns,$docovaFields);
                return new Response($json,200,array("Context-Type"=>"application/json"));
            case "insert":
                $json =  $edv->insert($app, $view, $request);
                return new Response($json,200,array("Context-Type"=>"application/json"));  
            case "update":
                $json =  $edv->update($app, $view, $request);
                return new Response($json,200,array("Context-Type"=>"application/json"));  
            case "delete":
                $json =  $edv->delete($app, $view, $keys);
                return new Response($json,200,array("Context-Type"=>"application/json")); 
            default:
                return new Response(json_encode(array('Error' => 'Invalid Action')),200,array("Context-Type"=>"application/json")); 
        }
    }
}

