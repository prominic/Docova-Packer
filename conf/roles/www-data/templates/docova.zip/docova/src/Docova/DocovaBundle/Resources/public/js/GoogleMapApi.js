var DocovaMap;

function GoogleMapApi(options)
{
	var geocoder;
	var map;
	var default_options = {
		name: 'Docova_Map_ID',
		longitude: 0,
		latitude: 0,
		zipcode: '',
		address: ''
	}

	var opts = $.extend({}, default_options, options);
	if (!opts.longitude && typeof opts.longitude == 'string') {
		opts.longitude = 0;
	}
	
	if (!opts.latitude && typeof opts.latitude == 'string') {
		opts.latitude = 0;
	}

	this.run = function() {
		geocoder = new google.maps.Geocoder();
		var latlng = new google.maps.LatLng(opts.latitude, opts.longitude);
		var myOptions = {
			zoom: 15,
			center: latlng,
			mapTypeControl: true,
			mapTypeControlOptions: {
				style: google.maps.MapTypeControlStyle.DROPDOWN_MENU
			},
			navigationControl: true,
			mapTypeId: google.maps.MapTypeId.ROADMAP
		};
	
		map = new google.maps.Map(document.getElementById(opts.name), myOptions);
		
		if (opts.address) {
			var prop = { 'address': opts.address };
			this.setMapMarker(prop, opts.address);
		}
		else if (opts.zipcode) {
			var prop = { 'address': opts.zipcode };
			this.setMapMarker(prop, opts.zipcode);
		}
		else {
			this.setMapMarker({ location: latlng }, latlng.toString());			
		}

		if (!opts.longitude && !opts.latitude) {
			this.obtainLngAlt();
		}
	}
	
	this.obtainLngAlt = function() {
		if (geocoder)
		{
			if (opts.address) {
				geocoder.geocode({ 'address': "'"+opts.address+"'" }, function(results, status) {
					if (status == google.maps.GeocoderStatus.OK) {
						opts.longitude = results[0].geometry.location.lng();
						opts.latitude = results[0].geometry.location.lat();
						map.setCenter(results[0].geometry.location);
						google.maps.event.trigger(map, 'resize');
						return true;
					}
					return false;
				});
			}
			else if (opts.zipcode) {
				geocoder.geocode({ 'address': "'"+opts.zipcode+"'" }, function(results, status) {
					if (status == google.maps.GeocoderStatus.OK) {
						opts.longitude = results[0].geometry.location.lng();
						opts.latitude = results[0].geometry.location.lat();
						map.setCenter(results[0].geometry.location);
						google.maps.event.trigger(map, 'resize');
						return true;
					}
					return false;
				});
			}
		}
		
		return false;
	}
	
	this.setMapMarker = function(property, map_title) {
		if (geocoder) {
			geocoder.geocode(property, function(results, status) {
				if (status == google.maps.GeocoderStatus.OK) {
					if (status != google.maps.GeocoderStatus.ZERO_RESULTS)
					{
						var marker = new google.maps.Marker({
							position: results[0].geometry.location,
							map: map, 
							title: map_title
						});
					} else {
						alert("No results found");
					}
				} else {
					alert("Failed to locate the address for the following reason: " + status);
				}
			});
		}
	}

	this.relocateByAddressOrZip = function(new_location) {
		if (geocoder)
		{
			geocoder.geocode({ 'address': "'"+ new_location +"'" }, function(results, status) {
				if (status == google.maps.GeocoderStatus.OK) {
					map.setCenter(results[0].geometry.location);
					google.maps.event.trigger(map, 'resize');
					return true;
				}
				alert('Failed to find location on map!');
			});			
		}
	}
	
	this.relocateByLatLng = function(lat, lng) {
		if (geocoder)
		{
			var new_loc = new google.maps.LatLng(lat, lng);
			map.setCenter(new_loc);
			google.maps.event.trigger(map, 'resize');
			return true;
		}
	}
}