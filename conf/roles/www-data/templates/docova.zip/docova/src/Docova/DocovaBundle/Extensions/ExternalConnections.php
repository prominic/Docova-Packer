<?php
namespace Docova\DocovaBundle\Extensions;

use Symfony\Component\Config\FileLocator;
use Symfony\Component\DependencyInjection\Loader\YamlFileLoader;
use Symfony\Component\DependencyInjection\ContainerBuilder;


class ExternalConnections {
	public static function getConnection($name){
		//Initialize the PDO connection from the YML configuration file
		return self::getDbConnection(self::getConfiguration($name));
	}
	
	public static function getConnectionInfo($name){
		$connection = self::getConnection($name);
		$info = "Driver Name: ".$connection->getAttribute(\PDO::ATTR_DRIVER_NAME);
		$info .="<br/>";
		try{
			$info .= "Server Info: ".json_encode($connection->getAttribute(\PDO::ATTR_SERVER_INFO),JSON_PRETTY_PRINT);
			$info .="<br/>";
		}
		catch (\PDOException $e){
		}
		catch (\Exception $e){
		}
		
		try{
			$info .= "Server Version: ".$connection->getAttribute(\PDO::ATTR_SERVER_VERSION);
			$info .="<br/>";
		}
		catch (\PDOException $e){
		}
		catch (\Exception $e){
		}
		
		/*
		try{		    		    
		    $info .= "Connection Status: ".json_encode($connection->getAttribute(\PDO::ATTR_CONNECTION_STATUS));
			$info .="<br/>";
		}
		catch (\PDOException $e){
		}
		catch (\Exception $e){
		}
		*/
		
		try{
			$info .= "Client Version: ".json_encode($connection->getAttribute(\PDO::ATTR_CLIENT_VERSION));
			$info .="<br/>";
		}
		catch (\PDOException $e){
		}
		catch (\Exception $e){
		}
		
		
		return $info;
	}
	public static function getDrivers(){
		return array(
			'MySQL' => 'pdo_mysql',
			'MS SQL' => 'pdo_sqlsrv',
			'PostGRE' => 'pdo_pgsql',
			'ODBC' => 'pdo_odbc',
			'Domino' => 'domino'
		);
	}
	//load and parse the specified yml configuration field
	public static function hasConnection($connectionName){
		//Read the yml connection file
		$configPath =  \str_replace('\\', '/', realpath(__DIR__.'/../../../../app/config/connections'));
		if (file_exists($configPath.DIRECTORY_SEPARATOR.$connectionName.".yml")){
			return true;
		}
		else{
			return false;
		}
	}
	public static function hasUserCredential($em,$connectionName,$user){
		$credential = ExternalConnections::getUserCredential($em, $connectionName, $user);
		if (empty($credential) )
			return false;
		else
			return true;
	}
	public static function getUserCredential($em,$connectionName,$user){
		return $em->getRepository("DocovaBundle:UserCredentials")->findByUserAndName($user,$connectionName);		
	}
	//load and parse the specified yml configuration field
	private static function getConfiguration($connectionName){
		//Read the yml connection file
		$configPath =  \str_replace('\\', '/', realpath(__DIR__.'/../../../../app/config/connections'));
		if (!file_exists($configPath.DIRECTORY_SEPARATOR.$connectionName.".yml")){
			return null;
		}
		$container = new ContainerBuilder();
		$ymlLoader = new YamlFileLoader($container,new FileLocator($configPath));
		$ymlLoader->load($connectionName.".yml");
		
		return $container;
	}

	//load and parse the specified yml configuration field
	private static function getConfigurations(){
		//Read the yml connection file
		$configPath =  \str_replace('\\', '/', realpath(__DIR__.'/../../../../app/config/connections'));
		
		//list the names of all of the yml files in the directory
		$connectionFiles = scandir($configPath);
		
		if ($connectionFiles==null || !is_array($connectionFiles) || empty($connectionFiles)){
			return null;
		}
		
		$connectionContainers = array();
		$connectionIndex = 0;
		foreach ($connectionFiles as $connectionName){
			if ($connectionName=="." || $connectionName==".."){
				continue;
			}
			$container = new ContainerBuilder();
			$ymlLoader = new YamlFileLoader($container,new FileLocator($configPath));
			$ymlLoader->load($connectionName);
			
			$connectionContainers[$connectionName]=$container;
			$connectionIndex++;
		}
		return $connectionContainers;
		
	}
	private static function getDbConnections($connectionContainers){
		if (empty($connectionContainers) || !is_array($connectionContainers)){
			return null;
		}
		$connections = array();
		foreach($connectionContainers as $connectionIndex => $connectionContainer){
			$connections[$connectionIndex]=self::getDbConnection($connectionContainer);
		}
		return $connections;
	}
	public static function saveDataConnection($connectionName,$yml){
		$configPath =  \str_replace('\\', '/', realpath(__DIR__.'/../../../../app/config/connections'));
		$configFilePath = $configPath.DIRECTORY_SEPARATOR.$connectionName.".yml";
		file_put_contents($configFilePath, $yml);
	}
	private static function getDbConnection($container){
		//Read Connection Parameters
		$host = $container->getParameter("database_host");
		$port = $container->getParameter("database_port");
		$name = $container->getParameter("database_name");
		if ($container->hasParameter("library_name")){
			$library_name = $container->getParameter("library_name");
		}
		else{
			$library_name = "";
		}
			
		$user=  $container->getParameter("database_user");
		if (empty($user)){
			if ($container->hasParameter("default_user")){
				$user = $container->getParameter("default_user");
			}
			else{
				$user="";
			}
		}		
		$pwd =  $container->getParameter("database_password");
		if (empty($pwd)){
			if ($container->hasParameter("default_password")){
				$pwd =  $container->getParameter("default_password");
			}
			else{
				$pwd = "";
			}
		}
		$driver = $container->getParameter("database_driver");
		$pdo = \str_replace('pdo_', '', $driver);

		if ( empty($name) || empty($driver) )
			throw new \Exception("Invalid External Database connection information provided!");

			//Connect
			try {
				$dsn = null;
				switch ($pdo){
					case "mysql":
						$dsn = $pdo.':host='.$host.(empty($port) ? '' : ';port='.$port).';dbname='.$name;
						break;
					case "sqlsrv":
						$dsn = $pdo.':Server='.$host.(empty($port) ? '' : ','.$port).';Database='.$name;
						break;
					case "pgsql":
						$dsn = $pdo.':host='.$host.(empty($port) ? '' : ';port='.$port).';dbname='.$name;
						break;
					case "odbc":
						$dsn = $pdo.':'.$name;
						break;
					case "sqlite":
						$dsn = $pdo.':'.$name;
						break;
					case "domino":
						$connectionInfo = array(
								"connection_name"=>$container->getParameter("connection_name"),
								"database_host"=>$host,
								"database_name"=>$name,
								"library_name"=>$library_name,
								"database_user"=>$user,
								"database_password"=>$pwd,
								"service_url"=> 
									$container->hasParameter("service_url") ?
									  $container->getParameter("service_url") : 
									  null
						);
						if (empty($connectionInfo["library_name"])) {
							$connectionInfo["library_name"]=$connectionInfo["database_name"];
						}
						//return new DominoConnection($connectionInfo);
						
					default:
						$dsn = $pdo.':host='.$host.';Server='.$host.(empty($port) ? '' : ','.$port).';Database='.$name.';dbname='.$name;
						break;
				}
				return new \PDO($dsn,$user,$pwd);
			} catch (\PDOException $e) {
				echo "PDO Exception: ".$e->getMessage();
				throw $e;
			}
	}
	public static function getConnectionNames(){
		$connectionContainers = self::getConfigurations();
		if (empty($connectionContainers) || !is_array($connectionContainers)){
			return null;
		}
		$connectionNames = array();
		$index = 0;
		foreach($connectionContainers as $connectionIndex => $connectionContainer){
			$connectionNames[$index]=self::getDbConnectionDetails($connectionContainer,$connectionIndex)['connection_name'];
			$index++;
		}
		
		return $connectionNames;
	}
	public static function getAllConnectionDetails(){
		$connectionContainers = self::getConfigurations();
		if (empty($connectionContainers) || !is_array($connectionContainers)){
			return null;
		}
		$connectionDetails = array();
		$index = 0;
		foreach($connectionContainers as $connectionIndex => $connectionContainer){
			$connectionDetails[$index]=self::getDbConnectionDetails($connectionContainer,$connectionIndex);
			$index++;
		}
		return $connectionDetails;
	}
	public static function getDbConnectionDetails($container,$fileName){
		if (!$container instanceof ContainerBuilder){
			//if this is not a container, then fetch the configuration container by name
			$container = self::getConfiguration($container);
		}
		
		if (empty($container)){
			return null;
		}
	
		//Read Connection Parameters
		$host = $container->getParameter("database_host");
		$port = $container->getParameter("database_port");
		$name = $container->getParameter("database_name");
		if ($container->hasParameter("library_name")){
			$library_name = $container->getParameter("library_name");
		}
		else{
			$library_name = "";
		}
			
		$user=  $container->getParameter("database_user");
		if (empty($user)){
			if ($container->hasParameter("default_user")){
				$user = $container->getParameter("default_user");
			}
			else{
				$user="";
			}
		}
		$pwd =  $container->getParameter("database_password");
		if (empty($pwd)){
			if ($container->hasParameter("default_password")){
				$pwd =  $container->getParameter("default_password");
			}
			else{
				$pwd = "";
			}
		}
		$driver = $container->getParameter("database_driver");
		
		$connectionName = str_replace(".yml","",$fileName); 
		return array(
			"getId" => $connectionName,
			"dockey" => $connectionName,
			"connection_name" => $connectionName,
			"host" => $host,
			"port" => $port,
			"name" => $name,
			"library_name" => $library_name,
			"user" => $user,
			"password" => $pwd,
			"driver" => $driver
		);
	}
}
?>