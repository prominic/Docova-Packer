# mxgraph-js

Just the JS portion of mxGraph. Do not submit PRs here, they belong in the mxGraph project.
