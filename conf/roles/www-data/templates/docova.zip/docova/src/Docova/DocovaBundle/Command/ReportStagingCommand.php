<?php
namespace Docova\DocovaBundle\Command;

use Doctrine\DBAL\Connection;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Docova\DocovaBundle\Extensions\ExternalConnections;
use Docova\DocovaBundle\Entity\ReportStagingLog;


/**
 * @author Jeff Primeau
 * Command to translate document field into into flattened and normalized tables for reporting
 *        
 */
class ReportStagingCommand extends ContainerAwareCommand 
{
	protected $output=null;
	protected $sourceFields = null;
	protected $sourceElementCount = null;
	protected $isMulti = false;
	protected $logFileName="";
	protected $sourceElementFirstMulti=null;
    protected $DEBUG=false;
    protected $builtInDateFields=array('Date_Created','Date_Modified','Released_Date','Last_Review_Date','Next_Review_Date','Custom_Archive_Date','Index_Date','Date_Archived','Date_Deleted');
    protected $builtInNameFields=array('Doc_Owner','Doc_Author','Created_By','Modified_By','Lock_Editor','Released_By','Deleted_By');
    
	protected function configure()
	{
		$this
			->setName('docova:reportstaging')
			->setDescription('Report Staging Command')
   			->addArgument(
           		'profileNameOrId',
               	InputArgument::REQUIRED,
                'The name or id of the staging profile to run'
            )
            ->addArgument(
                'logFileName',
                InputArgument::REQUIRED,
                'The name of the log file associated with this run'
                );         	
	}
	public static function isGUID($guid){
	    if (preg_match("/^(\{)?[a-f\d]{8}(-[a-f\d]{4}){4}[a-f\d]{8}(?(1)\})$/i", $guid)){
	        return true;
	    }
	    else{
	        return false;
	    }
	}
	protected function execute(InputInterface $input, OutputInterface $output)
	{
	    $this->output = $output;
		try {
		     $con = $this->getContainer()->get('doctrine')->getConnection();
		     $em = $this->getContainer()->get('doctrine')->getManager();
		     $profileNameOrId = $input->getArgument("profileNameOrId");
		     $this->logFileName = basename($input->getArgument("logFileName"));
		     //load profile by name or id
		     if ($this->isGUID($profileNameOrId)){
		         $profileData=$em->getRepository('DocovaBundle:ReportStagingProfile')->find($profileNameOrId);
		     }
		     
		     else{
		         $profileData=$em->getRepository('DocovaBundle:ReportStagingProfile')->findOneBy(array('Name' => $profileNameOrId));
		     }
		     if (empty($profileData))
		     {
		         $output->writeln("Error - Unable to locate report staging profile for [".$profileNameOrId."]");
		         return;
		     }
		    
		     echo PHP_EOL."Profile Name: ".$profileData->getName();
		     echo PHP_EOL."Profile ID: ".$profileData->getId();
		     echo PHP_EOL."Log File Name: ".$this->logFileName;
		     echo PHP_EOL."-------------------";
		  
		     $this->sourceElementCount = $this->getSourceFieldElementCount($profileData);
		     $this->sourceFields = $this->getSourceFieldNames($profileData,$this->sourceElementCount);
		     $this->sourceElementFirstMulti = $this->getFirstMultiValuedSource($profileData);
		     echo PHP_EOL."Source Element Count: ".$this->sourceElementCount;
		     echo PHP_EOL."Source Element First-Multi: ".$this->sourceElementFirstMulti;
		     $this->isMulti = $this->isSourceMultiValued($profileData);
		     echo PHP_EOL."Multivalued: ".json_encode($this->isMulti);		     
		     echo PHP_EOL."-------------------";
		     $runDate = new \DateTime();		     		     
		     		     
		     echo PHP_EOL."Reading document data".PHP_EOL;
		     $documentData  = $this->getDocumentData($con,$profileData,$profileData->getLastRunDate());
		     $deletedDocumentData  = $this->getDocumentData($con,$profileData,$profileData->getLastRunDate(),true);
		     $modifiedDocumentData = $this->getDocumentData($con,$profileData,$profileData->getLastRunDate(),false,true);
		     
		     echo PHP_EOL."Read document data".PHP_EOL;
		     		
		     
			 if (empty($documentData)){
			     $output->writeln("No document data found for profile - ".$profileNameOrId );
			 }
			 else{
			     $output->writeln("Loading document type schema");
			     $docTypeFieldInfo = $this->getDocTypeFieldInfo($con, null, $profileData);
			     
			     $output->writeln("Obtaining external connection");
			     $extConn = ExternalConnections::getConnection($profileData->getConnectionName());
			     
			     if (empty($extConn)){
			         $output->writeln("Unable to connect to connection named: ".$profileData["connectionName"]);
			         return;
			     }
			     //drop table?
			     if (!empty($profileData->getDropTable())){
			         $output->writeln("Dropping table ".$profileData->getTableName());
			         $extConn->exec("DROP TABLE ".$profileData->getTableName());
			         if (!empty($extConn->errorInfo()[1])){
			             $output->writeln("WARNING: ".json_encode($extConn->errorInfo()));
			         }
			     }
			     
			     //create table?
			     //when flag is set and dropping table or the first run
			     //where create table is true, and either no last run date or drop table is enabled
			     if (!empty($profileData->getCreateTable()) && ( empty($profileData->getLastRunDate()) || !empty($profileData->getDropTable())) ){
			         $driverName = $extConn->getAttribute(\PDO::ATTR_DRIVER_NAME);
			         $output->writeln("Creating table ".$profileData->getTableName()." for ".$driverName);
			         if ($profileData->getTranslationType()=="One to Many"){
			             $stmt = $this->generateCreateTableStatement($driverName,$profileData, $docTypeFieldInfo,true);
			         }
			         else{
			             $stmt = $this->generateCreateTableStatement($driverName,$profileData, $docTypeFieldInfo);
			         }
			         $output->writeln("SQL: ".$stmt);
			         $extConn->exec($stmt);
			         if (!empty($extConn->errorInfo()[1])){
			             $output->writeln(PHP_EOL."ERROR: ".json_encode($extConn->errorInfo()));
			         }
			     }		
			     $newAndModifiedCount = count($documentData);
			     $modifiedCount = count($modifiedDocumentData);
			     $deletedDocumentCount = count($deletedDocumentData);
			     echo PHP_EOL."New Documents: ".($newAndModifiedCount-$modifiedCount).",  Modified Documents: ".$modifiedCount.",  Deleted Documents: ".$deletedDocumentCount.PHP_EOL;
			     echo "Purging ".$deletedDocumentCount." related external record(s) that have been deleted in DOCOVA".PHP_EOL;
			     $deletedDocumentIds = $this->getColumnValuesArray($deletedDocumentData, 'id');
			     $purgeCount = $this->purgeRelatedRecords($extConn, $profileData, $deletedDocumentIds);
			     if (empty($purgeCount)){
			         $purgeCount=0;
			     }
			     echo "Purged ".$purgeCount." related external record(s) that have been deleted in DOCOVA".PHP_EOL;
			     
			     echo "Purging ".$modifiedCount." related external record(s) that have been modified in DOCOVA".PHP_EOL;
			     $modifiedDocumentIds = $this->getColumnValuesArray($modifiedDocumentData, 'id');
			     $purgeCountModified=$this->purgeRelatedRecords($extConn, $profileData, $modifiedDocumentIds);
			     if (empty($purgeCountModified)){
			         $purgeCountModified=0;
			     }
			     echo "Purged ".$purgeCountModified." related external record(s) that have been modified in DOCOVA".PHP_EOL;
			     
			     // Transfer types
			     // 1.  One to One mapping 
			     // 2.  One to Many mapping through multiple source fields
			     // 3.  One to Many mapping through multi-valued source fields			     
			     $inserts = $this->generateTableInsertStatements($con,$extConn, $profileData, $documentData, $docTypeFieldInfo,$profileData->getLastRunDate());
			     echo PHP_EOL.$inserts." record(s) have been created or modified".PHP_EOL;
			     

			     if (!empty($extConn->errorInfo()[1])){
			         $output->writeln(PHP_EOL."ERROR: ".json_encode($extConn->errorInfo()));
			     }			    
			     
			 }
			 if (empty($documentData)) {
			     $newAndModifiedCount = 0;
			     $modifiedCount = 0;
			     $deletedDocumentCount = 0;
			     $inserts=0;
			     $purgeCount=0;
			     $purgeCountModified=0;			     
			 }
			 $profileData->setLastRunDate($runDate);
			 $em->persist($profileData); // create entity record
			 $em->flush(); // commit entity record
			 
			 $this->createDataPresentationLog($em, $profileData, ($newAndModifiedCount-$modifiedCount), $modifiedCount, $deletedDocumentCount, $inserts-$purgeCountModified, $purgeCountModified,$purgeCount);
		}
		catch (\PDOException $e) {
		    $this->createDataPresentationLog($em, $profileData, 0, 0, 0, 0, 0 , 0);
			echo "Data Extract command - PDO Exception: ".$e->getMessage()." Code: ".$e->getCode()." on line ". $e->getLine() . PHP_EOL;
		}
		 catch (\Exception $e) { 
		     $this->createDataPresentationLog($em, $profileData, 0, 0, 0, 0, 0 , 0);
		     echo "Data Extract command - Exception: ".$e->getMessage()." on line ". $e->getLine() . PHP_EOL;
		}
		catch (\Throwable $t) {
		    $this->createDataPresentationLog($em, $profileData, 0, 0, 0, 0, 0 , 0);
		    echo "Data Extract command - Exception: ".$t->getTraceAsString()." on line ". $t->getLine() . PHP_EOL;
		    echo "ERROR - ".$t->getMessage().PHP_EOL;
		}
		echo "Data Extract command - execute - End".PHP_EOL;
	}
	protected function createDataPresentationLog($em,$profile,$NewDocuments,$ModifiedDocuments,$DeletedDocuments,$inserts,$updates,$deletions){
	    $log = new ReportStagingLog();
	    $log->setNewDocuments($NewDocuments);
	    $log->setModifiedDocuments($ModifiedDocuments);
	    $log->setDeletedDocuments($DeletedDocuments);
	    $log->setInserts($inserts);
	    $log->setUpdates($updates);
	    $log->setDeletions($deletions);
	    $log->setProfileId($profile->getId());
	    $log->setRunDate($profile->getLastRunDate());
	    $log->setRunCompletedDate(new \DateTime());
	    $log->setLogFile($this->logFileName);
	    $em->persist($log); // create entity record
	    $em->flush(); // commit entity record
	}
	protected function generateCreateTableStatement($driver,$profileData,$docTypeFieldInfo,$isMulti=false){
	    $stmt = "CREATE TABLE ".$profileData->getTableName()."( ".PHP_EOL;
	    
	    if ($driver=="mysql"){
	        if ($isMulti){
	            $stmt.=" id VARCHAR(64) NOT NULL,".PHP_EOL.
	            "value_order integer NOT NULL";
	        }
	        else{
	            $stmt.=" id VARCHAR(64) NOT NULL PRIMARY KEY";
	        }
	    }
	    else{
    	    if ($isMulti){
    	        $stmt.=" id UNIQUEIDENTIFIER NOT NULL,".PHP_EOL.
    	        "value_order integer NOT NULL";
    	    }
    	    else{
    	       $stmt.=" id UNIQUEIDENTIFIER NOT NULL PRIMARY KEY";
    	    }
	    }
	    $index = 0;
	    $sourceFields=$profileData->getSourceFields();
	    foreach($profileData->getDestinationFields() as $destField){
	        
	        if (!empty($destField)){
	            $sourceField=$sourceFields[$index];
	            $fieldList = explode(PHP_EOL,$sourceField);
	            
                //get the type from the first one in the list
                $sourceField=$fieldList[0];
	            
	            if (!empty($docTypeFieldInfo[$sourceField])){	                
	                $sourceType = $docTypeFieldInfo[$sourceField]['type'];
	            }
	            else{
	                $sourceType = "text";
	            }
	            	            
	            //handle typing of build in document properties
	            if (in_array($destField, $this->builtInDateFields)){
	                $sourceType="date";
	            }
	            else if (in_array($destField, $this->builtInNameFields)){
	                $sourceType="name";
	            }
	            
	            if ($sourceType=="date"){
	                if ($driver=="mysql"){
	                   $stmt.= ",".PHP_EOL." ".$destField ." DATETIME";
	                }
	                else{
	                   $stmt.= ",".PHP_EOL." ".$destField ." DATETIME2";
	                }
	            }
	            else if ($sourceType=="number"){
	                $stmt.= ",".PHP_EOL." ".$destField ." FLOAT";
	            }
	            else if ($sourceType=="name"){
	                $stmt.= ",".PHP_EOL." ".$destField ." NVARCHAR(255)";
	            }
	            else {
	                if ($driver=="mysql"){
	                    $stmt.= ",".PHP_EOL." ".$destField ." LONGTEXT";
	                }
	                else{
    	                $stmt.= ",".PHP_EOL." ".$destField ." NVARCHAR(MAX) ";
	                }
	            }
	        }
	        $index++;
	    }
	    if ($isMulti){
	        if ($driver=="mysql"){
	            $stmt.= ",".PHP_EOL."CONSTRAINT pk PRIMARY KEY (id,value_order)";
	        }
	        else{
    	        //defined the concatenated key
	           $stmt.= PHP_EOL."PRIMARY KEY (id,value_order)";
	        }
	    }
	    
	    $stmt .= PHP_EOL.")";
	    return $stmt;
	}
	protected function processDocumentData($con,$profileData,$documentData,$docTypeFieldInfo){
	    foreach($documentData as $document ){
	        $fieldValues = $this->getDocumentFieldValues($con, $document, $profileData, $docTypeFieldInfo);
	        echo PHP_EOL."Field values for document: ".$document["id"];
	        echo PHP_EOL.json_encode($fieldValues,JSON_PRETTY_PRINT);
	    }
	}
	protected function getMaxFieldOrder($con,$id,$profileData,$docTypeFieldInfo){
	    //locate the detail for the first multi-valued source field
	    $type = $docTypeFieldInfo[$this->sourceElementFirstMulti]['type'];
	    $fieldId = $docTypeFieldInfo[$this->sourceElementFirstMulti]['id'];
	    
	    //now compute the appropriate maximum elements select statement from it
	    if ($type=="number"){
	        $SQL = "SELECT MAX(Value_Order) FROM tb_form_numeric_values WHERE doc_id='".$id."' AND Field_id='".$fieldId."'";
	    }
	    else if ($type=="date"){
	        $SQL = "SELECT MAX(Value_Order) FROM tb_form_numeric_values WHERE doc_id='".$id."' AND Field_id='".$fieldId."'";
	    }
	    else if ($type=="name"){
	        //for names the maximum value order could be in either the name or the group table select both and then choose return the maximum 
	        $SQL = "SELECT MAX(Value_Order) FROM ( ".PHP_EOL.
	            "SELECT MAX(Value_Order) AS Value_Order FROM tb_form_name_values WHERE doc_id='".$id."' AND Field_id='".$fieldId."'".PHP_EOL.
	            " UNION ".PHP_EOL.
	            " SELECT MAX(Value_Order) AS Value_Order FROM tb_form_group_values WHERE doc_id='".$id."' AND Field_id='".$fieldId."'".
	            ") T";
	    }
	    else{
	        $SQL = "SELECT MAX(Value_Order) FROM tb_form_text_values WHERE doc_id='".$id."' AND Field_id='".$fieldId."'";
	    }
	    return $con->fetchArray($SQL);
	}
	protected function generateTableInsertStatements($con,$extCon,$profileData,$documentData,$docTypeFieldInfo,$since=null){
	    $destinationFields = array();	    
	    foreach($profileData->getDestinationFields() as $destField){
	        if (!empty($destField)){
	            $destinationFields[]=$destField;
	        }
	    }
	    $destinationFields = implode(',',$destinationFields);
	    $stmts=array();
	   	    
	    echo PHP_EOL."Inserting document data";
	    if (!empty($since)){
	       echo " created or modified since ".$since->format('Y-m-d H:i:s');
	    }
	    
	    $inserts=0;
	    
	    foreach($documentData as $document ){
	        //no longer required since this is performed in bulk
	        /*
	        if (!empty($since) && !empty($document['Date_Modified'] ) ){	           
	            $dtModified = \DateTime::createFromFormat('Y-m-d H:i:s', str_replace('.000000', '', $document['Date_Modified']));
	            if ($dtModified->getTimestamp() >= $since->getTimestamp() ){
	                //this document has been modified since the last run, remove the existing related documents
	                //echo PHP_EOL."Removed modified document ".$document['id'].PHP_EOL;
	                $this->purgeRelatedRecords( $extCon, $profileData, $document['id'] );	
	            }
	        }
	        else{
	            echo PHP_EOL."Modified: ".json_encode($document['Date_Modified'] ).PHP_EOL;
	        }
	        */
	        $fieldValues = $this->getDocumentFieldValues($con, $document, $profileData, $docTypeFieldInfo);
	        if (empty($fieldValues)){
	            echo PHP_EOL."No field values found for document: ".$document['id'];
	            return;
	        }
	        else{
	            if ($this->DEBUG) {echo PHP_EOL."Field Values: ".PHP_EOL.json_encode($fieldValues,JSON_PRETTY_PRINT);}
	        }
	        echo PHP_EOL."Processing data insert for document ".$document['id'];
	        
	        
	        $elementCount=1;
	        $docRows = count($fieldValues);
	        if ($docRows>1){
	            //we have more than one row of data for this document, then we need to process each row separately
	           $elementCount = $docRows;    
	        }
	        
	        $sourceFields = $profileData->getSourceFields();
	        for($e=1;$e<=$elementCount;$e++){
	            $index = 0;
	            $values = array();
	            if ($profileData->getTranslationType()=="One to One"){	            
	                $stmt="INSERT INTO ".$profileData->getTableName()." (id,".$destinationFields.") VALUES (".PHP_EOL;
	                $stmt.="     '".$document['id']."',".PHP_EOL;	                
	            }
	            else{
	                //include the order in the index
	                $stmt="INSERT INTO ".$profileData->getTableName()." (id,value_order,".$destinationFields.") VALUES (".PHP_EOL;
	                $stmt.="     '".$document['id']."',".PHP_EOL;
	                //when multivalued, the order index is required
	                $stmt.="     ".($e-1).",".PHP_EOL;
	            }

	            //verify that each row of data returns at least one non-null row
	            $hasData = false;
	            
        	    foreach($profileData->getDestinationFields() as $destField){
        	        if (!empty($destField) ) {
        	            $sourceField=$sourceFields[$index];
        	            $fieldList = explode(PHP_EOL,$sourceField);
        	            
        	            //get the type from the first one in the list
        	            $sourceField=$fieldList[0];
        	            
        	            if (empty($fieldValues[$e-1][$destField])){        	                
        	                $sourceFieldValue = null;
        	            }
        	            else{
        	               $sourceFieldValue = $fieldValues[$e-1][$destField];
        	            }
        	            if (! is_null($sourceFieldValue)){
        	                $hasData=true;
        	            }
        	            if (empty($docTypeFieldInfo[$sourceField])){
        	               $sourceType = "text"; 
        	            }
        	            else{
        	               $sourceType = $docTypeFieldInfo[$sourceField]['type'];
        	            }
        	            if ($sourceType=="number"){
        	                if (empty($sourceFieldValue)){
        	                    $values[] = '     0';
        	                }
        	                else{
        	                    $values[] = '     '.$sourceFieldValue;
        	                }
        	            }
        	            else if (($sourceType=="date" || in_array($sourceField,$this->builtInDateFields)) && empty($sourceFieldValue)) {
        	                $values[] = '     null';
        	            }
        	            else {
        	                $values[] = '     '."'".str_replace("'", "''", $sourceFieldValue)."'";
        	            }
        	            
        	        }
        	        $index++;
        	    }
        	    
        	    if ($hasData){
            	    $stmt.=implode(",".PHP_EOL,$values);
            	    $stmt .= PHP_EOL.");".PHP_EOL;
            	                	    
            	    if ($this->DEBUG) {echo PHP_EOL.PHP_EOL.$stmt;}
            	    $stmts[]=$stmt;
        	    }
        	    else if (!empty($document)){
        	        echo PHP_EOL."Document ".$document['id']." has no associated data";
        	    }
        	    
        	    if (count($stmts)==100){
        	        echo PHP_EOL."Posting batch of 100";
        	        $finalStmt = implode(PHP_EOL,$stmts);
        	      //  echo PHP_EOL."Final Statement: ".PHP_EOL.$finalStmt;
        	        $result = $extCon->exec($finalStmt);
        	        if ($result!=0){
        	            $inserts+=100;
        	        }
        	        echo PHP_EOL.$inserts." Record(s) posted";
        	        $stmts=array();
        	    }
	        }    	    
    	    
	    }

	    if (count($stmts)>0){
	        echo PHP_EOL."Posting batch of ".count($stmts);
	        $finalStmt = implode(PHP_EOL,$stmts);
	        //echo PHP_EOL."Final Statement: ".PHP_EOL.$finalStmt;
	        $result = $extCon->exec($finalStmt);
	        if ($result!=0){
	            $inserts+=count($stmts);
	        }
	        echo PHP_EOL.$inserts." Record(s) posted";
	        $stmts=array();
	    }
	    return $inserts;
	}
	protected function getFirstMultiValuedSource($profileData){
	    $index = 0;
	    $sourceFields=$profileData->getSourceFields();
	    foreach($profileData->getSourceFieldsMultiValued() as $multi){
	        if (!empty($multi) ) {
	            $sourceField = $sourceFields[$index];
	            $fieldList = explode(PHP_EOL,$sourceField);
	            return $fieldList[0];
	        }
	        $index++;
	    }
	    
	}
	protected function isSourceMultiValued($profileData){	    	    
	    foreach($profileData->getSourceFieldsMultiValued() as $multi){
	        if (!empty($multi) ) {	            
	                return true;	            
	        }	        
	    }
	    return false;
	}
	protected function getSourceFieldElementCount($profileData){	    
	    $elementCount = 0;
	    //get the largest number of source fields specified for a single mapping
	    echo PHP_EOL."Source Fields: ".json_encode($profileData->getSourceFields());
	    foreach($profileData->getSourceFields() as $sourceField){
	        $fieldList = explode(PHP_EOL,$sourceField);
	        
	        if (!empty($sourceField) && count($fieldList)>1 && count($fieldList)>$elementCount){
	            $elementCount = count($fieldList);
	        }
	    }
	    return $elementCount;
	}
	
	protected function getSourceFieldNames($profileData,$sourceElementCount=1){
	    $sourceFieldNames = array();
	    if ($sourceElementCount>1){
	        
    	        for ($i=0;$i<$sourceElementCount;$i++) {
    	            $sourceNames = array();
    	            foreach($profileData->getSourceFields() as $sourceField){
    	                if (empty($sourceField)){
    	                    continue;
    	                }
    	                $fieldList=explode(PHP_EOL,$sourceField);
    	                if (count($fieldList)==1){
    	                    $sourceNames[]=$fieldList[0];
    	                }
    	                else{
    	                    $sourceNames[]=$fieldList[$i];
    	                }    	                
    	            }
    	            $sourceFieldNames[]=$sourceNames;
    	        }
	    }
	    else {
	        $sourceFieldNames[] = $profileData->getSourceFields();
	    }
	    return $sourceFieldNames;
	}
	
	protected function getDocumentFieldValues($con,$document,$profileData,$docTypeFieldInfo){
	    $stmt = "SELECT * FROM ( ".PHP_EOL.
        "   VALUES (";
	    
	    if ($this->sourceElementCount>1){
	        $elementCount = 1;
	       
	        $sourceRows = 0;	       
	        foreach ($this->sourceFields as $sourceNames){
	            $values=array();
	            $sourceRows++;
	            if ($sourceRows>1){
	                //start a new values row
	                $stmt.=PHP_EOL."   , (";
	            }
	            $index = 0;
	            foreach($sourceNames as $sourceName){
	                if (!empty($sourceName) ) {	                    
	                    //only provide the order when multi-valued
	                    if (empty($profileData->getSourceFieldsMultiValued()[$index])){
	                        //do not add the order to the query when not multi-valued
	                        $thisValueOrder =  null;
	                    }
	                    else{
	                       $thisValueOrder = $index;
	                    }
	                    $values[] = $this->getFieldValueStatement($document, $sourceName, $docTypeFieldInfo, $thisValueOrder);
	                }
	                $index++;
	            }
	            
	            $stmt.=implode(",".PHP_EOL,$values);
	            $stmt.=PHP_EOL.")";
	            
	            if ($this->DEBUG) {echo PHP_EOL.$stmt;}
	        }
	        $destinationFields = array();
	        foreach($profileData->getDestinationFields() as $destField){
	            if (!empty($destField)){
	                $destinationFields[]=$destField;
	            }
	        }
	        
	        $destinationFields = implode(',',$destinationFields);
	        $stmt.=PHP_EOL.") T (".$destinationFields.")";
	        
	        if ($this->DEBUG) {echo PHP_EOL."SQL:".PHP_EOL.$stmt;}
	        $results=$con->fetchAll($stmt);
	        return $results;
	    }
	    else{
	        $elementCount = 1;
	        if ($this->isMulti){
	           
    	        $maxElements = $this->getMaxFieldOrder($con, $document['id'], $profileData, $docTypeFieldInfo);    	  
    	        if ($this->DEBUG) {echo PHP_EOL."Multi valued count: ".json_encode($maxElements);}
    	        if (!empty($maxElements) && is_array($maxElements) && is_numeric($maxElements[0]) && $maxElements[0]>1 ){
    	            $elementCount = $maxElements[0]+1;
    	        }
    	        else{
    	            $elementCount = 0;
    	        }
    	        if ($this->DEBUG) {echo PHP_EOL."Element Count: ".$elementCount.PHP_EOL;}
	        }
	        $sourceFields=$profileData->getSourceFields();
	        if ($elementCount>0){
    	        for ($i=1;$i<=$elementCount;$i++){
    	            $values=array();
    	            if ($i>1){
    	                //start a new values row
    	                $stmt.=PHP_EOL."   , (";
    	            }
    	            $index = 0;
    	            foreach($profileData->getDestinationFields() as $destField){
    	                if (!empty($destField) ) {
    	                    $sourceField=$sourceFields[$index];
    	                    $fieldList = explode(PHP_EOL,$sourceField);
    	                    
    	                    //get the type from the first one in the list
    	                    $sourceField=$fieldList[0];
    	                    
    	                    //only provide the order when multi-valued	                    
    	                    $thisValueOrder = $this->isMulti ? $i-1 : null;
						
							$field_values = $this->getFieldValueStatement($document, $sourceField, $docTypeFieldInfo, $thisValueOrder);
							if (! empty($field_values)) {
								$values[] = $field_values;
							}
    	                }
    	                $index++;
    	            }
    	            
    	            $stmt.=implode(",".PHP_EOL,$values);
    	            $stmt.=PHP_EOL.")";
    	            
    	            if ($this->DEBUG) {echo PHP_EOL.$stmt;}
    	        }
	       
	        $destinationFields = array();
	        foreach($profileData->getDestinationFields() as $destField){
	            if (!empty($destField)){
	                $destinationFields[]=$destField;
	            }
	        }
	        
	        $destinationFields = implode(',',$destinationFields);
	        $stmt.=PHP_EOL.") T (".$destinationFields.")";
	        
	        if ($this->DEBUG) {echo PHP_EOL.$stmt;}
	        
	        $results=$con->fetchAll($stmt);
	        }
	        else{
	            echo PHP_EOL."No field data found for document ".$document['id'];
	            $results=null;
	        }
	        return $results;
	    }  
	    
	    
	}
	protected function getFieldValueStatement($document,$sourceField,$docTypeFieldInfo,$valueOrder=null){	    
	    $id = $document["id"];
	    if (array_key_exists($sourceField,$docTypeFieldInfo)) {
	        $fieldId = $docTypeFieldInfo[$sourceField]['id'];
	        $type = $docTypeFieldInfo[$sourceField]['type'];
	        
	        //handle typing of build in document properties
	        if (in_array($sourceField, $this->builtInDateFields)){
	            $type="date";
	        }
	        else if (in_array($sourceField, $this->builtInNameFields)){
	            $type="name";
	        }
	        
	        
	        $valueOrderSelect = "";
	        
	        if (is_numeric($valueOrder)){
	            //this is a multi-valued field, the value order (index) must be included
	            $valueOrderSelect = " AND Value_Order=".$valueOrder;
	        }
	        	        
	        if ($type=="date"){
	            return "(SELECT Field_Value FROM tb_form_datetime_values WHERE doc_id='".$id."' AND field_id='".$fieldId."' ".$valueOrderSelect.")";
	        }
	        else if ($type=="number"){
	            return "(SELECT Field_Value FROM tb_form_numeric_values WHERE doc_id='".$id."' AND field_id='".$fieldId."' ".$valueOrderSelect.")";
	        }
	        else if ($type=="name"){
	            //the value could be in either the name or the group table, locate the id of the name or group value, 
	            //then lookup the name from the user accounts or user role tables
	            return "(SELECT user_name_dn_abbreviated as Field_Value FROM tb_user_accounts WHERE id=".PHP_EOL.
	            "   (SELECT Field_Value FROM tb_form_name_values ".PHP_EOL.
	            "    WHERE doc_id='".$id."' AND field_id='".$fieldId."' ".$valueOrderSelect." ".PHP_EOL.
	            "    ) ".PHP_EOL.
	            "    UNION ".PHP_EOL.
	            "    SELECT group_name As Field_Value FROM tb_user_roles WHERE id=".PHP_EOL.
	            "    (SELECT Field_Value FROM tb_form_group_values ".PHP_EOL.
	            "        WHERE doc_id='".$id."' AND field_id='".$fieldId."' ".$valueOrderSelect." ".PHP_EOL.
	            "        ))";
	                
	        }
	        else {
	            return "(SELECT Field_Value FROM tb_form_text_values WHERE doc_id='".$id."' AND field_id='".$fieldId."' ".$valueOrderSelect.")";
	        }
	        
	    }
	    else if (array_key_exists($sourceField, $document)){
	        if (!empty($document[$sourceField])){
	            return "'".str_replace("'", "''", $document[$sourceField])."'";
	        }
	        else{
	            return "null";
	        }
	    }
	}
	/*
	protected function getFieldValueStatement_($document,$sourceField,$docTypeFieldInfo,$fieldValues){
	    $id = $document["id"];
	    if (array_key_exists($sourceField, $document)){
	        if (!empty($document[$sourceField])){
	            return "'".str_replace("'", "''", $document[$sourceField])."'";
	        }
	        else{
	            return "null";
	        }	        
	    }
	    else if (array_key_exists($sourceField, $fieldValues)){
	       if ($docTypeFieldInfo[$sourceField]){
	           $fieldType = $docTypeFieldInfo[$sourceField]['type'];
	       }
	       else{
	           $fieldType = "text";
	       }
	       
	       if ($fieldType=="number"){
	           return $fieldValues[$sourceField];
	       }
	       else{
	           return "'".str_replace("'", "''", $fieldValues[$sourceField])."'";
	       }
	    }
	}
	*/
	public function loadProfile($extraction_file){	    
	    if (! file_exists($extraction_file)){
	        return "";
	    }
	    else{
	        $profileData = file_get_contents($extraction_file);
	        if (!empty($profileData)){
	            return json_decode($profileData,true);
	        }
	        return "";
	    }
	}
	
	//select attachment data using supplied custom date field range
	public function getDocumentData($con,$data,$since,$trash_only=false,$modified_only=false){
	   
	    if ($trash_only){
	        if (empty($since)){
	            $SQL = "-- All related document data that has been deleted".PHP_EOL;
	        }
	        else{
	           $SQL = "-- All related document data that has been deleted since the last run".PHP_EOL;
	        }
	    }
	    else if ($modified_only){
	        if (empty($since)){
	           $SQL = "-- All related document data that has been modified".PHP_EOL;
	        }
	        else{
	            $SQL = "-- All related document data that has been modified since the last run".PHP_EOL;
	        }
	    }
	    else{
	        if (empty($since)){
	            $SQL = "-- All related document data".PHP_EOL;
	        }
	        else{
	           $SQL = "-- All related document data that has been created or modified since the last run".PHP_EOL;
	        }
	    }
	    
	    if ($data->getRepositoryType()=="Libraries"){
    	    $SQL.= "SELECT ".($modified_only || $trash_only ? "d.id" : "d.*")." FROM tb_folders_documents d ".PHP_EOL.
    	   	    "JOIN tb_library_folders f on f.id = d.folder_id ".PHP_EOL.
    	   	    "JOIN tb_libraries l on l.id = f.library_id ".PHP_EOL.
    	   	    "WHERE 1=1 ";
	    }
	    else{
	        $SQL.= "SELECT ".($modified_only || $trash_only ? "d.id" : "d.*")." FROM tb_folders_documents d ".PHP_EOL.
	   	        "JOIN tb_app_forms f on f.id = d.app_form_id ".PHP_EOL.
	   	        "JOIN tb_libraries l on l.id = f.app_id ".PHP_EOL.
	   	        "WHERE 1=1 ";
	    }

	    //optionally process additional selection criteria
	    //***********************************************
	    $criteria=$this->getSelectionCriteria(1, $data);
	    if (!empty($criteria)){
	        $SQL.=PHP_EOL.$criteria;
	    }
	    $criteria=$this->getSelectionCriteria(2, $data);
	    if (!empty($criteria)){
	        $SQL.=PHP_EOL.$criteria;
	    }
	    $criteria=$this->getSelectionCriteria(3, $data);
	    if (!empty($criteria)){
	        $SQL.=PHP_EOL.$criteria;
	    }
	    //***********************************************	    
	    
	    if ($data->getRepositoryType()=="Libraries"){
	        $SQL.=PHP_EOL." AND l.trash=0 and f.del=0 and d.trash=".($trash_only ? '1' : '0')." ";
	    }
	    else{
	        $SQL.=PHP_EOL." AND l.trash=0 and d.trash=".($trash_only ? '1' : '0')." ";
	    }
	    if (!empty($data->getLibraries()) ){
	        $SQL.=PHP_EOL." AND l.id IN ".$this->getSQLList($data->getLibraries())." ";
	    }
	    
	    if ($data->getRepositoryType()=="Libraries"){
    	    if (!empty($data->getDoc_type_id()) ){
    	        $SQL.=PHP_EOL." AND d.doc_type_id IN ".$this->getSQLList(array($data->getDoc_type_id()))." ";
    	    }
	    }
	    else{
	        $SQL.=PHP_EOL." AND d.app_form_id IN ".$this->getSQLList(array($data->getDoc_type_id()))." ";
	    }
	    
	    if ($since!=null && $trash_only==false){
	        $dtSince = $since->format('Y-m-d H:i:s');
	    
	        if ($modified_only==false){
	            //only the documents created or modified on or after the last run
	            $SQL.=PHP_EOL." AND (d.Date_Created>='".$dtSince."' OR d.Date_Modified>='".$dtSince."') ";
	        }
	        else{
	            //only the documents modified on or after the last run
	            //use the creation date as the modification date if no modification date is available
	            $SQL.=PHP_EOL." AND ( ( d.Date_Modified IS NULL AND d.Date_Created>='".$dtSince."' ) OR ( d.Date_Modified>='".$dtSince."') )";
	        }
	    }
	    else if ($since!=null && $trash_only==true){
	        $dtSince = $since->format('Y-m-d H:i:s');
	        $SQL.=PHP_EOL." AND d.Date_Deleted>='".$dtSince."' ";
	    }
	    $this->writeln(PHP_EOL."SQL: ".PHP_EOL.$SQL);
	    
	    $result = $con->fetchAll($SQL);
	    if (!empty($result) && is_array($result) ){
	        $this->writeln(PHP_EOL."Results Found: ".PHP_EOL.count($result));
	    }
	    else{
	        $this->writeln(PHP_EOL."Results Found: ".PHP_EOL."0");
	    }
	    return $result;
	    
	}
	protected function purgeRelatedRecords($con,$profileData,array $ids) {
	    $stmt = "DELETE FROM ".$profileData->getTableName()." WHERE id IN ".$this->getSQLList($ids)."";
	    return $con->exec($stmt);
	}
	
	protected function getColumnValuesArray(array $data,$key){
	    $column=array();
	    foreach($data as $row){	        
	        if (array_key_exists($key, $row)){
	            $column[]=$row[$key];
	        }
	    }
	    return $column;
	}
	protected function getDocTypeFieldInfo($con, $request,$data_source){
	    $docTypes = array();
	    if (empty($data_source->getDoc_type_id())){
	        $docTypes = $request->request->get('DocTypeKey');
	    }
	    else{
	        $docTypes = $data_source->getDoc_type_id();
	    }
	    if (!is_array($docTypes)){
	        $docTypes = array($docTypes);
	    }
	    
	    if (empty($data_source->getRepositoryType()) && !empty($request)  ){
	        $repType = $request->request->get('RepositoryType');
	    }
	    else{
	        $repType = $data_source->getRepositoryType();
	    }
	    
	    if ($repType=="Libraries"){
	        $stmt="select id,Field_Name,Field_Type FROM tb_design_elements ".
	   	        "WHERE subform_id IN ( ".
	   	        "    select subform_id from tb_doc_type_subforms ".
	   	        "    JOIN tb_subforms sf on sf.id = subform_id ".
	   	        "    WHERE doc_type_id IN ".$this->getSQLList($docTypes).
	   	        "    AND sf.Is_Custom=1 ".
	   	        "    ) ORDER BY Field_Name";
	    }
	    else {
	        $stmt="select id,Field_Name,Field_Type FROM tb_design_elements ".
	   	        "WHERE Form_id IN ".$this->getSQLList($docTypes).
	   	        "   ORDER BY Field_Name";
	    }
	    
	    $docTypeFieldInfo =  $con->fetchAll($stmt);
	    
	    
	    $docTypeData = array();
	    foreach($docTypeFieldInfo as $docTypeField){
	        $id = $docTypeField["id"];
	        if ($docTypeField["Field_Type"]==1){
	            $type="date";
	        }
	        else if ($docTypeField["Field_Type"]==4){
	            $type="number";
	        }
	        else if ($docTypeField["Field_Type"]==3){
	            $type="name";
	        }
	        else{
	            $type="text";
	        }
	        
	        $docTypeData[$docTypeField["Field_Name"]]=array("type"=>$type,"id"=> $id);
	    }	    
	    
	    return $docTypeData;
	}
	
	protected function getSelectionCriteria($selectionNumber,$data){
	    $fieldNames=$data->getCriteriaFieldNames();
	    $fieldTypes=$data->getCriteriaFieldTypes();
	    $fieldOperators=$data->getCriteriaFieldOperators();
	    $fieldValues=$data->getCriteriaFieldValues();
	    $i=$selectionNumber-1;
	    
	    if (!empty($fieldNames[$i]) && !empty($fieldTypes[$i]) && !empty($fieldOperators[$i] ) ){
	        //process criteria
	        if ($fieldTypes[$i]=="text"){
	            return " AND d.id IN (SELECT doc_id FROM tb_form_text_values WHERE ".
	   	            "Field_Id IN (SELECT id from tb_design_elements WHERE Field_Name='".$fieldNames[$i]."') ".
	   	            " AND Summary_Value ".$fieldOperators[$i] ." '".$fieldValues[$i]."')";
	        }
	        else if ($fieldTypes[$i]=="date"){
	            return " AND d.id IN (SELECT doc_id FROM tb_form_datetime_values WHERE ".
	   	            "Field_Id IN (SELECT id from tb_design_elements WHERE Field_Name='".$fieldNames[$i]."') ".
	   	            " AND Field_Value ".$fieldOperators[$i] ." '".$fieldValues[$i]."')";
	        }
	        else if ($fieldTypes[$i]=="number"){
	            return " AND d.id IN (SELECT doc_id FROM tb_form_numeric_values WHERE ".
	   	            "Field_Id IN (SELECT id from tb_design_elements WHERE Field_Name='".$fieldNames[$i]."') ".
	   	            " AND Field_Value ".$fieldOperators[$i] ." ".$fieldValues[$i].")";
	        }
	    }
	    else{
	        return "";
	    }
	}
	
	protected function writeln($line){
	    $this->output->writeln($line);
	}
	protected function getSQLList(array $data){
	    $list = "(";
	    foreach($data as $index=>$value){
	        if ($index!=0){
	            $list.=",";
	        }
	        $list.="'".$value."'";
	    }
	    $list.=")";
	    return $list;
	}
	
}