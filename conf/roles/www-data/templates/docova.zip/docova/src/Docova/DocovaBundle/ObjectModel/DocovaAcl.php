<?php

namespace Docova\DocovaBundle\ObjectModel;

use Docova\DocovaBundle\Entity\Libraries;
use Docova\DocovaBundle\Security\User\CustomACL;

/**
 * Back-end class to handle application acl
 * @author javad_rahimi
 */
class DocovaAcl 
{
	private $_container = null;
	private $application = null;
	private $custom_acl = null;
	private $security_checker = null;
	private $security_token = null;
	private $user = null;
	private $user_app_access = null;
	private $user_can_create = null;
	private $user_can_delete = null;
	
	/**
	 * @param Libraries $application
	 */
	public function __construct(Libraries $application, Docova $docova_obj = null) 
	{
		if (!empty($docova_obj)) {
			$this->_container = $docova_obj->getContainer();
		}
		else {
			global $docova;
			$this->_container = $docova->getContainer();
		}
		$this->application = $application;
		$this->security_checker = $this->_container->get('security.authorization_checker');
		$this->security_token = $this->_container->get('security.token_storage');
		$this->user = $this->security_token->getToken()->getUser();
		$this->custom_acl = new CustomACL($this->_container);
		$this->user_app_access = $this->getUserAccessLevel();
	}
	
	
	public function getUserAccessLevel()
	{	    
	    if(!is_null($this->user_app_access)){
	        return $this->user_app_access;
	    }
    
	    if ($this->security_checker->isGranted('ROLE_ADMIN')) {
	        $this->user_app_access = 7; //Super User Admin
	        return $this->user_app_access;
	    }

	    $result = 0; //No Access
	    $security_identity = $this->user;
	    $usermasks = $this->custom_acl->getUserMasks($this->application, $security_identity);	  
	    $defaultmasks = [];
	    $groupmasks = [];
	    $checkmasks = [];
	    
	    $acl_property = $this->getAclProperty();
	    if (!empty($acl_property))
	    {
	        if(is_array($acl_property)){
	            for($i=0; $i<count($acl_property); $i++){
	                if ($acl_property[$i]->getNoAccess()){
	                    $this->user_app_access = 0;
	                    return $this->user_app_access; //exit early since this user is marked as having no access in ACL
	                }
	            }
	        }else{
	            if ($acl_property->getNoAccess()){
	                $this->user_app_access = 0;
	                return $this->user_app_access; //exit early since this user is marked as having no access in ACL
	            }
	        }
	    }
	    
	    if(!empty($usermasks)){
	        $checkmasks = $usermasks;
	    }else{
	        $groups = $security_identity->getRoles();
	        if (!empty($groups)) {
	            foreach ($groups as $g) {
	                $tempmasks = $this->custom_acl->getGroupMasks($this->application, $g);
	                if(!empty($tempmasks)){
	                    //differentiate between role_user and other groups so that we can tell if this is a default level of access
	                    if ($g == "ROLE_USER" ){
	                        $defaultmasks =  $tempmasks;
	                    }else{
	                        $groupmasks =  array_merge($groupmasks, $tempmasks);
	                    }
	                }
	            }
	        }
	        if(!empty($groupmasks)){
	            $checkmasks = $groupmasks;
	        }elseif(!empty($defaultmasks)){
	            $checkmasks = $defaultmasks;
	        }
	    }
	    
	    if(!empty($checkmasks)){
	        if(in_array("owner", $checkmasks)){
	            $result = 6;  //Manager
	        }elseif(in_array("master", $checkmasks)){
	            $result = 5; //Designer
	        }elseif(in_array("operator", $checkmasks)){
	            $result = 4;  //Editor
	        }elseif(in_array("edit", $checkmasks)){
	            $result = 3; //Author
	        }elseif(in_array("view", $checkmasks)){
	            $result = 2;  //Reader
	        }
	  
	    }
	    
	    $this->user_app_access = $result;
	    return $this->user_app_access;
	}
	
	
	/**
	 * Check if current user has super admin access
	 * 
	 * @return boolean
	 */
	public function isSuperAdmin()
	{
		return ($this->user_app_access == 7);
	}
	
	/**
	 * Check if current user has manager access
	 * 
	 * @return boolean
	 */
	public function isManager()
	{
	    return ($this->user_app_access >= 6);
	}
	
	/**
	 * Check if current user has designer access
	 * 
	 * @return boolean
	 */
	public function isDesigner()
	{	
	    return ($this->user_app_access == 5);
	}
	
	/**
	 * Check if current user has editor access
	 * 
	 * @return boolean
	 */
	public function isEditor()
	{
	    return ($this->user_app_access == 4);		
	}
	
	/**
	 * Check if current user has author access
	 * 
	 * @return boolean
	 */
	public function isAuthor()
	{
	    return ($this->user_app_access == 3);	
	}
	
	/**
	 * Check if current user has reader access
	 * 
	 * @return boolean
	 */
	public function isReader()
	{ 
	    return ($this->user_app_access == 2);	
	}
	
	/**
	 * Check if current user has edit rights to document
	 * 
	 * @param \Docova\DocovaBundle\Entity\Documents|\Docova\DocovaBundle\ObjectModel\DocovaDocument $document
	 * @return boolean
	 */
	public function isDocAuthor($document)
	{
	    if(empty($document)){
	        return false;
	    }
	    
	    if ($this->isEditor() || $this->isDesigner() || $this->isManager()){
			return true;
	    }else if($this->isAuthor()){
	        $doctocheck = null;
	        if($document instanceof \Docova\DocovaBundle\Entity\Documents){
	            $doctocheck = $document;
	        }else if($document instanceof \Docova\DocovaBundle\ObjectModel\DocovaDocument){
	            $doctocheck = $document->getEntity();
	        }
	        
	        if (!empty($doctocheck))
	        {
	             $security_identity = $this->security_token->getToken()->getUser();
	             if ($this->custom_acl->isUserGranted($doctocheck, $security_identity, 'edit')){
    	             	return true;
	             }
	             
	             $groups = $security_identity->getRoles();
	             if (!empty($groups)) {
    	             foreach ($groups as $g) {
                         //exclude role_user since it is too generic for the author level users   	                 
    	                 if ($g !== "ROLE_USER" && $this->custom_acl->isRoleGranted($doctocheck, $g, 'edit')){
	                       return true;
	                     }
	                 }
	             }
	             
	             //if user belongs to workflow step assignee and editing document is permitted
	             if (true === $this->isPartOfWorkflowParticipants($document, true)) {
	             	return true;
	             }
	        }
	    }		

		return false;
	}
	
	/**
	 * Check if current user is in document readers field
	 * 
	 * @param \Docova\DocovaBundle\Entity\Documents|\Docova\DocovaBundle\ObjectModel\DocovaDocument $document
	 * @return boolean
	 */
	public function isDocReader($document)
	{
	    if(empty($document)){
	        return false;
	    }
	    if ($this->isSuperAdmin()){
	        return true;
	    }
		if (empty($this->user_app_access)) {
			return false;
		}
	    $doctocheck = null;
	    if($document instanceof \Docova\DocovaBundle\Entity\Documents){
	         $doctocheck = $document;
	    }else if($document instanceof \Docova\DocovaBundle\ObjectModel\DocovaDocument){
	         $doctocheck = $document->getEntity();
	    }
	    if (!empty($doctocheck)){
	        if ($this->security_checker->isGranted('VIEW', $doctocheck)){
	           return true;	                
	        }
		//if current user is part of current workflow step assignees, let it see the document
		elseif (true === $this->isPartOfWorkflowParticipants($document)) {
			return true;
		}
	    }
	    return false;
	}
	
	/**
	 * Check if current user can create document in the app
	 * 
	 * @return boolean
	 */
	public function canCreateDocument()
	{
	    if ($this->isSuperAdmin()){
	        $this->user_can_create = true;
	        return $this->user_can_create;
	    }
		
	    if ($this->isReader()){
	        $this->user_can_create = false;
	        return $this->user_can_create;
	    }
	   
	    if(!is_null($this->user_can_create)){
	       return $this->user_can_create;  //return cached value if available
	    }
	    
	    $acl_property = $this->getAclProperty();
	    if (!empty($acl_property))
	    {
	        if(is_array($acl_property)){
	            for($i=0; $i<count($acl_property); $i++){
	                if (!$acl_property[$i]->getNoAccess() && $acl_property[$i]->getCreateDocument()){
	                    $this->user_can_create = true;
	                    return $this->user_can_create;
	                }
	            }
	        }else{
	            if (!$acl_property->getNoAccess() && $acl_property->getCreateDocument()){
	                $this->user_can_create = true;
	                return $this->user_can_create;
	            }
	        }
	    }
		
	    $this->user_can_create = false;
	    return $this->user_can_create;
	}
	
	/**
	 * Check if current user can delete document in the app
	 * 
	 * @return boolean
	 */
	public function canDeleteDocument()
	{
	    if ($this->isSuperAdmin()){
	        $this->user_can_delete = true;
	        return $this->user_can_delete;
	    }
	    
	    if ($this->isReader()){
	        $this->user_can_delete = false;
	        return $this->user_can_delete;
	    }
	    
	    if(!is_null($this->user_can_delete)){
	        return $this->user_can_delete;  //return cached value if available
	    }
	    
	    $acl_property = $this->getAclProperty();
	    if (!empty($acl_property))
	    {
	        if(is_array($acl_property)){
	            for($i=0; $i<count($acl_property); $i++){
	                if (!$acl_property[$i]->getNoAccess() && $acl_property[$i]->getDeleteDocument()){
	                    $this->user_can_delete = true;
	                    return $this->user_can_delete;
	                }
	            }
	        }else{
	            if (!$acl_property->getNoAccess() && $acl_property->getDeleteDocument()){
	                $this->user_can_delete = true;
	                return $this->user_can_delete;
	            }
	        }
	    }
	    
	    $this->user_can_delete = false;
	    return $this->user_can_delete;
	}
	
	/**
	 * Given a name, finds its entry in an ACL.
	 *  
	 * @param string $entry
	 * @return NULL|DocovaAclEntry
	 */
	public function getEntry($entry)
	{
		if (empty($entry)) return null;
		$acl_property = new DocovaAclEntry($this, $entry);
		return $acl_property;
	}
	
	/**
	 * Creates an entry in the ACL with the name and level that you specify
	 * 
	 * @param string $name
	 * @param integer $level
	 * @return DocovaAclEntry
	 */
	public function createAclEntry($name, $level)
	{
		$acl_entry = new DocovaAclEntry($this, $name, $level);
		$acl_entry->new = true;
		return $acl_entry;
	}
	
	/**
	 * Removes an entry from the ACL.
	 * 
	 * @param string $name
	 */
	public function removeAclEntry($name)
	{
		$acl_entry = new DocovaAclEntry($this, $name);
		$acl_entry->remove();
	}
	
	public function save()
	{
		//@todo: if it's confirmed this function should be complete otherwise the createAclEntry should be removed, too.
	}
	
	/**
	 * Get application ID
	 * 
	 * @return string
	 */
	public function getAppId()
	{
		return $this->application->getId();
	}
	
	/**
	 * Add a user/role to document authors field
	 * 
	 * @param \Docova\DocovaBundle\Entity\Documents $document
	 * @param \Docova\DocovaBundle\Entity\UserAccounts|string $security_identity
	 * @param boolean $isRole
	 */
	public function addDocAuthor($document, $security_identity, $isRole = false)
	{
	    $this->custom_acl->insertObjectAce($document, $security_identity, 'edit', $isRole);
	}
	
	/**
	 * Add a user/role to document readers field
	 * 
	 * @param \Docova\DocovaBundle\Entity\Documents $document
	 * @param \Docova\DocovaBundle\Entity\UserAccounts|string $security_identity
	 * @param boolean $isRole
	 */
	public function addDocReader($document, $security_identity, $isRole = false)
	{
	    $this->custom_acl->insertObjectAce($document, $security_identity, 'view', $isRole);
	}
	
	/**
	 * Remove a user/role from document readers field
	 * 
	 * @param \Docova\DocovaBundle\Entity\Documents $document
	 * @param \Docova\DocovaBundle\Entity\UserAccounts|string $security_identity
	 * @param boolean $isRole
	 */
	public function removeDocReader($document, $security_identity, $isRole = false)
	{
	    $this->custom_acl->removeUserACE($document, $security_identity, 'view', $isRole);
	}
	
	/**
	 * Remove a user/role from document authors field
	 * 
	 * @param \Docova\DocovaBundle\Entity\Documents $document
	 * @param \Docova\DocovaBundle\Entity\UserAccounts|string $security_identity
	 * @param string $isRole
	 */
	public function removeDocAuthor($document, $security_identity, $isRole = false)
	{
	    $this->custom_acl->removeUserACE($document, $security_identity, 'edit', $isRole);
	}
	
	/**
	 * Remove all users/roles from document authors field
	 * 
	 * @param \Docova\DocovaBundle\Entity\Documents $document
	 */
	public function removeAllDocAuthors($document)
	{
	    $this->custom_acl->removeMaskACEs($document, 'edit');
	}
	
	/**
	 * Remove all users/roles from document readers field
	 * 
	 * @param \Docova\DocovaBundle\Entity\Documents $document
	 */
	public function removeAllDocReaders($document)
	{
	    $this->custom_acl->removeMaskACEs($document, 'view');
	}
	
	/**
	 * Find app ACL property record(s)
	 * 
	 * @param string $username
	 * @return NULL|\Docova\DocovaBundle\Entity\AppAcl
	 */
	private function getAclProperty($username = null)
	{
		$em = $this->_container->get('doctrine')->getManager();
		if (empty($username)){
			$user = $this->security_token->getToken()->getUser();
		}else {
			$user = $em->getRepository('DocovaBundle:UserAccounts')->findOneBy(array('username' => $username, 'Trash' => false));
			if (empty($user)){
				$user = $em->getRepository('DocovaBundle:UserAccounts')->findOneBy(array('userNameDnAbbreviated' => $username, 'Trash' => false));
			}
			if (empty($user)){
				return null;
			}
		}
		$acl_property = $em->getRepository('DocovaBundle:AppAcl')->findOneBy(array('application' => $this->application->getId(), 'userObject' => $user->getId()));
		if (empty($acl_property))
		{
			$groups = $user->getUserRoles();
			if (!empty($groups) && $groups->count() > 0)
			{
			    $acl_property_array = [];
			    $def_acl_property = null;
			    $temp_acl_property = null;
				foreach ($groups as $g)
				{				    
					$temp_acl_property = $em->getRepository('DocovaBundle:AppAcl')->findOneBy(array('application' => $this->application->getId(), 'groupObject' => $g->getId()));
					if (!empty($temp_acl_property)){
					    if($g->getRole() == "ROLE_USER"){
					        //-- default access so keep on hand in case nothing else comes up
					        $def_acl_property = $temp_acl_property;
					    }else{
				            $acl_property_array[] = $temp_acl_property;
				            $def_acl_property = null;
					    }
					}
				}
				if(empty($acl_property) && !empty($acl_property_array) && count($acl_property_array)>0){
				    $acl_property = (count($acl_property_array) == 1 ? $acl_property_array[0] : $acl_property_array);   
				}else if(empty($acl_property) && !empty($def_acl_property)){
				    //-- if no other access found other than default use default
				    $acl_property = $def_acl_property;
				}
			}
		}
		return $acl_property;
	}
	
	/**
	 * Check if current user is part of cusrrent workflow step participant(s) and/or has edit access on the document
	 * 
	 * @param \Docova\DocovaBundle\Entity\Documents $document
	 * @param boolean $check_edit_access
	 * @return boolean
	 */
	private function isPartOfWorkflowParticipants($document, $check_edit_access = false)
	{
		$em = $this->_container->get('doctrine')->getManager();
		$pending_step = $em->getRepository('DocovaBundle:DocumentWorkflowSteps')->getFirstPendingStep($document->getId());
		if (!empty($pending_step) && !empty($pending_step[0]))
		{
			$pending_step = $pending_step[0];
			$assignees = $pending_step->getAssignee();
			if (!empty($assignees) && $assignees->count())
			{
				foreach ($assignees as $rec) {
					if ($rec->getAssignee()->getId() === $this->user->getId()) {
						if ($check_edit_access === false) {
							return true;
						}
						elseif ($pending_step->getStepType() == 2 || $pending_step->getStepType() == 4 || $pending_step->getApproverEdit()) {
							return true;
						}
					}
				}
			}
		}
		return false;
	}
}