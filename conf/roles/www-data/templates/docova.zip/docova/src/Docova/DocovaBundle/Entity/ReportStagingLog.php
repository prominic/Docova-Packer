<?php

namespace Docova\DocovaBundle\Entity;

use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Doctrine\ORM\EntityManager;

/**
 * ReportStagingLog
 *
 * @ORM\Table(name="tb_report_staging_log")
 * @ORM\Entity(repositoryClass="Docova\DocovaBundle\Entity\ReportStagingLogRepository")
 */
class ReportStagingLog {
/**
 * @ORM\Column(name="id", type="guid")
 * @ORM\Id
 * @ORM\GeneratedValue(strategy="UUID")
 */
protected $id;


/**
 * @ORM\Column(name="ProfileId", type="guid") 
 */
protected $ProfileId;

/**
 * @var \DateTime
 *
 * @ORM\Column(name="RunDate", type="datetime", nullable=true)
 */
protected $RunDate;

/**
 * @var \DateTime
 *
 * @ORM\Column(name="RunCompletedDate", type="datetime", nullable=true)
 */
protected $RunCompletedDate;


/**
 * @var integer
 *
 * @ORM\Column(name="NewDocuments", type="integer", nullable=true)
 */
protected $NewDocuments;

/**
 * @var integer
 *
 * @ORM\Column(name="ModifiedDocuments", type="integer", nullable=true)
 */
protected $ModifiedDocuments;

/**
 * @var integer
 *
 * @ORM\Column(name="DeletedDocuments", type="integer", nullable=true)
 */
protected $DeletedDocuments;
/**
 * @var integer
 *
 * @ORM\Column(name="Inserts", type="integer", nullable=true)
 */
protected $Inserts;

/**
 * @var integer
 *
 * @ORM\Column(name="Updates", type="integer", nullable=true)
 */
protected $Updates;

/**
 * @var integer
 *
 * @ORM\Column(name="Deletions", type="integer", nullable=true)
 */
protected $Deletions;


/**
 * @var string
 *
 * @ORM\Column(name="LogFile",type="text", length=255, nullable=true)
 */
protected $LogFile;

/**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

/**
     * @return mixed
     */
    public function getProfileId()
    {
        return $this->ProfileId;
    }

/**
     * @return DateTime
     */
    public function getRunDate()
    {
        return $this->RunDate;
    }

/**
     * @return DateTime
     */
    public function getRunCompletedDate()
    {
        return $this->RunCompletedDate;
    }

/**
     * @return number
     */
    public function getInserts()
    {
        return $this->Inserts;
    }

/**
     * @return number
     */
    public function getUpdates()
    {
        return $this->Updates;
    }

/**
     * @return number
     */
    public function getDeletions()
    {
        return $this->Deletions;
    }

/**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

/**
     * @param mixed $ProfileId
     */
    public function setProfileId($ProfileId)
    {
        $this->ProfileId = $ProfileId;
    }

/**
     * @param DateTime $RunDate
     */
    public function setRunDate($RunDate)
    {
        $this->RunDate = $RunDate;
    }

/**
     * @param DateTime $RunCompletedDate
     */
    public function setRunCompletedDate($RunCompletedDate)
    {
        $this->RunCompletedDate = $RunCompletedDate;
    }



/**
     * @param number $Inserts
     */
    public function setInserts($Inserts)
    {
        $this->Inserts = $Inserts;
    }

/**
     * @param number $Updates
     */
    public function setUpdates($Updates)
    {
        $this->Updates = $Updates;
    }

/**
     * @param number $Deletions
     */
    public function setDeletions($Deletions)
    {
        $this->Deletions = $Deletions;
    }
    /**
     * @return number
     */
    public function getNewDocuments()
    {
        return $this->NewDocuments;
    }

    /**
     * @return number
     */
    public function getModifiedDocuments()
    {
        return $this->ModifiedDocuments;
    }

    /**
     * @return number
     */
    public function getDeletedDocuments()
    {
        return $this->DeletedDocuments;
    }

    /**
     * @param number $NewDocuments
     */
    public function setNewDocuments($NewDocuments)
    {
        $this->NewDocuments = $NewDocuments;
    }

    /**
     * @param number $ModifiedDocuments
     */
    public function setModifiedDocuments($ModifiedDocuments)
    {
        $this->ModifiedDocuments = $ModifiedDocuments;
    }

    /**
     * @param number $DeletedDocuments
     */
    public function setDeletedDocuments($DeletedDocuments)
    {
        $this->DeletedDocuments = $DeletedDocuments;
    }
    /**
     * @return string
     */
    public function getLogFile()
    {
        return $this->LogFile;
    }

    /**
     * @param string $LogFile
     */
    public function setLogFile($LogFile)
    {
        $this->LogFile = $LogFile;
    }

    

}