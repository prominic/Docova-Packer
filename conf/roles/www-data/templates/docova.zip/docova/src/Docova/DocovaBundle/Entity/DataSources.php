<?php

namespace Docova\DocovaBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use PDO;
use Docova\DocovaBundle\Extensions\ExternalConnections;
use Symfony\Component\BrowserKit\Response;

/**
 * DataSources
 *
 * @ORM\Table(name="tb_data_sources")
 * @ORM\Entity(repositoryClass="Docova\DocovaBundle\Entity\DataSourcesRepository")
 */
class DataSources
{
    /**
     * @ORM\Column(name="id", type="guid")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     */
    protected $id;

    /**
     * @var string
     *
     * @ORM\Column(name="Name", type="string", length=100)
     */
    protected $Name;

    /**
     * @var string
     *
     * @ORM\Column(name="Columns", type="string", nullable=true)
     */
    protected $Columns;
    
    /**
     * @var string
     *
     * @ORM\Column(name="Connection_Name", type="string", length=100, nullable=true)
     */
    protected $Connection_Name;
       
    
    /**
     * @var string
     *
     * @ORM\Column(name="Type", type="string", length=20)
     */
    protected $Type;
    
    /**
     * @var string
     *
     * @ORM\Column(name="File_Resource_Name", type="string", length=100, nullable=true)
     */
    protected $File_Resource_Name;
    
    /**
     * @var string
     *
     * @ORM\Column(name="Subject_Column", type="string", length=1)
     */
    protected $Subject_Column;
    
    
    
    /**
     * @var \DateTime
     *
     * @ORM\Column(name="Date_Created", type="datetime")
     */
    protected $Date_Created;
    
    
    //Define CSV Fields
    /**
     * @var string
     *
     * @ORM\Column(name="CSV_Delimiter", type="string", length=1, nullable=true)
     */
    protected $CSV_Delimiter;
    
    /**
     * @var string
     *
     * @ORM\Column(name="CSV_Offset_Lines", type="string", length=1, nullable=true)
     */
    protected $CSV_Offset_Lines;
    
    /**
     * @var string
     *
     * @ORM\Column(name="CSV_Offset_Chars", type="string", length=2, nullable=true)
     */
    protected $CSV_Offset_Chars;
        
    //Define SQL Fields
    /**
     * @var string
     *
     * @ORM\Column(name="SQL_Type", type="string", length=100, nullable=true)
     */
    protected $SQL_Type;
    
    /**
     * @var string
     *
     * @ORM\Column(name="SQL_String", type="string", nullable=true)
     */
    protected $SQL;
    
    /**
     * @var boolean
     *
     * @ORM\Column(name="Docova_Documents_Only", type="boolean", nullable=true)
     */
    protected $Docova_Documents_Only;
    
    /**
     * @var string
     *
     * @ORM\Column(name="SQL_Table_Name", type="string", length=100, nullable=true)
     */
    protected $SQL_Table_Name;

    /**
     * @var string
     *
     * @ORM\Column(name="SQL_Order_By", type="string", length=100, nullable=true)
     */
    protected $SQL_Order_By;
    
    
    /**
     * @var string
     *
     * @ORM\Column(name="SQL_Key_Name", type="string", length=100, nullable=true)
     */
    protected $SQL_Key_Name;
    
    /**
     * @var string
     *
     * @ORM\Column(name="SQL_Key_Gen_Type", type="string", length=100, nullable=true)
     */
    protected $SQL_Key_Gen_Type;
    /**
     * Get id
     *
     * @return string 
     */
    public function getId()
    {
        return $this->id;
    }

    
     /**
     * Get Date_Created
     *
     * @return \DateTime 
     */
    public function getDateCreated()
    {
        return $this->Date_Created;
    }
    /**
     * Set Date_Created
     *
     * @param \DateTime $dateCreated
     * @return FileResources
     */
    public function setDateCreated($dateCreated)
    {
    	$this->Date_Created = $dateCreated;
    
    	return $this;
    }
	public function getName() {
		return $this->Name;
	}
	public function setName($Name) {
		$this->Name = $Name;
		return $this;
	}
	public function getConnectionName() {
		return $this->Connection_Name;
	}
	public function setConnectionName($Connection) {
		$this->Connection_Name = $Connection;
		return $this;
	}
	public function getType() {
		return $this->Type;
	}
	public function setType($Type) {
		$this->Type = $Type;
		return $this;
	}
	public function getFileResourceName() {
		return $this->File_Resource_Name;
	}
	public function setFileResourceName($Name) {
		$this->File_Resource_Name = $Name;
		return $this;
	}
	public function getSubjectColumn() {
		return $this->Subject_Column;
	}
	public function setSubjectColumn($Column) {
		$this->Subject_Column = $Column;
		return $this;
	}
	public function getCSVDelimiter() {
		return $this->CSV_Delimiter;
	}
	public function setCSVDelimiter($delim) {
		$this->CSV_Delimiter = $delim;
		return $this;
	}
	public function getCSVOffsetLines() {
		return $this->CSV_Offset_Lines;
		
	}
	public function setCSVOffsetLines($offset) {
		$this->CSV_Offset_Lines = $offset;
		return $this;
	}
	public function getCSVOffsetChars() {
		return $this->CSV_Offset_Chars;
	
	}
	public function setCSVOffsetChars($offset) {
		$this->CSV_Offset_Chars = $offset;
		return $this;
	}
	public function getSQLTableName() {
		return $this->SQL_Table_Name;
	}
	public function setSQLTableName($tableName) {
		$this->SQL_Table_Name = $tableName;
		return $this;
	}
	public function getSQLType() {
		return $this->SQL_Type;
	}
	public function setSQLType($type) {
		$this->SQL_Type = $type;
		return $this;
	}
	public function getSQL() {
		return $this->SQL;
	}
	public function setSQL($sql) {
		$this->SQL = $sql;
		return $this;
	}
	public function getColumns() {
		return $this->Columns;
	}
	public function setColumns($columns) {
		$this->Columns = $columns;
		return $this;
	}
	public function getSQLOrderBy() {
		return $this->SQL_Order_By;
	}
	public function setSQLOrderBy($orderBy) {
		$this->SQL_Order_By = $orderBy;
		return $this;
	}
	public function getSQLKeyName() {
		return $this->SQL_Key_Name;
	}
	public function setSQLKeyName($keyName) {
		$this->SQL_Key_Name = $keyName;
		return $this;
	}
	public function getFileResource($em)
	{
		return $em->getRepository("DocovaBundle:FileResources")->getFileResource($this->getFileResourceName());
	}
	public function getFileResourcePath($em,$root)
	{
		return $em->getRepository("DocovaBundle:FileResources")->getFileResourcePath($root,$this->getFileResourceName());
	}
	public function getFileResourceContent($em,$root)
	{
		return $em->getRepository("DocovaBundle:FileResources")->getFileResourceContent($root,$this->getFileResourceName());
	}
	public function getDocovaDocumentsOnly() {
		return $this->Docova_Documents_Only;
	}
	public function setDocovaDocumentsOnly($Docova_Documents_Only) {
		$this->Docova_Documents_Only = $Docova_Documents_Only;
		return $this;
	}
    /**
     * @return string
     */
    public function getSQLKeyGenType()
    {
        return $this->SQL_Key_Gen_Type;
    }

    /**
     * @param string $SQL_Key_Gen_Type
     */
    public function setSQLKeyGenType($SQL_Key_Gen_Type)
    {
        $this->SQL_Key_Gen_Type = $SQL_Key_Gen_Type;
    }
    public static function buildHTMLTable($array,$columns,$linkBase,$id="tblData",$enabledField=null,$hiddenFields=array()){
        $MAX_CELL_WIDTH=125;
        if (empty($array)){
            return "<span>No data found!</span>";
        }
        
        $TABLE_PROP = ' border="0" cellspacing="0" cellpadding="2"';
        $CELL_STYLE = ' background-color:white;padding:2px;border-collapse: collapse; border: 1px solid #dfdfdf;font-size:9pt;';
        
        
        // start table
        $html = PHP_EOL.'<div style="height:100%;overflow:auto;font-family:Arial;"><table id="'.$id.'"'.$TABLE_PROP.'>'.PHP_EOL;
        
        
        // process header rows
        $html .= '<thead class="ui-widget-header headercell">';
        
        if (!empty($array[0]) && is_array($array[0]) ) {
            if ($columns==null){
                //no column names specified, return all values in the default order
                foreach($array[0] as $key=>$value){
                    if (is_numeric($key)){
                        continue;
                    }
                    $html .= '<th class="ui-widget-header headercell" style="font-size:9pt;">' . htmlspecialchars($key).'</th>'.PHP_EOL;
                }
            }
            else{
                //columns names have been provided, create in the order provided
                foreach($columns as $column){
                    //check to see if this column name exists in the data
                    $hasColumn=false;
                    foreach($array[0] as $key=>$value){
                        if ($key==$column){
                            $hasColumn=true;
                            break;
                        }
                    }
                    if ($hasColumn && !in_array($column,$hiddenFields) ) {
                        $html .= '<th class="ui-widget-header headercell" style="font-size:9pt;">' . htmlspecialchars($key).'</th>'.PHP_EOL;
                    }
                }
            }
        }
        $html .= '</thead>';
        
        
        // process data rows
        $html .= '<tbody class="ui-widget-content">';
        
        foreach( $array as $key=>$row){
            if (empty($row)){
                continue;
            }
            $html .= '<tr>'.PHP_EOL;
            $columnPosition = 0;
            if ($columns==null){
                //columns not specified, return all columns available
                foreach($row as $name=>$value){
                    $columnPosition++;
                    if (is_numeric($name)){
                        continue;
                    }
                    if (is_object($value)){
                        $html .= '<td class="datacell" style="'.$CELL_STYLE.'">' . 'object'. '</td>'.PHP_EOL;
                    }
                    else{
                        $html .= '<td class="datacell" style="'.$CELL_STYLE.'">';
                        
                        
                        if (strlen($value)>$MAX_CELL_WIDTH){
                            $value = substr($value,0,$MAX_CELL_WIDTH);
                            if ($name=="Folder" || $name=="Source File Name"){
                                $html .= '<a href="">'.htmlspecialchars($value."...") .'</a>'. '</td>'.PHP_EOL;
                            }
                            else{
                                $html .= htmlspecialchars($value."...") . '</td>'.PHP_EOL;
                            }
                        }
                        else{
                            if ($name=="Folder" || $name=="Source File Name"){
                                $html .= '<a href="">'.htmlspecialchars($value) .'</a>'.'&nbsp;</td>'.PHP_EOL;
                            }
                            else{
                                $html .= htmlspecialchars($value) . '&nbsp;</td>'.PHP_EOL;
                            }
                            
                        }
                    }
                }
            }
            else{
                //columns names have been provided, create in the order provided
                $columnsProcessed=0;
                
                $enabledValue=false;
                if ($enabledField!=null && in_array($enabledField,$columns) ) {
                    $enabledValue = $row[$enabledField];
                }
                
                foreach($columns as $column){
                    
                    //check to see if this column name exists in the data
                    $hasColumn=false;
                    
                    foreach($row as $key=>$value){
                        if ($key==$column){
                            $hasColumn=true;
                            break;
                        }
                    }
                    
                    
                    if ($hasColumn ) {
                        if (is_object($value)){
                            $html .= '<td class="datacell" style="'.$CELL_STYLE.'">' . 'object'. '</td>'.PHP_EOL;
                        }
                        else{
                            $cellValue =  htmlspecialchars($value);
                            //the first column is the links column, when an id is available
                            if ($columns[0]==$column){  //&& !empty($row['id'])
                                
                                $icon="";
                                
                                if ($enabledField!=null){
                                    //insert the status icon
                                    if ($enabledValue){
                                        $icon = '<img src="../../../bundles/docova/images/vwicn082.gif">&nbsp;&nbsp;';
                                    }
                                    else{
                                        $icon = '<img src="../../../bundles/docova/images/vwicn081.gif">&nbsp;&nbsp;';
                                    }
                                    
                                }
                                
                                $cellValue = $icon.'<a class="rowLink" style="color:navy;" href="'.(!empty($linkBase) ? $linkBase : '').$row['id'].'">'.$cellValue."</a>";
                                $html .= '<td class="linkcell" style="'.$CELL_STYLE.'">'. $cellValue . '</td>'.PHP_EOL;
                            }
                            else{
                                if (!in_array($column,$hiddenFields) ) {
                                    if (strlen($cellValue)>$MAX_CELL_WIDTH){
                                        $html .= '<td class="datacell" style="'.$CELL_STYLE.'">'.  htmlspecialchars(substr($cellValue,0,$MAX_CELL_WIDTH)."...") . '</td>'.PHP_EOL;
                                    }
                                    else{
                                        $html .= '<td class="datacell" style="'.$CELL_STYLE.'">'. $cellValue . '</td>'.PHP_EOL;
                                    }
                                }
                            }
                            
                            
                        }
                        
                        $columnsProcessed++;
                    }
                }
            }
            
            
            $html .= '</tr>'.PHP_EOL;
        }
        $html .= '</tbody>';
        
        // finish table and return it
        $html .= '</table></div>'.PHP_EOL;
        return "<html>".$html."</html>";
    }
    public function testQuery(){
        $conn = ExternalConnections::getConnection($this->getConnectionName());  
        $driverName = $conn->getAttribute(\PDO::ATTR_DRIVER_NAME);
        if ($driverName=="sqlsrv" || $driverName=="pdo_sqlsrv"){
            $queryOptions=" OFFSET 0 ROWS FETCH NEXT 500 ROWS ONLY";
        }
        else{
            $queryOptions=" LIMIT 500 OFFSET 0";
        }
        if (!empty($this->getSQLOrderBy())){
            $orderBy = " ORDER BY ".$this->getSQLOrderBy();
        }
        else{
            $orderBy = "";
        }
        $q = $conn->query( $this->getSQL().$orderBy.$queryOptions );
        if ($q===false){
            return "<pre>Error running query: ".json_encode($conn->errorInfo(),JSON_PRETTY_PRINT)."</pre>";
        }
        else{
            $results = $q->fetchAll();
            return $this->buildHtmlTable($results,null,'');
        }
        
        
    }
}
