<?php
namespace Docova\DocovaBundle\Extensions;

//use Docova\DocovaBundle\Extensions\CSVDataSource;
//use Docova\DocovaBundle\Extensions\ExternalConnections;
//use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Docova\DocovaBundle\Entity\DataViews;
use Docova\DocovaBundle\Entity\AppForms;
use Symfony\Component\HttpFoundation\Request;
use DateTime;
use Docova\DocovaBundle\Entity\UserAccounts;
use Doctrine\ORM\EntityManager;
//use Docova\DocovaBundle\Logging\FileLogger;
//use Docova\DocovaBundle\Controller\Miscellaneous;

class ExternalViews {
	public static function getDataView($controller,$dataViewId){
		$em = ExternalViews::getEntityManager($controller);
		$dataView = $em->getRepository("DocovaBundle:DataViews")->find($dataViewId);
		return $dataView;		
	}
	public static function getDataSource($controller,$dataViewId){		
		$dataView = ExternalViews::getDataView($controller,$dataViewId);
		$dataSource = !empty($dataView) ? $dataView->getDataSource(ExternalViews::getEntityManager($controller)) : null;
		return $dataSource;
	}
	public static function readDocument($controller, $rootPath, $doc_id, $folder_id, $dataView, $dataSource,$columns=null,$docovaDoc=null,$docovaFields=null){
		//Do not process DOCOVA documents
		if (!empty($dataSource)){
			$docovaDocumentsOnly = $dataSource->getDocovaDocumentsOnly();
			if (!empty($docovaDocumentsOnly) && $docovaDocumentsOnly){
				return null;
			}
		}
		$documentFieldValues = array();
		$documentAttachments = "";
		if ($docovaDoc!=null){
		    
		    if (!empty($docovaDoc)){		        
		        $form = ExternalViews::getApplicationForm($controller->getEntityManager(), $dataView->getAppId(), $dataView->getFormName());
		        
		        $documentFieldValues = ExternalViews::getSpecifiedDocumentFieldValues($controller->getEntityManager(), $dataView->getAppId(), $form, array($doc_id => $docovaDoc), $docovaFields);
		        
		        if ( !empty($documentFieldValues) && array_key_exists($docovaDoc->getId(),$documentFieldValues)){
		            $documentFieldValues = $documentFieldValues[$docovaDoc->getId()];
		        }
		        else{
		            $documentFieldValues = array();
		        }

		       
		        //join each of the fields values into a single string
		        $collapsedDocumentFieldValues = array();
		        foreach($documentFieldValues as $name => $documentFieldValue){		       
		            if (is_array($documentFieldValue)){
		                $collapsedDocumentFieldValues[$name]=implode(',',$documentFieldValue);
		            }
		            else{
		                $collapsedDocumentFieldValues[$name]=$documentFieldValue;
		            }
		        }
		        $documentFieldValues = $collapsedDocumentFieldValues;
		        
		        $attachments = $docovaDoc->getAttachments();
		        if (!empty($attachments)){
		            foreach($attachments as $attachment){
		                if ($documentAttachments!=""){
		                    $documentAttachments.=";";
		                }
		                $documentAttachments.=$attachment->getFileName();
		            }
		        }
		        $documentFieldValues['attachment_names']=$documentAttachments;
		    }
		}
		$documentData = ExternalViews::getFirstDocument(ExternalViews::getDocumentData($controller, $rootPath, $doc_id, $dataView, $dataSource));
		$documentData = array_merge($documentFieldValues,$documentData);
		
		if ($docovaDoc!=null){
		    $documentData['docovaunid']=$docovaDoc->getId();
		}
	
		if (!empty($columns)){
		    $arrColumns = explode(',',$columns);
    		foreach($documentData as $name => $value){
    		    if (!in_array($name,$arrColumns)) {
    		        unset($documentData[$name]);
    		    }
    		}
       	}
       	if (!empty($docovaFields)){
       	    if (!is_array($docovaFields)){
       	        $docovaFields=explode(',',$docovaFields);
       	    }
       	    //find any field values not yet populated
       	    //if the field is a document property field then set its value
       	    foreach($docovaFields as $docovaField){       	        
       	        if (!array_key_exists($docovaField,$documentData) ){       	            
       	            if (ExternalViews::isDocumentField($docovaDoc,$docovaField)){
       	                //the field specified is a document property, set the value
       	                $documentData[$docovaField]=ExternalViews::getDocumentField($docovaDoc,$docovaField);
       	            }
       	           
       	        }       	        
       	    }
       	    
       	}
		/*
		$securityContext = $controller->getSecurityContext();
		$user = $securityContext->getToken()->getUser();
		$global_settings = $controller->getEntityManager()->getRepository('DocovaBundle:GlobalSettings')->findAll();
		$global_settings = $global_settings[0];
		
		$documentData['getId']=$doc_id;
		$documentData['getDocStatus']='External';
		$documentData['getStatusNo']='0';
		$documentData['getDocTitle']=$doc_id;
		$documentData['getCreator']=$user;
		$documentData['getDateCreated']=new \DateTime();
		$documentData['getModifier']=$user;
		$documentData['getDateModified']=new \DateTime();
		$documentData['getLockEditor']=$user;
		$documentData['getLocked']=0;
		$documentData['getAttachments']=array("count" => 0);
*/
		return $documentData;
	}
	public static function readDocumentAndRender($controller, $rootPath, $doc_id, $folder_id, $dataView, $dataSource ){
	    //Do not process DOCOVA documents
	    if (!empty($dataSource)){
	        $docovaDocumentsOnly = $dataSource->getDocovaDocumentsOnly();
	        if (!empty($docovaDocumentsOnly) && $docovaDocumentsOnly){
	            return null;
	        }
	    }
	    
	    $documentData = ExternalViews::getFirstDocument(ExternalViews::getDocumentData($controller, $rootPath, $doc_id, $dataView, $dataSource));
	    $securityContext = $controller->getSecurityContext();
	    $user = $securityContext->getToken()->getUser();
	    $global_settings = $controller->getEntityManager()->getRepository('DocovaBundle:GlobalSettings')->findAll();
	    $global_settings = $global_settings[0];
	    
	    $documentData['getId']=$doc_id;
	    $documentData['getDocStatus']='External';
	    $documentData['getStatusNo']='0';
	    $documentData['getDocTitle']=$doc_id;
	    $documentData['getCreator']=$user;
	    $documentData['getDateCreated']=new \DateTime();
	    $documentData['getModifier']=$user;
	    $documentData['getDateModified']=new \DateTime();
	    $documentData['getLockEditor']=$user;
	    $documentData['getLocked']=0;
	    $documentData['getAttachments']=array("count" => 0);
	    //Look for a custom form
	    /*
	     if (\file_exists(\realpath(__DIR__.'/../Resources/views/DesignElements/A094EE8F-F4AB-41F0-BCC2-5BC004EEBF42')."/".$dataView->getName().'_read.html.twig')){
	     $form = $controller->getEntityManager()->getRepository('DocovaBundle:AppForms')->findOneBy(array('formName' => $dataView->getName(), 'application' => 'A094EE8F-F4AB-41F0-BCC2-5BC004EEBF42', 'trash' => false));
	     
	     return $controller->renderForm('DocovaBundle:DesignElements:A094EE8F-F4AB-41F0-BCC2-5BC004EEBF42/'.$dataView->getName().'_read.html.twig', array(
	     'viewTitle' => $dataView->getName(),
	     'dataViewId' => $dataView->getId(),
	     'doc_id' => $doc_id,
	     'user' => $user,
	     'form' => $form,
	     'settings' => $global_settings,
	     'object' => $documentData,
	     'applicationname' => $form->getApplication()->getLibraryTitle(),
	     'useraccess' => 6,
	     'workflow_options' => null,
	     'available_versions' => null
	     ));
	     }
	     else{
	     echo "No such file ".\realpath(__DIR__.'/../Resources/views/DesignElements/A094EE8F-F4AB-41F0-BCC2-5BC004EEBF42')."/".$dataView->getName().'_read.html.twig';
	     }
	     */
	    $customFormPath = \realpath(__DIR__.'/../Resources/views/Form').DIRECTORY_SEPARATOR.$dataView->getName().'_read.html.twig';
	    if (\file_exists($customFormPath)){
	        //render using custom form
	        
	        return $controller->renderForm('DocovaBundle:Form:'.$dataView->getName().'_read.html.twig', array(
	            'dataSource' => $dataSource,
	            'dataView' => $dataView,
	            'viewName' => $dataView->getName(),
	            'viewTitle' => (empty($dataView->getFormLabel()) ? $dataView->getName(): $dataView->getFormLabel()),
	            'dataViewId' => $dataView->getId(),
	            'data' => $documentData,
	            'doc_id' => $doc_id,
	            'user' => $securityContext->getToken()->getUser(),
	            'canEdit' => $dataView->canUpdate()
	        ));
	    }
	    else {
	        //no custom twig found, render using the default twig
	        //$extView = new ExternalView($controller,$rootPath,$dataView);
	        return $controller->renderForm('DocovaBundle:Form:Default-External_read.html.twig', array(
	            'dataSource' => $dataSource,
	            'dataView' => $dataView,
	            'viewName' => $dataView->getName(),
	            'viewTitle' => (empty($dataView->getFormLabel()) ? $dataView->getName(): $dataView->getFormLabel()),
	            'dataViewId' => $dataView->getId(),
	            'data' => $documentData,
	            'doc_id' => $doc_id,
	            'user' => $securityContext->getToken()->getUser(),
	            'canEdit' => $dataView->canUpdate()
	            //  ,
	            //    'lookup' => $extView->dbColumn(array("Name","Code"))
	        ));
	    }
	    
	}
	public static function getRowData($fields,$request){
		$row=array();
		foreach($fields as $field){
			$field_value = $request->get($field);
			if (!empty($field_value) || $field_value=="0"){
				$row[$field]=$field_value;
			}
			
		}
		return $row;
	}
	public static function saveDocument($controller, $rootPath, $request, $doc_id, $folder_id, $dataViewId, &$saveDocovaDocument /*out*/ ){
		$logPath = $rootPath ? $rootPath.DIRECTORY_SEPARATOR.'Docova'.DIRECTORY_SEPARATOR.'logs'.DIRECTORY_SEPARATOR : $_SERVER['DOCUMENT_ROOT'].DIRECTORY_SEPARATOR.'Docova'.DIRECTORY_SEPARATOR.'logs'.DIRECTORY_SEPARATOR;
		//$log = new FileLogger($logPath."documentLog.log");
		//if (!empty($log)) $log->log("SaveDocument for Document ID: ".$doc_id. " in view ".$dataViewId,FileLogger::NOTICE); 
		
		$em = self::getEntityManager($controller);
		$dataView = $em->getRepository("DocovaBundle:DataViews")->find($dataViewId);
		$dataSource = !empty($dataView) ? $dataView->getDataSource($em) : null;
	
		if (empty($dataView->getDOCOVAIntegrated()) || $dataView->getDOCOVAIntegrated()=="Yes"){
		    $saveDocovaDocument=true;
		}
		else{
		    $saveDocovaDocument=false;
		}
				
		//Do not process DOCOVA documents
		if (!empty($dataSource)){
			$docovaDocumentsOnly = $dataSource->getDocovaDocumentsOnly();
			if (!empty($docovaDocumentsOnly) && $docovaDocumentsOnly){
				return null;
			}
		}
		
		if (!empty($log)) $log->log("Data Source: ".\json_encode($dataSource),$log::NOTICE);
		
		
		if ($dataSource->getType()=="CSV"){
			$source = self::getCSVSource($controller, $rootPath, $folder_id, 0, 1000000, null, $dataSource, $dataView);
				
			if (!empty($log)) $log->log("CSV Source: ".\json_encode($source),$log::NOTICE);			
			$source->updateCSVLine($doc_id, self::getRowData($source->fields,$request));					
			if (!empty($log)) $log->log("CSV Source Updated: ".\json_encode($source),$log::NOTICE);
						
			$source->saveCSVFile();
		}
		else if ($dataSource->getType()=="SQL"){
		    if (is_numeric($doc_id)){
			   $source = self::getSQLSource($controller, $rootPath, $folder_id, $doc_id, 1, null, $dataSource, $dataView);
		    }
		    else{
		        $source = self::getSQLSource($controller, $rootPath, $folder_id, 0, 1, null, $dataSource, $dataView);
		    }
			
			if (!empty($log)) $log->log("SQL Source: ".\json_encode($source),$log::NOTICE);
			
			$rowData = self::getRowData($source->fields,$request);
			$keyColumn = $dataSource->getSQLKeyName();
			//echo "<br/>Source Fields: ".json_encode($source->fields);
			//echo "<br/>Row Data: ".json_encode($rowData);
			//echo "<br/>Key Column: ".json_encode($keyColumn);
			if (empty($doc_id) || $doc_id=="null" ){
			    if ($dataView->canCreate()==false){
			        throw new \Exception("This data view does not permit creating new records!");
			    }
			    //echo "<br/>New Document: true";
			    //new document
			    if ($dataSource->getSQLKeyGenType()=="DOCOVA Generated GUID"){
			        $generatedKey = $rowData[$keyColumn]=self::getGUID();
			        $source->insertRow($dataSource->getSQLTableName(), $dataSource->getSQLKeyName(),null,$rowData,true);
			    }
			    else{
			        $generatedKey = $source->insertRow($dataSource->getSQLTableName(), $dataSource->getSQLKeyName(),null,$rowData);
			    }
			    
			    //ensure that only the necessary fields remain in the request for DOCOVA to process
			    ExternalViews::removeExternalDataFromRequest($request,$dataView,$keyColumn,$source->getFields());
			    
			    if (!empty($generatedKey)){
			        $generatedKey = str_replace('{','',$generatedKey);
			        $generatedKey = str_replace('}','',$generatedKey);
			    }
			    return $generatedKey;
			}
			else{
			    //existing document
			    //echo "<br/>New Document: false";
			    if ($dataView->canUpdate()==false){
			        throw new \Exception("This data view does not permit updating!");
			    }
			    $source->updateRow($dataSource->getSQLTableName(),$keyColumn,$doc_id, $rowData);
			    
			    //ensure that only the necessary fields remain in the request for DOCOVA to process
			    ExternalViews::removeExternalDataFromRequest($request,$dataView,$keyColumn,$source->getFields());
			}
			
			//$source->updateSQLRow($doc_id, $rowData);
			if (!empty($log)) $log->log("SQL Source Updated: ".\json_encode($source),$log::NOTICE);
		}
		$source=null;
	}
	private static function removeExternalDataFromRequest(Request $request,$dataView,$keyColumn,$fields){
	    //1.  L (Local) - Do not remove any fields
	    //2.  O (Other) - Remove all but the specified fields
	    //3.  E (External) - Remove all external fields, except the key column (Default)

	    $storageOption = $dataView->getStorage();
	    if ($storageOption=="L"){
	        //1.  L - Do not remove any fields
	        return;
	    }
	    else if ($storageOption=="O") {
	        //2.  O - Remove all but the specified fields
	        $storageFields = explode(',',$dataView->getStorageFields());
	        foreach($fields as $field){
	            //even if not specified, do not remove the key column
	            if ($field!=$keyColumn){
    	            if ( ! in_array($field,$storageFields) ){
    	                $request->request->remove($field);
    	            }
	            }
	        }
	    }
	    else{	       
	         //3.  E - Remove all external fields, except the key column
	        foreach($fields as $field){
	            if ($field!=$keyColumn){
	                $request->request->remove($field);
	            }
	        }
	    }
	}
	public static function deleteDocument($controller, $rootPath, $doc_id, $folder_id, $dataView, $dataSource ){
	    if ($dataView->canDelete()==false){
	        throw new \Exception("This data view does not permit deletions!");
	    }
	    $em = self::getEntityManager($controller);
	    	    
	    //Do not process DOCOVA documents
	    if (!empty($dataSource)){
	        $docovaDocumentsOnly = $dataSource->getDocovaDocumentsOnly();
	        if (!empty($docovaDocumentsOnly) && $docovaDocumentsOnly){
	            return null;
	        }
	    }
	    
	  
	    
	    if ($dataSource->getType()=="CSV"){
	        //TBD
	        /*
	        $source = self::getCSVSource($controller, $rootPath, $folder_id, 0, 1000000, null, $dataSource, $dataView);
	        
	        */
	    }
	    else if ($dataSource->getType()=="SQL"){
	        $source = self::getSQLSource($controller, $rootPath, $folder_id, 0, 1, null, $dataSource, $dataView);
	        return $source->deleteRow($dataSource->getSQLTableName(), $dataSource->getSQLKeyName(), $doc_id);
	    }
	}
	/* no longer used*/
	public static function editDocument($controller, $rootPath, $doc_id, $folder_id, $dataViewId ){		
	   
		$em = ExternalViews::getEntityManager($controller);
		$dataView = $em->getRepository("DocovaBundle:DataViews")->find($dataViewId);
		$dataSource = !empty($dataView) ? $dataView->getDataSource($em) : null;
	
		//Do not process DOCOVA documents
        if (!empty($dataSource)){
        	$docovaDocumentsOnly = $dataSource->getDocovaDocumentsOnly();
        	if (!empty($docovaDocumentsOnly) && $docovaDocumentsOnly){
        		return null;
        	}
        }
        
        if (empty($doc_id) || $doc_id=="undefined" || $doc_id=="null"){
            //new document            
            $documentData = ExternalViews::getFirstDocument(ExternalViews::getDocumentData($controller, $rootPath, null, $dataView, $dataSource));
                        
        }
        else {
            $documentData = ExternalViews::getFirstDocument(ExternalViews::getDocumentData($controller, $rootPath, $doc_id, $dataView, $dataSource));
        }
		$securityContext = $controller->getSecurityContext();
		
		$customFormPath = \realpath(__DIR__.'/../Resources/views/Form').DIRECTORY_SEPARATOR.$dataView->getName().'_edit.html.twig';
		if (\file_exists($customFormPath)){
		    //render using custom form
			return $controller->renderForm('DocovaBundle:Form:'.$dataView->getName().'_edit.html.twig', array(
			        'dataSource' => $dataSource,
			        'dataView' => $dataView,
			         'viewName' => $dataView->getName(),
			         'viewTitle' => (empty($dataView->getFormLabel()) ? $dataView->getName(): $dataView->getFormLabel()),
					'doc_id' => $doc_id,
					'folderId' => $folder_id,
					'dataViewId' => $dataView->getId(),
			        'document' => $documentData,
			        'user' => $securityContext->getToken()->getUser(),
			        'keyName' => $dataSource->getSQLKeyName()
			));
		} 
		else {		
			//no custom twig found, render using the default twig
			return $controller->renderForm('DocovaBundle:Form:Default-External_edit.html.twig', array(
			         'dataSource' => $dataSource,
			         'dataView' => $dataView,
			         'viewName' => $dataView->getName(),
			         'viewTitle' => (empty($dataView->getFormLabel()) ? $dataView->getName(): $dataView->getFormLabel()),
					'doc_id' => $doc_id,
					'folderId' => $folder_id,
					'dataViewId' => $dataView->getId(),
					'document' => $documentData,
			        'user' => $securityContext->getToken()->getUser(),
			        'keyName' => $dataSource->getSQLKeyName()
			));
		}
	}
	public static function dbColumn($controller,$rootPath,$dataView,$column) {
	    $em = ExternalViews::getEntityManager($controller);
	    $sqlSource = getSQLSource($controller,$rootPath,null,1,0,false,$dataView->getDataSource($em),$dataView);
	    return $sqlSource->dbColumn(1);
	}
	public static function getData($controller,$rootPath,$folder_id,$start,$count,$searchQuery,$returnJSON=false) {
	    
		//Check to see if there this folder is supplied by an external view
		$em = ExternalViews::getEntityManager($controller);	
		if ($folder_id instanceof DataViews){
			$dataView = $folder_id;
			$folder_id = $dataView->getId();
		}
		else{			
			$dataView = $em->getRepository("DocovaBundle:DataViews")->getDataView($folder_id);
		}
		$dataSource = !empty($dataView) ? $dataView->getDataSource($em) : null;
		if (empty($dataView))
			return null;
		
		//Proces SQL data extensions		
		$data = ExternalViews::getSQLData($controller,$rootPath, $folder_id, $start, $count, $searchQuery,$dataSource,$dataView,$returnJSON);
	
		if ($data!=null) return $data;
		
		//Proces CSV data extensions		
		$data = ExternalViews::getCSVData($controller,$rootPath,$folder_id, $start, $count, $searchQuery,$dataSource,$dataView);
		if ($data!=null) return $data;
		
		return null;
	}
	
	public static function getCount($controller,$rootPath,$folder_id){		
		//Data View Mappings
		$em = ExternalViews::getEntityManager($controller);
		$dataView = $em->getRepository("DocovaBundle:DataViews")->getDataView($folder_id);
		$dataSource = !empty($dataView) ? $dataView->getDataSource($em) : null;
		if (!empty($dataView) && !empty($dataSource)){
			$dataType = $dataSource->getType();				
			if ($dataType=="SQL"){
				$connectionName = $dataSource->getConnectionName();
				$connection = $connectionName=="DOCOVA SE" ? $controller->getDoctrine()->getConnection() : ExternalConnections::getConnection($connectionName);
				$sqlType = $dataSource->getSQLType();
				if ($sqlType=="Text")
						$query = $dataSource->getSQL();
				else if ($sqlType=="File Resource" &&
					(empty($query) || $query=="" ))
						$query = $dataSource->getFileResourceContent($em,$rootPath);
				
				if (empty($query) || $query=="" )
					throw new NotFoundHttpException("A query must be provided");
				
				//check to see if this is a DOCOVA documents source
				$docovaDocumentsOnly = $dataSource->getDocovaDocumentsOnly();
				if (empty($docovaDocumentsOnly) || $docovaDocumentsOnly==false){
					$docovaDocumentsOnly=false;
				}
								
				$sqlSource = new SQLDataSource(
						$controller,
						$dataView->getName(), 
						$connection, 
						$query,
						$dataSource->getSQLOrderBy(),
				        null,//key name
				        null,//key value
						0,
						0,
						$docovaDocumentsOnly);
				
				return $sqlSource->getRowCountResponse($dataSource->getSQLTableName());
			}
			else if ($dataType=="CSV"){
				$csvPath = $dataSource->getFileResourcePath($em,$rootPath);
				if (empty($csvPath))
					throw new NotFoundHttpException("File resouce ".$dataSource->getFileResourceName()." was not found!");		
				return CSVDataSource::getRowCountResponse($csvPath);
			}			
		}
		
		//Special handling
		switch ($folder_id){
			/*
			case "361CD4FA-DA4B-41BC-BD83-4B87F3BBDBFC":
				$file_resource = $em->getRepository('DocovaBundle:FileResources');
				$csvPath = $file_resource->getFileResourcePath($rootPath,"Fruit");
				if (empty($csvPath))
					throw new \Exception("File resouce Fruit was not found!");
				$file_resource=null;
				return CSVDataSource::getRowCountResponse($csvPath);
			*/
			default:
				return null;
		}
	}
	private static function getDocumentContent($dataView,$data){
		$html= "<h3 style='border:0;margin:5px;font-family: Verdana; font-size: 10pt; font-weight: bold'>".$dataView->getName()."</h3>";
		$html.="<hr style='margin-top:5:px;color:rgb(92,134,197);height:1px'/>";
		
		$html.="<table border=0 style='font-family: Verdana; font-size: 8pt;'>";
		
		if (!empty($data)){
			foreach($data as $field => $field_value){
				$html.= "<tr>";
					$html.= "<td><b>".$field.":&nbsp;&nbsp;&nbsp;</b></td>";
					$html.= "<td>".$field_value."</td>";
				$html.= "</tr>";					
			}
		}			
		
		$html.= "</table>";
	    return $html;
	}
	public function getFirstDocument($documentData){
	    
		foreach($documentData as $data){
			if (!empty($data)){
				return $data;				
			}
		}
	}
	public static function getDocumentData($controller, $rootPath, $doc_id, $dataView,$dataSource){
		$em = ExternalViews::getEntityManager($controller);
		if (empty($dataView) & empty($dataSource)){
			throw new NotFoundHttpException("Data View or Data Source could not be located!");
		}
	
		switch ($dataSource->getType()){
			case "CSV":
				if ($dataSource->getName()=="IIS Logs" || $dataSource->getName()=="IIS Log"){
					$iisPath="C:/inetpub/logs/LogFiles/W3SVC1/";
					$files = scandir($iisPath, SCANDIR_SORT_DESCENDING);
					$csvFilePath = $iisPath.$files[0];
					if (empty($csvFilePath))
						throw new NotFoundHttpException("No log files found to process in path");
				}
				else
					$csvFilePath = $dataSource->getFileResourcePath($em,$rootPath);
				
				//CSV Options
				$csvDelimiter = $dataSource->getCSVDelimiter();
				$csvOffsetLines = $dataSource->getCSVOffsetLines();
				$csvOffsetChars = $dataSource->getCSVOffsetChars();
				
				$csvSource = new CSVDataSource($controller,$csvFilePath,intval($doc_id)-1,1,null,
						$csvDelimiter,$csvOffsetLines,$csvOffsetChars);
				return $csvSource->getDataNameValues();
				break;
			case "SQL":
				$connectionName = $dataSource->getConnectionName();
				$connection = $connectionName=="DOCOVA SE" ? $controller->getDoctrine()->getConnection() : ExternalConnections::getConnection($connectionName);
				$sqlType = $dataSource->getSQLType();
				if ($sqlType=="Text")
					$query = $dataSource->getSQL();
				if (empty($query) || $query=="")
					$query = $dataSource->getFileResourceContent($em,$rootPath);
				

				//check to see if this is a DOCOVA documents source
				$docovaDocumentsOnly = $dataSource->getDocovaDocumentsOnly();
				if (empty($docovaDocumentsOnly) || $docovaDocumentsOnly==false){
					$docovaDocumentsOnly=false;
				}
							
				$sqlSource = new SQLDataSource(
						$controller,
						$dataView->getName(),
						$connection,
						$query,
						$dataSource->getSQLOrderBy(),
				        $dataSource->getSQLKeyName(),//key name
    				    $doc_id,//key value
				        $doc_id==null || $doc_id=="null" ? null : 0,
						1,
						$docovaDocumentsOnly);
							
				return $sqlSource->getDataNameValues();
				break;
		}
	}
		
	private static function getEntityManager($controller){
		return  $controller->getEntityManager();
	}
	public static function getSQLSourceExt($controller,$dataView,$dataSource,$connection,$query,$start=1,$count=10000){
	    $sqlSource = new SQLDataSource(
	        $controller,
	        $dataView->getName(),
	        $connection,
	        $query,
	        $dataSource->getSQLOrderBy(),
	        null,
	        null,
	        ($start-1),
	        $count,null,false);
	    
	    if (!empty($dataView)){
	        $perspectiveColumns = $dataView->getPerspectiveColumns();
	        if (!empty($perspectiveColumns)){
	            $sqlSource->setDisplayColumns($perspectiveColumns);
	        }
	    }
	    return $sqlSource;
	}
	private static function getSQLSource($controller,$rootPath,$folder_id,$start,$count,$searchQuery,$dataSource,$dataView) {
		//Adjust the offsets and limits
		$start = ($searchQuery!=null ? 1 : $start);
		$start = ($start==0 ? 1 : $start);
		$count = ($count==10000 ? 1000000 : $count);
		$count = ($searchQuery!=null ? 1000000 : $count);
		
		
		//Data View Hooks
		$em = ExternalViews::getEntityManager($controller);
		if (!empty($dataView) && !empty($dataSource)){
			$connectionName = $dataSource->getConnectionName();
			$connection = $connectionName=="DOCOVA SE" ? $controller->getDoctrine()->getConnection() : ExternalConnections::getConnection($connectionName);
			$dataType = $dataSource->getType();
	
			if ($dataType=="SQL"){
				$sqlType = $dataSource->getSQLType();
				if ($sqlType=="Text")
					$query = $dataSource->getSQL();
				else if ($sqlType=="File Resource" &&
						(empty($query) || $query=="" ))
							$query = $dataSource->getFileResourceContent($em,$rootPath);
							
				if (empty($query) || $query=="" )
					throw new NotFoundHttpException("A query must be provided");
				
				$docovaDocumentsOnly = $dataSource->getDocovaDocumentsOnly();
				if (empty($docovaDocumentsOnly) || $docovaDocumentsOnly==false){
					$docovaDocumentsOnly=false;
				}				
			
				//If the data view has a filter then append it as an additonal condition
			    $whereFilter=$dataView->getSQLFilter();
			    if (!empty($whereFilter) && $whereFilter!=""){
			    	//if a where statement does not exist in the query then add one			    	
			    	if (\strpos(\strtolower($query),"where")===false)
			    		$query.=" WHERE ".$whereFilter;
			    	else
			    	//add an additional AND WHERE condition
			    		$query.=" AND ".$whereFilter;
			    }
			    
				$sqlSource = new SQLDataSource(
						$controller,						
						$dataView->getName(),
						$connection,
						$query,
						$dataSource->getSQLOrderBy(),
				        null,
				        null,
						($start-1),
						$count,$searchQuery,$docovaDocumentsOnly);

				if (!empty($dataView)){
				    $perspectiveColumns = $dataView->getPerspectiveColumns();
				    if (!empty($perspectiveColumns)){
				        $sqlSource->setDisplayColumns($perspectiveColumns);
				    }
				}
				return $sqlSource;
			}
		}
	
		//Hard Coded Hooks
		switch ($folder_id){
			//Special External Data Folder Hooks
	
			/*
				//Game
				case "3EE64EC3-AFC5-49E6-A18E-558AC25F82CA":
				$query = "SELECT * FROM dbo.Game";
				$sqlSource = new SQLDataSource("Game", ExternalConnections::getVideoGamesDbConnection(), $query,"SystemName",($start-1),$count,$searchQuery);
				return $sqlSource; //->getXmlResponse($folder_id,$isSearch);
				*/
			default:
				return null;
					
		}
	}
	
	private static function getSQLData($controller,$rootPath,$folder_id,$start,$count,$searchQuery,$dataSource,$dataView,$returnJSON=false) {
		$isSearch = ($searchQuery==null ? false : true);
		$sqlSource = self::getSQLSource($controller, $rootPath, $folder_id, $start, $count, $searchQuery, $dataSource, $dataView);
		
		if (!empty($sqlSource)){
		    $docovaDocs = null;
		    $keyFieldName = $dataSource->getSQLKeyName();
		    $formName = $dataView->getFormName();
		    if (!empty($keyFieldName) && !empty($formName) ){
		        //read the key values and use them to locate the associated DOCOVA documents
		        $extKeys = $sqlSource->dbColumn($dataSource->getSQLKeyName());		        
		        $docovaDocs = self::getAssociatedDOCOVADocuments(self::getEntityManager($controller), $dataView->getAppId(), $formName, $keyFieldName, $extKeys);
		    }
		    

		    $applicationForm = ExternalViews::getApplicationForm(self::getEntityManager($controller), $dataView->getAppId(), $formName);
		    if (!empty($applicationForm)){
		        //compute the DOCOVA Fields included in the perspective
		        //Do so by removing the SQL columns from the perspective columns list, the remaining columns will be DOCOVA columns		        
		        $docovaFields = array_diff($dataView->getPerspectiveColumns(),$sqlSource->getFields());
		        if (!empty($docovaFields)){
		            $docovaFields = implode(',',$docovaFields);
		        }
		        $docovaDocFieldValues = ExternalViews::getSpecifiedDocumentFieldValues(self::getEntityManager($controller), $dataView->getAppId(),$applicationForm, $docovaDocs, $docovaFields);
		        //echo "Dcova doc fields values:".PHP_EOL.json_encode($docovaDocFieldValues);
		    }
		    
			if ($returnJSON){			    
			    return $sqlSource->getJsonResponse($folder_id,$isSearch,$dataSource->getSQLKeyName(),null,null,$dataView->getPerspectiveColumns(),$docovaDocs,$docovaDocFieldValues);
			}
			else{
			    //no longer used
			    return $sqlSource->getXmlResponse($folder_id,$isSearch,$dataSource->getSQLKeyName());
			}
		}
	}
	
	public static function getAssociatedDOCOVADocuments($em,$application,$formName,$keyFieldName,$keyFieldValues){
	    $form = self::getApplicationForm($em,$application, $formName);
	   	    
	    if (empty($form)){		       
	        return array();
	    }
	    $keyField = self::getFormElement($form,$keyFieldName);
	    
	    if (empty($keyField)){	        
	        return array();
	    }
	    
	    //for now lets assume all key fields are text
//TODO need to expand to handle other types, specifically numeric keys	    
	    $ftv = $em->getRepository("DocovaBundle:FormTextValues");
	    
	    $query = $ftv->createQueryBuilder('EV')
	    ->select('EV')
	    ->where('EV.Field = :field');
	    
	    if ($keyFieldValues==null){
	        $parameters = array('field' => $keyField);
	        $query->setParameters($parameters);
	    }
	    else if (empty($keyFieldValues)){
	        return array();
	    }
	    else{	    
	        $keyList = self::getSQLList($keyFieldValues);	        
	        $query->andWhere('EV.summaryValue IN '.$keyList);
	        $parameters = array('field' => $keyField);
	        $query->setParameters($parameters);
	    }
	    
	    $query = $query->getQuery();
	    
	    
	    $fieldValues = $query->getResult();
	    
	    $results = array();
	    
	    if (!empty($fieldValues)){
	        foreach($fieldValues as $fieldValue){
	            $results[$fieldValue->getFieldValue()]=$fieldValue->getDocument();
	        }
	    }
	    
	    return $results;
	}
	public static function getSQLList(array $data,$checkType=false){
	    $list = "(";
	    foreach($data as $index=>$value){
	        if ($index!=0){
	            $list.=",";
	        }
	        if ($checkType){
    	        if (is_numeric($value)){
    	            //no need to quote the value
    	            $list.=$value;
    	        }
    	        else{
    	            $list.="'".$value."'";
    	        }
	        }
	        else{
	            $list.="'".$value."'";
	        }
	        
	    }
	    $list.=")";
	    return $list;
	}
	public static function getApplicationForm($em,$application,$formName){
	    $forms = $em->getRepository("DocovaBundle:AppForms");
	    $query = $forms->createQueryBuilder('F')->select("F")->where('F.application = :application')
	    ->andWhere('F.formName = :formName');
	    $query->setParameters(array('application'=>$application,'formName'=>$formName));
	    $appForms = $query->getQuery()->getResult();
	    if (!empty($appForms)){
	        return $appForms[0];
	    }
	    else{
	        return null;
	    }
	}
	
	public static function getDocumentField($document,$fieldName){
	    $fieldName = str_replace('_','',$fieldName);
	    //first check to see if we have a matching property on the document itself
	    if (method_exists($document,"get".$fieldName)){	   
	          // echo PHP_EOL."Field ".$fieldName." found";
	          
	           $result = call_user_func(array($document,"get".$fieldName));
	          // echo PHP_EOL."Class for ".$fieldName." ".get_class($result)." found";
	           if ($result instanceof DateTime){
	               return $result->format('Y-m-d H:i:s');
	           }
	           else if ($result instanceof UserAccounts){
	               return $result->getUserNameDnAbbreviated();
	           }
	           else{
	               return $result;
	           }
	    }
	    else{
	       // echo PHP_EOL."Field ".$fieldName." NOT found";
	        return null;
	    }
	}
	public static function isDocumentField($document,$fieldName){
	    $fieldName = str_replace('_','',$fieldName);
	    //first check to see if we have a matching property on the document itself
	    if (method_exists($document,"set".$fieldName)){
	        return true;
	    }
	    else{
	        return false;
	    }
	}
	public static function getFormFieldsByType($designElements,$docovaFields){
	    //compute a distinct list of the types being requested
	    $fieldsByType = array();
	    if (empty($docovaFields)){	       
	        return $fieldsByType;
	    }
	    
	    if (!is_array($docovaFields)){
	        $docovaFields = explode(',',$docovaFields);
	    }
	  
	    if (!empty($designElements)){
    	    foreach($designElements as $element){
    	        if (in_array($element->getFieldName(),$docovaFields)){      	           
    	            if (!array_key_exists($element->getFieldType(),$fieldsByType)){
    	                $fieldsByType[$element->getFieldType()] = array( $element->getId()=> $element) ;
    	            }
    	            else{    	                
    	                $fieldsByType[$element->getFieldType()][$element->getId()] = $element;
    	            }
    	        }    	       
    	    }
	    }
	    return $fieldsByType;
	}
	private static function getDocovaIds($docovaDocs){
	    $docovaIds=array();
	    foreach($docovaDocs as $docovaDoc){
	        $docovaIds[]=$docovaDoc->getId();
	    }
	    return $docovaIds;
	}

	public static function getSpecifiedDocumentFieldValues(EntityManager $em,$app_id,$form,$docovaDocs,$docovaFields){
	    $docovaIds = self::getDocovaIds($docovaDocs);	 
	    $documentValues=array();
	    if (!empty($docovaIds)){
    	    //determine which types are being referenced
    	    $applicationForm = ExternalViews::getApplicationForm($em, $app_id, $form->getFormName());
    	    if (!empty($applicationForm)){
    	        $formFieldsByType = ExternalViews::getFormFieldsByType($form->getElements(), $docovaFields);
    	        
    	        if (array_key_exists(0,$formFieldsByType)){
    	            //text fields specified
    	            $textFields = $formFieldsByType[0];	            
    	            $textFieldIds = array_keys($textFields);	
    	            $query = "SELECT doc_id,field_id,field_value,value_Order FROM tb_form_text_values ".PHP_EOL.
    	            "WHERE doc_id IN ". self::getSQLList($docovaIds)." AND field_id IN ". self::getSQLList($textFieldIds).PHP_EOL.
    	            "ORDER BY doc_id,field_id,value_order";
    	            
    	            $textFieldResults = $em->getConnection()->fetchAll($query);
    	            //if any field values were found, then reindex the values by document id then field name and value order
    	            // $documentValues[$doc_id][$fieldname][$fieldvalue][$value_order or null)
    	            ExternalViews::processDocumentValues(0,$textFieldResults, $textFields, $documentValues);
    	           
    	        }
    	        if (array_key_exists(4,$formFieldsByType)){
    	            //number fields specified
    	            $numberFields = $formFieldsByType[4];
    	            $numberFieldIds = array_keys($numberFields);
    	            
    	            $query = "SELECT doc_id,field_id,field_value,value_Order FROM tb_form_numeric_values ".PHP_EOL.
    	            "WHERE doc_id IN ". self::getSQLList($docovaIds)." AND field_id IN ". self::getSQLList($numberFieldIds).PHP_EOL.
    	            "ORDER BY doc_id,field_id,value_order";
    	            
    	            $numberFieldResults = $em->getConnection()->fetchAll($query);
    	            //if any field values were found, then reindex the values by document id then field name and value order
    	            // $documentValues[$doc_id][$fieldname][$fieldvalue][$value_order or null)
    	            ExternalViews::processDocumentValues(4,$numberFieldResults, $numberFields, $documentValues);
    	        }
    	        if (array_key_exists(1,$formFieldsByType)){
    	            //date fields specified
    	            $dateFields = $formFieldsByType[1];
    	            $dateFieldIds = array_keys($dateFields);
    	            
    	            $query = "SELECT doc_id,field_id,field_value,value_Order FROM tb_form_datetime_values ".PHP_EOL.
    	            "WHERE doc_id IN ". self::getSQLList($docovaIds)." AND field_id IN ". self::getSQLList($dateFieldIds).PHP_EOL.
    	            "ORDER BY doc_id,field_id,value_order";
    	            
    	            $dateFieldResults = $em->getConnection()->fetchAll($query);
    	            //if any field values were found, then reindex the values by document id then field name and value order
    	            // $documentValues[$doc_id][$fieldname][$fieldvalue][$value_order or null)
    	            ExternalViews::processDocumentValues(1,$dateFieldResults, $dateFields, $documentValues);
    	        }
    	        if (array_key_exists(3,$formFieldsByType)){
    	            //name fields specified
    	            $nameFields = $formFieldsByType[3];
    	            $nameFieldIds = array_keys($nameFields);
    	            $query = "SELECT T.* FROM (".PHP_EOL.
    	            "SELECT doc_id,field_id,(SELECT user_name_dn_abbreviated as Field_Value FROM tb_user_accounts WHERE id=field_value) as field_value,value_Order FROM tb_form_name_values ".PHP_EOL.
    	            "WHERE doc_id IN ". self::getSQLList($docovaIds)." AND field_id IN ". self::getSQLList($nameFieldIds).PHP_EOL.
    	            "UNION ".PHP_EOL.
    	            "SELECT doc_id,field_id,(SELECT group_name As Field_Value FROM tb_user_roles WHERE id=field_value) As field_value,value_Order FROM tb_form_group_values ".PHP_EOL.
    	            "WHERE doc_id IN ". self::getSQLList($docovaIds)." AND field_id IN ". self::getSQLList($nameFieldIds).PHP_EOL.
    	            ") T ".PHP_EOL.
    	            "ORDER BY doc_id,field_id,value_order";
    	            
    	            $nameFieldResults = $em->getConnection()->fetchAll($query);
    	            //if any field values were found, then reindex the values by document id then field name and value order
    	            // $documentValues[$doc_id][$fieldname][$fieldvalue][$value_order or null)
    	            ExternalViews::processDocumentValues(3,$nameFieldResults, $nameFields, $documentValues);
    	        }
    	        
    	    }
	    }
	    return $documentValues;
	}
	private static function processDocumentValues($type,$fieldValuesCollection,$elements,&$documentValues){
	    if (!empty($fieldValuesCollection)){
	        foreach($fieldValuesCollection as $fieldValue){
	            $doc_id = $fieldValue['doc_id'];
	            $field_id = $fieldValue['field_id'];
	            $field_value = $fieldValue['field_value'];
	            if ($type==1 and !empty($field_value) ){
	                //remove and subsecond values from any date fields
	                $documentValues[$doc_id][$elements[$field_id]->getFieldName()][]=str_replace('.000000','',$field_value);
	            }
	            else{
    	            $documentValues[$doc_id][$elements[$field_id]->getFieldName()][]=$field_value;
	            }
	        }
	    }
	}
	
	protected static function getFormElement(AppForms $form,$fieldName){
	    $elements = $form->getElements();
	    if (!empty($elements)){
	        foreach($elements as $element){
	            if (strtolower($element->getFieldName())==strtolower($fieldName)) {
	                return $element;
	            }
	        }
	    }
	}
	private static function getCSVSource($controller,$rootPath,$folder_id,$start,$count,$searchQuery,$dataSource,$dataView){
		
		//Adjust the offsets and limits
		$em = ExternalViews::getEntityManager($controller);
		$start = $searchQuery!=null ? 1 : $start;
		$count = $count==10000 ? 0 : $count;
		
		//Data view hooks
		if (!empty($dataView) && !empty($dataSource)){
			
			$dataType = $dataSource->getType();			
			if ($dataType=="CSV"){
				
				if ($dataSource->getName()=="IIS Logs" || $dataSource->getName()=="IIS Log"){
					$iisPath="C:/inetpub/logs/LogFiles/W3SVC1/";
					$files = scandir($iisPath, SCANDIR_SORT_DESCENDING);
					$csvFilePath = $iisPath.$files[0];
					if (empty($csvFilePath))
						throw new NotFoundHttpException("No log files found to process in path");
				}
				else
					$csvFilePath = $dataSource->getFileResourcePath($em,$rootPath);
				
				if (empty($csvFilePath)){
					throw new \Exception("Unable to determine CSV data file location in "+$rootPath);
				}
				
				//CSV Options
				$csvDelimiter = $dataSource->getCSVDelimiter();
				$csvOffsetLines = $dataSource->getCSVOffsetLines();
				$csvOffsetChars = $dataSource->getCSVOffsetChars();

				$docovaDocumentsOnly = $dataSource->getDocovaDocumentsOnly();
				if (empty($docovaDocumentsOnly) || $docovaDocumentsOnly==false){
					$docovaDocumentsOnly=false;
				}
				
				$csvSource = new CSVDataSource($controller,$csvFilePath,$start,$count,$searchQuery,
						$csvDelimiter,$csvOffsetLines,$csvOffsetChars,$docovaDocumentsOnly);
				
				return $csvSource;
			}
		}

		//Hard Coded hooks
		switch ($folder_id){
			//Special External Data Folder Hooks
				
			//IIS Logs
			case "D7187305-B06D-4860-8513-41F208BDB2A6":
				$iisPath="C:/inetpub/logs/LogFiles/W3SVC1/";
				$files = scandir($iisPath, SCANDIR_SORT_DESCENDING);
				$logFilePath = $files[0];
				if (empty($logFilePath))
					throw new NotFoundHttpException("No log files found to process in path: ".$iisPath);
					
				//Skip software,date, and version lines
				//Space is the delimiter
				$csvSource = new CSVDataSource($controller,$iisPath.$logFilePath,$start,$count,$searchQuery," ",3,10);
				return $csvSource;
			default:
				return null;
		}
	}
	private static function getCSVData($controller,$rootPath,$folder_id,$start,$count,$searchQuery,$dataSource,$dataView){
		$csvSource = self::getCSVSource($controller, $rootPath, $folder_id, $start, $count, $searchQuery, $dataSource, $dataView);
		$isSearch = $searchQuery==null ? false : true;		
		if ($csvSource==null)
			return null;
		else 
			return $csvSource->getXmlResponse($folder_id,$isSearch);
	}
	private static function getSchemaQuery($controller,$rootPath) {
		$em = ExternalViews::getEntityManager($controller);
		return $em->getRepository("DocovaBundle:FileResources")->getFileResourceContent($rootPath, "SE Schema");				
	}
	private static function getLibraryStatisticsQuery($controller,$rootPath){
		$em = ExternalViews::getEntityManager($controller);
		return $em->getRepository("DocovaBundle:FileResources")->getFileResourceContent($rootPath, "SE Library Statistics");	
	}
	function getGUID(){
	    if (function_exists('com_create_guid')){
	        return com_create_guid();
	    }else{
	        mt_srand((double)microtime()*10000);//optional for php 4.2.0 and up.
	        $charid = strtoupper(md5(uniqid(rand(), true)));
	        $hyphen = chr(45);// "-"
	        $uuid = chr(123)// "{"
	        .substr($charid, 0, 8).$hyphen
	        .substr($charid, 8, 4).$hyphen
	        .substr($charid,12, 4).$hyphen
	        .substr($charid,16, 4).$hyphen
	        .substr($charid,20,12)
	        .chr(125);// "}"
	        return $uuid;
	    }
	}
}
?>