<?php

namespace Docova\DocovaBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * UserLibrariesGroups
 *
 * @ORM\Table(name="tb_user_libraries_groups")
 * @ORM\Entity(repositoryClass="Docova\DocovaBundle\Entity\UserLibrariesGroupsRepository")
 */
class UserLibrariesGroups
{
    /**
     * @var string
     *
     * @ORM\Column(name="id", type="guid")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="UUID")
     */
    protected $id;

    /**
     * @var string
     * 
     * @ORM\Column(name="Item_Type", type="string", length=2)
     */
    protected $type;

    /**
     * @ORM\ManyToOne(targetEntity="UserAccounts")
     * @ORM\JoinColumn(name="User_Id", referencedColumnName="id", nullable=false, onDelete="CASCADE")
     */
	protected $user;

	/**
	 * @ORM\ManyToOne(targetEntity="Libraries")
	 * @ORM\JoinColumn(name="Library_Id", referencedColumnName="id", nullable=true, onDelete="CASCADE")
	 */
	protected $library;

	/**
     * @ORM\ManyToOne(targetEntity="LibraryGroups")
     * @ORM\JoinColumn(name="Library_Group", referencedColumnName="id", nullable=true, onDelete="CASCADE")
     */
    protected $libraryGroup;


    /**
     * Get id
     *
     * @return string
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set type
     * 
     * @param string $type
     * @return UserLibrariesGroups
     */
    public function setType($type)
    {
    	$this->type = $type;
    	
    	return $this;
    }

    /**
     * Get type
     * @return string
     */
    public function getType()
    {
    	return $this->type;
    }

    /**
     * Set user
     *
     * @param \Docova\DocovaBundle\Entity\UserAccounts $user
     *
     * @return UserLibrariesGroups
     */
    public function setUser(\Docova\DocovaBundle\Entity\UserAccounts $user = null)
    {
        $this->user = $user;

        return $this;
    }

    /**
     * Get user
     *
     * @return \Docova\DocovaBundle\Entity\UserAccounts
     */
    public function getUser()
    {
        return $this->user;
    }

    /**
     * Set library
     *
     * @param \Docova\DocovaBundle\Entity\Libraries $library
     *
     * @return UserLibrariesGroups
     */
    public function setLibrary(\Docova\DocovaBundle\Entity\Libraries $library = null)
    {
        $this->library = $library;

        return $this;
    }

    /**
     * Get library
     *
     * @return \Docova\DocovaBundle\Entity\Libraries
     */
    public function getLibrary()
    {
        return $this->library;
    }

    /**
     * Set libraryGroup
     *
     * @param \Docova\DocovaBundle\Entity\LibraryGroups $libraryGroup
     *
     * @return UserLibrariesGroups
     */
    public function setLibraryGroup(\Docova\DocovaBundle\Entity\LibraryGroups $libraryGroup = null)
    {
        $this->libraryGroup = $libraryGroup;

        return $this;
    }

    /**
     * Get libraryGroup
     *
     * @return \Docova\DocovaBundle\Entity\LibraryGroups
     */
    public function getLibraryGroup()
    {
        return $this->libraryGroup;
    }
}
